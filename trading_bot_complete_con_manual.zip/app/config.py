"""Central configuration loaded from environment variables."""

from __future__ import annotations

import os
from pathlib import Path
from typing import Optional

from dotenv import load_dotenv
from pydantic_settings import BaseSettings

_env_path = Path(__file__).resolve().parent.parent / ".env"
load_dotenv(_env_path)


class Settings(BaseSettings):
    # --- mode ---
    PAPER_MODE: bool = True  # True = paper trading, False = live
    TEST_MODE: bool = True   # True = use synthetic data
    LOG_LEVEL: str = "INFO"

    # --- CEX API keys ---
    BINANCE_API_KEY: str = ""
    BINANCE_API_SECRET: str = ""
    COINBASE_API_KEY: str = ""
    COINBASE_API_SECRET: str = ""
    COINBASE_PASSPHRASE: str = ""

    # --- DEX ---
    WEB3_RPC_URL: str = "https://eth-mainnet.g.alchemy.com/v2/demo"
    WALLET_ADDRESS: str = ""
    WALLET_PRIVATE_KEY: str = ""
    UNISWAP_ROUTER: str = "0x7a250d5630B4cF539739dF2C5dAcb4c659F2488D"

    # --- Trading defaults ---
    DEFAULT_EXCHANGE: str = "binance"
    DEFAULT_SYMBOL: str = "BTC/USDT"
    DEFAULT_TIMEFRAME: str = "1h"
    MAX_POSITION_SIZE_PCT: float = 5.0    # % of portfolio per trade
    MAX_OPEN_POSITIONS: int = 5
    DEFAULT_STOP_LOSS_PCT: float = 2.0
    DEFAULT_TAKE_PROFIT_PCT: float = 4.0
    RISK_REWARD_MIN: float = 1.5

    # --- Scalping ---
    SCALP_TIMEFRAME: str = "1m"
    SCALP_MAX_HOLD_MINUTES: int = 15
    SCALP_STOP_LOSS_PCT: float = 0.5
    SCALP_TAKE_PROFIT_PCT: float = 1.0

    # --- Intraday ---
    INTRADAY_TIMEFRAME: str = "15m"
    INTRADAY_MAX_HOLD_HOURS: int = 8
    INTRADAY_STOP_LOSS_PCT: float = 1.5
    INTRADAY_TAKE_PROFIT_PCT: float = 3.0

    # --- Swing ---
    SWING_TIMEFRAME: str = "4h"
    SWING_MAX_HOLD_DAYS: int = 14
    SWING_STOP_LOSS_PCT: float = 3.0
    SWING_TAKE_PROFIT_PCT: float = 8.0

    # --- Risk ---
    MAX_DAILY_LOSS_PCT: float = 5.0
    MAX_DRAWDOWN_PCT: float = 15.0
    POSITION_SIZING_METHOD: str = "kelly"  # kelly | fixed | atr

    # --- Notifications ---
    TELEGRAM_BOT_TOKEN: str = ""
    TELEGRAM_CHAT_ID: str = ""
    DISCORD_WEBHOOK_URL: str = ""

    class Config:
        env_file = ".env"
        extra = "ignore"


settings = Settings()
