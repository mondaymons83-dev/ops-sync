"""CLI Interface for the Trading Bot.

Commands:
  tradingbot run         - Start live/paper trading
  tradingbot backtest    - Run backtesting on historical data
  tradingbot strategies  - List all available strategies
  tradingbot status      - Show current configuration and status
"""

from __future__ import annotations

import asyncio
import sys
from typing import List, Optional

import click
import numpy as np
import pandas as pd
from rich.console import Console
from rich.table import Table

from app.config import settings

console = Console()


def _get_connector(exchange: str):
    """Create and return the appropriate exchange connector."""
    if exchange == "binance":
        from connectors.binance_connector import BinanceConnector
        return BinanceConnector()
    elif exchange == "coinbase":
        from connectors.coinbase_connector import CoinbaseConnector
        return CoinbaseConnector()
    elif exchange == "dex":
        from connectors.dex_connector import DEXConnector
        return DEXConnector()
    else:
        console.print(f"[red]Unknown exchange: {exchange}[/red]")
        sys.exit(1)


def _get_all_strategies():
    """Return a list of all available strategy classes."""
    strategies = []

    # Scalping
    from strategies.scalping.ema_crossover import EMAcrossoverScalp
    from strategies.scalping.bollinger_bounce import BollingerBounceScalp
    from strategies.scalping.vwap_reversion import VWAPReversionScalp
    from strategies.scalping.orderbook_imbalance import OrderBookImbalanceScalp
    from strategies.scalping.momentum_burst import MomentumBurstScalp

    strategies.extend([
        EMAcrossoverScalp, BollingerBounceScalp, VWAPReversionScalp,
        OrderBookImbalanceScalp, MomentumBurstScalp,
    ])

    # Intraday
    from strategies.intraday.sr_breakout import SRBreakoutIntraday
    from strategies.intraday.elliott_impulse import ElliottImpulseIntraday
    from strategies.intraday.ma_ribbon import MARibbonIntraday
    from strategies.intraday.fib_retracement import FibRetracementIntraday
    from strategies.intraday.pattern_detection import PatternDetectionIntraday

    strategies.extend([
        SRBreakoutIntraday, ElliottImpulseIntraday, MARibbonIntraday,
        FibRetracementIntraday, PatternDetectionIntraday,
    ])

    # Swing
    from strategies.swing.elliott_full_cycle import ElliottFullCycleSwing
    from strategies.swing.golden_cross import GoldenDeathCrossSwing
    from strategies.swing.multi_timeframe import MultiTimeframeSwing
    from strategies.swing.divergence import DivergenceSwing
    from strategies.swing.flag_breakout import FlagBreakoutSwing

    strategies.extend([
        ElliottFullCycleSwing, GoldenDeathCrossSwing, MultiTimeframeSwing,
        DivergenceSwing, FlagBreakoutSwing,
    ])

    return strategies


def _get_strategies_by_style(style: Optional[str] = None):
    """Filter strategies by trading style."""
    all_strategies = _get_all_strategies()

    if not style:
        return [s() for s in all_strategies]

    return [s() for s in all_strategies if s.trading_style.value == style]


def _generate_synthetic_data(bars: int = 500, base_price: float = 50000.0) -> pd.DataFrame:
    """Generate synthetic OHLCV data for testing."""
    np.random.seed(42)
    dates = pd.date_range(end=pd.Timestamp.now(), periods=bars, freq="4h")

    prices = [base_price]
    for _ in range(bars - 1):
        change = np.random.normal(0, 0.02) * prices[-1]
        prices.append(max(prices[-1] + change, 100))

    df = pd.DataFrame(index=dates)
    df["close"] = prices
    df["open"] = df["close"].shift(1).fillna(base_price)
    df["high"] = df[["open", "close"]].max(axis=1) * (1 + np.random.uniform(0, 0.01, bars))
    df["low"] = df[["open", "close"]].min(axis=1) * (1 - np.random.uniform(0, 0.01, bars))
    df["volume"] = np.random.uniform(100, 1000, bars) * (df["close"] / base_price)

    return df


@click.group()
@click.version_option(version="1.0.0", prog_name="tradingbot")
def cli():
    """Autonomous Trading Bot - Multi-strategy crypto trading."""
    pass


@cli.command()
@click.option("--exchange", "-e", default=settings.DEFAULT_EXCHANGE, help="Exchange to use")
@click.option("--symbol", "-s", default=settings.DEFAULT_SYMBOL, help="Trading pair")
@click.option("--style", type=click.Choice(["scalping", "intraday", "swing", "all"]), default="all")
@click.option("--interval", "-i", default=60, help="Poll interval in seconds")
@click.option("--paper/--live", default=True, help="Paper or live trading mode")
def run(exchange: str, symbol: str, style: str, interval: int, paper: bool):
    """Start the trading engine."""
    from core.engine import EngineConfig, TradingEngine
    from core.risk_manager import RiskManager

    if not paper and not settings.PAPER_MODE:
        console.print("[red]WARNING: LIVE TRADING MODE[/red]")
        if not click.confirm("Are you sure you want to trade with real money?"):
            return

    mode = "PAPER" if paper or settings.PAPER_MODE else "LIVE"
    console.print(f"[green]Starting Trading Bot ({mode} mode)[/green]")
    console.print(f"Exchange: {exchange} | Symbol: {symbol} | Style: {style}")

    connector = _get_connector(exchange)

    filter_style = style if style != "all" else None
    strategies = _get_strategies_by_style(filter_style)

    if not strategies:
        console.print("[red]No strategies found for the selected style[/red]")
        return

    console.print(f"Loaded {len(strategies)} strategies:")
    for s in strategies:
        console.print(f"  - {s.name} ({s.trading_style.value}/{s.timeframe})")

    risk_manager = RiskManager(
        portfolio_value=10000.0,
        sizing_method=settings.POSITION_SIZING_METHOD,
        max_position_pct=settings.MAX_POSITION_SIZE_PCT,
        max_open_positions=settings.MAX_OPEN_POSITIONS,
        max_daily_loss_pct=settings.MAX_DAILY_LOSS_PCT,
        max_drawdown_pct=settings.MAX_DRAWDOWN_PCT,
        min_risk_reward=settings.RISK_REWARD_MIN,
    )

    engine = TradingEngine(
        connector=connector,
        strategies=strategies,
        risk_manager=risk_manager,
        config=EngineConfig(
            symbols=[symbol],
            poll_interval_seconds=interval,
        ),
    )

    try:
        asyncio.run(engine.start())
    except KeyboardInterrupt:
        console.print("\n[yellow]Shutting down...[/yellow]")


@cli.command()
@click.option("--strategy", "-s", default=None, help="Strategy name to backtest (default: all)")
@click.option("--style", type=click.Choice(["scalping", "intraday", "swing"]), default=None)
@click.option("--symbol", default="BTC/USDT", help="Symbol to backtest")
@click.option("--bars", "-b", default=500, help="Number of bars for synthetic data")
@click.option("--capital", "-c", default=10000.0, help="Initial capital")
def backtest(strategy: Optional[str], style: Optional[str], symbol: str, bars: int, capital: float):
    """Run backtesting on historical/synthetic data."""
    from backtesting.engine import BacktestEngine

    console.print("[green]Starting Backtest[/green]")

    # Generate synthetic data
    df = _generate_synthetic_data(bars=bars)
    console.print(f"Generated {len(df)} bars of synthetic data")

    all_strats = _get_all_strategies()

    if strategy:
        # Find specific strategy
        target = [s for s in all_strats if s.name == strategy]
        if not target:
            console.print(f"[red]Strategy '{strategy}' not found[/red]")
            console.print("Available strategies:")
            for s in all_strats:
                console.print(f"  - {s.name}")
            return
        strats_to_test = [target[0]()]
    elif style:
        strats_to_test = [s() for s in all_strats if s.trading_style.value == style]
    else:
        strats_to_test = [s() for s in all_strats]

    results_table = Table(title="Backtest Results")
    results_table.add_column("Strategy", style="cyan")
    results_table.add_column("Style", style="magenta")
    results_table.add_column("Trades", justify="right")
    results_table.add_column("Win Rate", justify="right")
    results_table.add_column("Return %", justify="right")
    results_table.add_column("Sharpe", justify="right")
    results_table.add_column("Max DD %", justify="right")
    results_table.add_column("Profit Factor", justify="right")

    for strat in strats_to_test:
        console.print(f"  Backtesting {strat.name}...")

        engine = BacktestEngine(
            strategy=strat,
            df=df,
            initial_capital=capital,
        )

        result = engine.run(symbol=symbol)

        ret_color = "green" if result.total_return_pct > 0 else "red"
        results_table.add_row(
            strat.name,
            strat.trading_style.value,
            str(result.total_trades),
            f"{result.win_rate:.1f}%",
            f"[{ret_color}]{result.total_return_pct:+.2f}%[/{ret_color}]",
            f"{result.sharpe_ratio:.3f}",
            f"{result.max_drawdown_pct:.2f}%",
            f"{result.profit_factor:.2f}",
        )

    console.print()
    console.print(results_table)


@cli.command(name="strategies")
def list_strategies():
    """List all available trading strategies."""
    table = Table(title="Available Trading Strategies")
    table.add_column("#", justify="right", style="dim")
    table.add_column("Name", style="cyan")
    table.add_column("Style", style="magenta")
    table.add_column("Timeframe", style="green")
    table.add_column("Min Candles", justify="right")
    table.add_column("Description")

    all_strats = _get_all_strategies()

    for i, strat_cls in enumerate(all_strats, 1):
        table.add_row(
            str(i),
            strat_cls.name,
            strat_cls.trading_style.value,
            strat_cls.timeframe,
            str(strat_cls.min_candles),
            strat_cls.description,
        )

    console.print(table)
    console.print(f"\nTotal: {len(all_strats)} strategies "
                  f"(5 scalping, 5 intraday, 5 swing)")


@cli.command()
def status():
    """Show current configuration and bot status."""
    console.print("[bold]Trading Bot Status[/bold]\n")

    config_table = Table(title="Configuration")
    config_table.add_column("Setting", style="cyan")
    config_table.add_column("Value", style="green")

    config_table.add_row("Paper Mode", str(settings.PAPER_MODE))
    config_table.add_row("Test Mode", str(settings.TEST_MODE))
    config_table.add_row("Default Exchange", settings.DEFAULT_EXCHANGE)
    config_table.add_row("Default Symbol", settings.DEFAULT_SYMBOL)
    config_table.add_row("Position Sizing", settings.POSITION_SIZING_METHOD)
    config_table.add_row("Max Position %", f"{settings.MAX_POSITION_SIZE_PCT}%")
    config_table.add_row("Max Open Positions", str(settings.MAX_OPEN_POSITIONS))
    config_table.add_row("Max Daily Loss %", f"{settings.MAX_DAILY_LOSS_PCT}%")
    config_table.add_row("Max Drawdown %", f"{settings.MAX_DRAWDOWN_PCT}%")
    config_table.add_row("Min Risk/Reward", str(settings.RISK_REWARD_MIN))

    console.print(config_table)

    console.print("\n[bold]Timeframe Configuration[/bold]")
    tf_table = Table()
    tf_table.add_column("Style", style="magenta")
    tf_table.add_column("Timeframe")
    tf_table.add_column("Max Hold")
    tf_table.add_column("Stop Loss %")
    tf_table.add_column("Take Profit %")

    tf_table.add_row(
        "Scalping", settings.SCALP_TIMEFRAME,
        f"{settings.SCALP_MAX_HOLD_MINUTES} min",
        f"{settings.SCALP_STOP_LOSS_PCT}%", f"{settings.SCALP_TAKE_PROFIT_PCT}%",
    )
    tf_table.add_row(
        "Intraday", settings.INTRADAY_TIMEFRAME,
        f"{settings.INTRADAY_MAX_HOLD_HOURS} hrs",
        f"{settings.INTRADAY_STOP_LOSS_PCT}%", f"{settings.INTRADAY_TAKE_PROFIT_PCT}%",
    )
    tf_table.add_row(
        "Swing", settings.SWING_TIMEFRAME,
        f"{settings.SWING_MAX_HOLD_DAYS} days",
        f"{settings.SWING_STOP_LOSS_PCT}%", f"{settings.SWING_TAKE_PROFIT_PCT}%",
    )

    console.print(tf_table)

    # API key status
    console.print("\n[bold]API Keys[/bold]")
    keys_table = Table()
    keys_table.add_column("Exchange", style="cyan")
    keys_table.add_column("Status")

    binance_ok = bool(settings.BINANCE_API_KEY)
    coinbase_ok = bool(settings.COINBASE_API_KEY)
    dex_ok = bool(settings.WALLET_ADDRESS)

    keys_table.add_row("Binance", "[green]Configured[/green]" if binance_ok else "[yellow]Not set[/yellow]")
    keys_table.add_row("Coinbase", "[green]Configured[/green]" if coinbase_ok else "[yellow]Not set[/yellow]")
    keys_table.add_row("DEX (Uniswap)", "[green]Configured[/green]" if dex_ok else "[yellow]Not set[/yellow]")

    console.print(keys_table)


if __name__ == "__main__":
    cli()
