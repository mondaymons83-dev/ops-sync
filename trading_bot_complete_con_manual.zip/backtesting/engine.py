"""Backtesting Engine - Historical data replay and strategy evaluation.

Simulates trading on historical data to evaluate strategy performance.

Features:
- Historical candle replay
- Strategy signal generation and execution simulation
- Performance metrics: Sharpe ratio, Sortino ratio, max drawdown, etc.
- Trade-by-trade log
- Summary report with statistics

Usage:
    engine = BacktestEngine(strategy, df, initial_capital=10000)
    result = engine.run()
    result.print_summary()
"""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Any, Dict, List, Optional

import numpy as np
import pandas as pd

from core.risk_manager import RiskManager
from indicators.technical import atr
from strategies.base import BaseStrategy, Signal, SignalType, TradingStyle
from utils.logging import logger


@dataclass
class BacktestTrade:
    entry_time: Any
    exit_time: Any
    side: str  # "long" or "short"
    entry_price: float
    exit_price: float
    amount: float
    pnl: float
    pnl_pct: float
    strategy_name: str
    reason_entry: str
    reason_exit: str
    hold_bars: int = 0


@dataclass
class BacktestResult:
    # Summary
    strategy_name: str
    symbol: str
    timeframe: str
    start_date: str
    end_date: str
    initial_capital: float
    final_capital: float

    # Performance
    total_return_pct: float
    annual_return_pct: float
    sharpe_ratio: float
    sortino_ratio: float
    max_drawdown_pct: float
    max_drawdown_duration: int  # in bars

    # Trade stats
    total_trades: int
    winning_trades: int
    losing_trades: int
    win_rate: float
    avg_win_pct: float
    avg_loss_pct: float
    profit_factor: float
    avg_hold_bars: float
    largest_win: float
    largest_loss: float

    # Trade log
    trades: List[BacktestTrade] = field(default_factory=list)
    equity_curve: List[float] = field(default_factory=list)

    def print_summary(self) -> str:
        """Generate a formatted summary string."""
        lines = [
            "=" * 60,
            f"BACKTEST RESULTS: {self.strategy_name}",
            "=" * 60,
            f"Symbol: {self.symbol} | Timeframe: {self.timeframe}",
            f"Period: {self.start_date} to {self.end_date}",
            f"Initial Capital: ${self.initial_capital:,.2f}",
            f"Final Capital:   ${self.final_capital:,.2f}",
            "-" * 60,
            "PERFORMANCE",
            f"  Total Return:    {self.total_return_pct:+.2f}%",
            f"  Annual Return:   {self.annual_return_pct:+.2f}%",
            f"  Sharpe Ratio:    {self.sharpe_ratio:.3f}",
            f"  Sortino Ratio:   {self.sortino_ratio:.3f}",
            f"  Max Drawdown:    {self.max_drawdown_pct:.2f}%",
            f"  Max DD Duration: {self.max_drawdown_duration} bars",
            "-" * 60,
            "TRADES",
            f"  Total Trades:    {self.total_trades}",
            f"  Win Rate:        {self.win_rate:.1f}%",
            f"  Winning:         {self.winning_trades}",
            f"  Losing:          {self.losing_trades}",
            f"  Avg Win:         {self.avg_win_pct:+.2f}%",
            f"  Avg Loss:        {self.avg_loss_pct:+.2f}%",
            f"  Profit Factor:   {self.profit_factor:.2f}",
            f"  Avg Hold:        {self.avg_hold_bars:.1f} bars",
            f"  Largest Win:     {self.largest_win:+.2f}%",
            f"  Largest Loss:    {self.largest_loss:+.2f}%",
            "=" * 60,
        ]
        summary = "\n".join(lines)
        print(summary)
        return summary


class BacktestEngine:
    """Backtest a strategy on historical data."""

    def __init__(
        self,
        strategy: BaseStrategy,
        df: pd.DataFrame,
        initial_capital: float = 10000.0,
        commission_pct: float = 0.1,
        slippage_pct: float = 0.05,
        risk_manager: Optional[RiskManager] = None,
    ) -> None:
        self.strategy = strategy
        self.df = df.copy()
        self.initial_capital = initial_capital
        self.commission_pct = commission_pct
        self.slippage_pct = slippage_pct
        self.risk_manager = risk_manager or RiskManager(
            portfolio_value=initial_capital,
            sizing_method="fixed",
        )

        # State
        self._capital = initial_capital
        self._position: Optional[Dict] = None
        self._trades: List[BacktestTrade] = []
        self._equity_curve: List[float] = []

    def run(self, symbol: str = "BTC/USDT") -> BacktestResult:
        """Run the backtest."""
        logger.info(
            f"Starting backtest: {self.strategy.name} on {symbol}",
            extra={"action": "backtest_start"},
        )

        self._capital = self.initial_capital
        self._position = None
        self._trades = []
        self._equity_curve = [self.initial_capital]

        min_bars = max(self.strategy.min_candles, 50)

        for i in range(min_bars, len(self.df)):
            # Get historical window up to current bar
            window = self.df.iloc[:i + 1].copy()
            current_bar = self.df.iloc[i]
            current_price = float(current_bar["close"])

            # Track equity
            equity = self._capital
            if self._position:
                unrealized = self._calc_unrealized_pnl(current_price)
                equity += unrealized
            self._equity_curve.append(equity)

            # Generate signal
            try:
                signal = self.strategy.analyze(window, symbol)
            except Exception:
                continue

            # Process signal
            self._process_signal(signal, current_price, i, current_bar)

        # Close any remaining position at the end
        if self._position:
            final_price = float(self.df.iloc[-1]["close"])
            self._close_position(final_price, len(self.df) - 1, "backtest_end")

        return self._generate_result(symbol)

    def _process_signal(
        self, signal: Signal, current_price: float, bar_idx: int, bar: Any
    ) -> None:
        """Process a signal during backtesting."""

        # Handle exit signals
        if signal.is_exit and self._position:
            exit_price = self._apply_slippage(current_price, is_exit=True)
            self._close_position(exit_price, bar_idx, signal.reason)
            self.strategy.update_state_on_exit(exit_price)
            return

        # Handle entry signals
        if signal.is_entry and not self._position:
            if not self.strategy.should_enter(signal):
                return

            # Risk check
            if signal.entry_price and signal.stop_loss and signal.take_profit:
                atr_val = 0.0
                if bar_idx >= 14:
                    window = self.df.iloc[max(0, bar_idx - 20):bar_idx + 1]
                    try:
                        atr_val = float(atr(window, 14).iloc[-1])
                    except Exception:
                        pass

                risk_check = self.risk_manager.check_risk(
                    entry_price=signal.entry_price,
                    stop_loss=signal.stop_loss,
                    take_profit=signal.take_profit,
                    confidence=signal.confidence,
                    win_rate=self.strategy.win_rate,
                    atr_value=atr_val,
                )

                if not risk_check.approved:
                    return

                position_size = risk_check.position_size
            else:
                # Default: use 2% of capital
                position_size = (self._capital * 0.02) / current_price

            entry_price = self._apply_slippage(current_price, is_exit=False)
            cost = position_size * entry_price
            commission = cost * (self.commission_pct / 100)

            if cost + commission > self._capital:
                return  # Not enough capital

            self._capital -= commission
            self._position = {
                "side": "long" if signal.signal_type == SignalType.LONG else "short",
                "entry_price": entry_price,
                "amount": position_size,
                "entry_bar": bar_idx,
                "entry_time": bar.name if hasattr(bar, "name") else bar_idx,
                "stop_loss": signal.stop_loss,
                "take_profit": signal.take_profit,
                "reason": signal.reason,
            }

            self.strategy.update_state_on_entry(signal)
            self.risk_manager.on_position_opened()

        # Check stop loss / take profit for existing positions
        if self._position:
            high = float(self.df.iloc[bar_idx]["high"])
            low = float(self.df.iloc[bar_idx]["low"])

            if self._position["side"] == "long":
                if self._position.get("stop_loss") and low <= self._position["stop_loss"]:
                    self._close_position(self._position["stop_loss"], bar_idx, "stop_loss")
                    self.strategy.update_state_on_exit(self._position["stop_loss"] if self._position else current_price)
                elif self._position.get("take_profit") and high >= self._position["take_profit"]:
                    self._close_position(self._position["take_profit"], bar_idx, "take_profit")
                    self.strategy.update_state_on_exit(self._position["take_profit"] if self._position else current_price)
            else:  # short
                if self._position.get("stop_loss") and high >= self._position["stop_loss"]:
                    self._close_position(self._position["stop_loss"], bar_idx, "stop_loss")
                    self.strategy.update_state_on_exit(self._position["stop_loss"] if self._position else current_price)
                elif self._position.get("take_profit") and low <= self._position["take_profit"]:
                    self._close_position(self._position["take_profit"], bar_idx, "take_profit")
                    self.strategy.update_state_on_exit(self._position["take_profit"] if self._position else current_price)

    def _close_position(self, exit_price: float, bar_idx: int, reason: str) -> None:
        """Close the current position and record the trade."""
        if not self._position:
            return

        pos = self._position
        commission = pos["amount"] * exit_price * (self.commission_pct / 100)

        if pos["side"] == "long":
            pnl = (exit_price - pos["entry_price"]) * pos["amount"] - commission
        else:
            pnl = (pos["entry_price"] - exit_price) * pos["amount"] - commission

        pnl_pct = pnl / (pos["amount"] * pos["entry_price"]) * 100

        trade = BacktestTrade(
            entry_time=pos["entry_time"],
            exit_time=bar_idx,
            side=pos["side"],
            entry_price=pos["entry_price"],
            exit_price=exit_price,
            amount=pos["amount"],
            pnl=pnl,
            pnl_pct=pnl_pct,
            strategy_name=self.strategy.name,
            reason_entry=pos["reason"],
            reason_exit=reason,
            hold_bars=bar_idx - pos["entry_bar"],
        )

        self._trades.append(trade)
        self._capital += pnl
        self.risk_manager.on_position_closed(pnl)
        self._position = None

    def _calc_unrealized_pnl(self, current_price: float) -> float:
        """Calculate unrealized PnL for current position."""
        if not self._position:
            return 0.0

        if self._position["side"] == "long":
            return (current_price - self._position["entry_price"]) * self._position["amount"]
        else:
            return (self._position["entry_price"] - current_price) * self._position["amount"]

    def _apply_slippage(self, price: float, is_exit: bool) -> float:
        """Apply slippage to a price."""
        slip = price * (self.slippage_pct / 100)
        if is_exit:
            return price - slip  # Worse exit (sell lower / buy higher)
        return price + slip  # Worse entry (buy higher)

    def _generate_result(self, symbol: str) -> BacktestResult:
        """Generate the backtest result with all metrics."""
        equity = np.array(self._equity_curve)

        # Basic stats
        total_return = (self._capital - self.initial_capital) / self.initial_capital * 100
        n_bars = len(self.df)

        # Estimate annualized return (assume 365 days of 4h candles as default)
        bars_per_year = 365 * 6  # rough estimate for 4h
        if self.strategy.timeframe == "1m":
            bars_per_year = 365 * 24 * 60
        elif self.strategy.timeframe == "5m":
            bars_per_year = 365 * 24 * 12
        elif self.strategy.timeframe == "15m":
            bars_per_year = 365 * 24 * 4
        elif self.strategy.timeframe == "1h":
            bars_per_year = 365 * 24
        elif self.strategy.timeframe == "4h":
            bars_per_year = 365 * 6
        elif self.strategy.timeframe in ("1d", "daily"):
            bars_per_year = 365

        years = n_bars / max(bars_per_year, 1)
        annual_return = ((self._capital / self.initial_capital) ** (1 / max(years, 0.01)) - 1) * 100

        # Returns series
        returns = np.diff(equity) / equity[:-1] if len(equity) > 1 else np.array([0.0])

        # Sharpe ratio (annualized)
        if len(returns) > 1 and np.std(returns) > 0:
            sharpe = np.mean(returns) / np.std(returns) * np.sqrt(min(bars_per_year, 252))
        else:
            sharpe = 0.0

        # Sortino ratio (only downside deviation)
        downside = returns[returns < 0]
        if len(downside) > 1 and np.std(downside) > 0:
            sortino = np.mean(returns) / np.std(downside) * np.sqrt(min(bars_per_year, 252))
        else:
            sortino = 0.0

        # Max drawdown
        peak = np.maximum.accumulate(equity)
        drawdown = (peak - equity) / peak * 100
        max_dd = float(np.max(drawdown)) if len(drawdown) > 0 else 0.0

        # Max drawdown duration
        dd_duration = 0
        max_dd_duration = 0
        for i in range(len(drawdown)):
            if drawdown[i] > 0:
                dd_duration += 1
                max_dd_duration = max(max_dd_duration, dd_duration)
            else:
                dd_duration = 0

        # Trade statistics
        wins = [t for t in self._trades if t.pnl > 0]
        losses = [t for t in self._trades if t.pnl <= 0]

        avg_win = np.mean([t.pnl_pct for t in wins]) if wins else 0.0
        avg_loss = np.mean([t.pnl_pct for t in losses]) if losses else 0.0

        gross_profit = sum(t.pnl for t in wins)
        gross_loss = abs(sum(t.pnl for t in losses))
        profit_factor = gross_profit / max(gross_loss, 0.01)

        avg_hold = np.mean([t.hold_bars for t in self._trades]) if self._trades else 0.0

        largest_win = max((t.pnl_pct for t in self._trades), default=0.0)
        largest_loss = min((t.pnl_pct for t in self._trades), default=0.0)

        # Date range
        start_date = str(self.df.index[0]) if hasattr(self.df.index[0], "__str__") else "N/A"
        end_date = str(self.df.index[-1]) if hasattr(self.df.index[-1], "__str__") else "N/A"

        return BacktestResult(
            strategy_name=self.strategy.name,
            symbol=symbol,
            timeframe=self.strategy.timeframe,
            start_date=start_date,
            end_date=end_date,
            initial_capital=self.initial_capital,
            final_capital=round(self._capital, 2),
            total_return_pct=round(total_return, 2),
            annual_return_pct=round(annual_return, 2),
            sharpe_ratio=round(float(sharpe), 3),
            sortino_ratio=round(float(sortino), 3),
            max_drawdown_pct=round(max_dd, 2),
            max_drawdown_duration=max_dd_duration,
            total_trades=len(self._trades),
            winning_trades=len(wins),
            losing_trades=len(losses),
            win_rate=round(len(wins) / max(len(self._trades), 1) * 100, 1),
            avg_win_pct=round(float(avg_win), 2),
            avg_loss_pct=round(float(avg_loss), 2),
            profit_factor=round(profit_factor, 2),
            avg_hold_bars=round(float(avg_hold), 1),
            largest_win=round(largest_win, 2),
            largest_loss=round(largest_loss, 2),
            trades=self._trades,
            equity_curve=self._equity_curve,
        )
