"""Backtesting engine for strategy evaluation."""

from backtesting.engine import BacktestEngine, BacktestResult

__all__ = [
    "BacktestEngine",
    "BacktestResult",
]
