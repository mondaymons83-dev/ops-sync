"""Coinbase CEX connector using ccxt."""

from __future__ import annotations

from datetime import datetime, timezone
from typing import Any, Dict, List, Optional

import ccxt.async_support as ccxt

from app.config import settings
from connectors.base import (
    Balance,
    BaseConnector,
    Candle,
    OrderResult,
    OrderSide,
    OrderStatus,
    OrderType,
    Ticker,
)
from utils.logging import logger


class CoinbaseConnector(BaseConnector):
    name = "coinbase"
    connector_type = "cex"

    def __init__(self) -> None:
        self._exchange: Optional[ccxt.coinbase] = None

    async def connect(self) -> None:
        config: Dict[str, Any] = {
            "apiKey": settings.COINBASE_API_KEY,
            "secret": settings.COINBASE_API_SECRET,
            "enableRateLimit": True,
        }
        if settings.COINBASE_PASSPHRASE:
            config["password"] = settings.COINBASE_PASSPHRASE
        if settings.PAPER_MODE:
            config["sandbox"] = True

        self._exchange = ccxt.coinbase(config)
        if settings.PAPER_MODE:
            self._exchange.set_sandbox_mode(True)
        await self._exchange.load_markets()
        logger.info(f"Connected to Coinbase ({'sandbox' if settings.PAPER_MODE else 'live'})")

    async def disconnect(self) -> None:
        if self._exchange:
            await self._exchange.close()

    @property
    def exchange(self) -> ccxt.coinbase:
        if self._exchange is None:
            raise RuntimeError("Coinbase connector not connected.")
        return self._exchange

    async def get_ticker(self, symbol: str) -> Ticker:
        data = await self.exchange.fetch_ticker(symbol)
        return Ticker(
            symbol=symbol,
            bid=float(data.get("bid", 0) or 0),
            ask=float(data.get("ask", 0) or 0),
            last=float(data.get("last", 0) or 0),
            volume_24h=float(data.get("quoteVolume", 0) or 0),
            timestamp=datetime.now(timezone.utc),
        )

    async def get_candles(
        self, symbol: str, timeframe: str = "1h", limit: int = 100
    ) -> List[Candle]:
        ohlcv = await self.exchange.fetch_ohlcv(symbol, timeframe, limit=limit)
        return [
            Candle(
                timestamp=datetime.fromtimestamp(r[0] / 1000, tz=timezone.utc),
                open=float(r[1]),
                high=float(r[2]),
                low=float(r[3]),
                close=float(r[4]),
                volume=float(r[5]),
            )
            for r in ohlcv
        ]

    async def get_balance(self, currency: str = "USDT") -> Balance:
        if settings.TEST_MODE:
            return Balance(currency=currency, free=10000.0, used=0.0, total=10000.0)
        bal = await self.exchange.fetch_balance()
        c = bal.get(currency, {})
        return Balance(
            currency=currency,
            free=float(c.get("free", 0) or 0),
            used=float(c.get("used", 0) or 0),
            total=float(c.get("total", 0) or 0),
        )

    async def place_order(
        self,
        symbol: str,
        side: OrderSide,
        order_type: OrderType,
        amount: float,
        price: Optional[float] = None,
        params: Optional[Dict[str, Any]] = None,
    ) -> OrderResult:
        if settings.PAPER_MODE or settings.TEST_MODE:
            logger.info(f"[PAPER] {side.value} {amount} {symbol} @ {price or 'market'}")
            return OrderResult(
                order_id=f"paper_{int(datetime.now(timezone.utc).timestamp()*1000)}",
                symbol=symbol,
                side=side,
                order_type=order_type,
                status=OrderStatus.FILLED,
                price=price or 0.0,
                amount=amount,
                filled=amount,
                cost=amount * (price or 0.0),
            )

        ccxt_type = "market" if order_type == OrderType.MARKET else "limit"
        result = await self.exchange.create_order(
            symbol, ccxt_type, side.value, amount, price, params or {}
        )
        return OrderResult(
            order_id=str(result.get("id", "")),
            symbol=symbol,
            side=side,
            order_type=order_type,
            status=OrderStatus.OPEN,
            price=float(result.get("price", 0) or 0),
            amount=amount,
            filled=float(result.get("filled", 0) or 0),
            raw=result,
        )

    async def cancel_order(self, order_id: str, symbol: str) -> bool:
        try:
            await self.exchange.cancel_order(order_id, symbol)
            return True
        except Exception as e:
            logger.error(f"Cancel failed: {e}")
            return False

    async def get_order(self, order_id: str, symbol: str) -> OrderResult:
        data = await self.exchange.fetch_order(order_id, symbol)
        return OrderResult(
            order_id=str(data["id"]),
            symbol=symbol,
            side=OrderSide(data["side"]),
            order_type=OrderType.MARKET,
            status=OrderStatus.FILLED if data["status"] == "closed" else OrderStatus.OPEN,
            price=float(data.get("price", 0) or 0),
            amount=float(data.get("amount", 0) or 0),
            filled=float(data.get("filled", 0) or 0),
            raw=data,
        )

    async def get_open_orders(self, symbol: Optional[str] = None) -> List[OrderResult]:
        orders = await self.exchange.fetch_open_orders(symbol)
        return [
            OrderResult(
                order_id=str(o["id"]),
                symbol=o["symbol"],
                side=OrderSide(o["side"]),
                order_type=OrderType.LIMIT,
                status=OrderStatus.OPEN,
                price=float(o.get("price", 0) or 0),
                amount=float(o.get("amount", 0) or 0),
                raw=o,
            )
            for o in orders
        ]

    async def get_orderbook(
        self, symbol: str, limit: int = 20
    ) -> Dict[str, List[List[float]]]:
        book = await self.exchange.fetch_order_book(symbol, limit)
        return {"bids": book["bids"], "asks": book["asks"]}
