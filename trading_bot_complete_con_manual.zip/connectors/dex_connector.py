"""Generic DEX connector using Web3 for Uniswap-compatible DEXes."""

from __future__ import annotations

import json
import time
from datetime import datetime, timezone
from typing import Any, Dict, List, Optional

from app.config import settings
from connectors.base import (
    Balance,
    BaseConnector,
    Candle,
    OrderResult,
    OrderSide,
    OrderStatus,
    OrderType,
    Ticker,
)
from utils.logging import logger

# Uniswap V2 Router ABI (minimal)
ROUTER_ABI = json.loads(
    '[{"inputs":[{"internalType":"uint256","name":"amountIn","type":"uint256"},'
    '{"internalType":"address[]","name":"path","type":"address[]"}],'
    '"name":"getAmountsOut","outputs":[{"internalType":"uint256[]",'
    '"name":"amounts","type":"uint256[]"}],"stateMutability":"view",'
    '"type":"function"},'
    '{"inputs":[{"internalType":"uint256","name":"amountOutMin","type":"uint256"},'
    '{"internalType":"address[]","name":"path","type":"address[]"},'
    '{"internalType":"address","name":"to","type":"address"},'
    '{"internalType":"uint256","name":"deadline","type":"uint256"}],'
    '"name":"swapExactETHForTokens","outputs":[{"internalType":"uint256[]",'
    '"name":"amounts","type":"uint256[]"}],"stateMutability":"payable",'
    '"type":"function"},'
    '{"inputs":[{"internalType":"uint256","name":"amountIn","type":"uint256"},'
    '{"internalType":"uint256","name":"amountOutMin","type":"uint256"},'
    '{"internalType":"address[]","name":"path","type":"address[]"},'
    '{"internalType":"address","name":"to","type":"address"},'
    '{"internalType":"uint256","name":"deadline","type":"uint256"}],'
    '"name":"swapExactTokensForETH","outputs":[{"internalType":"uint256[]",'
    '"name":"amounts","type":"uint256[]"}],"stateMutability":"nonpayable",'
    '"type":"function"}]'
)

# ERC20 minimal ABI
ERC20_ABI = json.loads(
    '[{"constant":true,"inputs":[{"name":"_owner","type":"address"}],'
    '"name":"balanceOf","outputs":[{"name":"balance","type":"uint256"}],'
    '"type":"function"},'
    '{"constant":true,"inputs":[],"name":"decimals",'
    '"outputs":[{"name":"","type":"uint8"}],"type":"function"},'
    '{"constant":false,"inputs":[{"name":"_spender","type":"address"},'
    '{"name":"_value","type":"uint256"}],"name":"approve",'
    '"outputs":[{"name":"","type":"bool"}],"type":"function"}]'
)

# Common token addresses (Ethereum mainnet)
TOKEN_ADDRESSES = {
    "WETH": "0xC02aaA39b223FE8D0A0e5C4F27eAD9083C756Cc2",
    "USDT": "0xdAC17F958D2ee523a2206206994597C13D831ec7",
    "USDC": "0xA0b86991c6218b36c1d19D4a2e9Eb0cE3606eB48",
    "DAI": "0x6B175474E89094C44Da98b954EedeAC495271d0F",
    "WBTC": "0x2260FAC5E5542a773Aa44fBCfeDf7C193bc2C599",
    "UNI": "0x1f9840a85d5aF5bf1D1762F925BDADdC4201F984",
    "LINK": "0x514910771AF9Ca656af840dff83E8264EcF986CA",
    "AAVE": "0x7Fc66500c84A76Ad7e9c93437bFc5Ac33E2DDaE9",
}


class DexConnector(BaseConnector):
    """DEX connector for Uniswap V2-compatible decentralized exchanges."""

    name = "uniswap"
    connector_type = "dex"

    def __init__(self) -> None:
        self._w3 = None
        self._router = None
        self._account = None

    async def connect(self) -> None:
        try:
            from web3 import Web3

            self._w3 = Web3(Web3.HTTPProvider(settings.WEB3_RPC_URL))
            if not self._w3.is_connected():
                logger.warning("Web3 RPC not connected, DEX trading disabled")
                return

            self._router = self._w3.eth.contract(
                address=Web3.to_checksum_address(settings.UNISWAP_ROUTER),
                abi=ROUTER_ABI,
            )
            if settings.WALLET_PRIVATE_KEY:
                self._account = self._w3.eth.account.from_key(
                    settings.WALLET_PRIVATE_KEY
                )
            logger.info("Connected to DEX via Web3")
        except Exception as e:
            logger.warning(f"DEX connection failed: {e}")

    async def disconnect(self) -> None:
        self._w3 = None
        self._router = None

    async def get_ticker(self, symbol: str) -> Ticker:
        """Get price from Uniswap pool. Symbol format: TOKEN/WETH"""
        if settings.TEST_MODE or self._w3 is None:
            return Ticker(
                symbol=symbol,
                bid=1800.0,
                ask=1801.0,
                last=1800.50,
                volume_24h=1000000.0,
                timestamp=datetime.now(timezone.utc),
            )

        base, quote = symbol.split("/")
        base_addr = TOKEN_ADDRESSES.get(base, base)
        quote_addr = TOKEN_ADDRESSES.get(quote, quote)
        from web3 import Web3

        path = [
            Web3.to_checksum_address(base_addr),
            Web3.to_checksum_address(quote_addr),
        ]
        try:
            amounts = self._router.functions.getAmountsOut(
                10**18, path
            ).call()
            price = amounts[1] / 10**6  # Assumes 6 decimal quote
            return Ticker(
                symbol=symbol,
                bid=price * 0.999,
                ask=price * 1.001,
                last=price,
                volume_24h=0,
                timestamp=datetime.now(timezone.utc),
            )
        except Exception as e:
            logger.error(f"DEX ticker error: {e}")
            return Ticker(
                symbol=symbol, bid=0, ask=0, last=0, volume_24h=0,
                timestamp=datetime.now(timezone.utc),
            )

    async def get_candles(
        self, symbol: str, timeframe: str = "1h", limit: int = 100
    ) -> List[Candle]:
        """DEX candles via synthetic generation (real implementation would use subgraph)."""
        import random

        candles = []
        base_price = 1800.0
        now = datetime.now(timezone.utc)

        for i in range(limit):
            delta = random.uniform(-20, 20)
            o = base_price + delta
            h = o + random.uniform(0, 30)
            l = o - random.uniform(0, 30)
            c = o + random.uniform(-15, 15)
            base_price = c
            candles.append(
                Candle(
                    timestamp=now,
                    open=o, high=max(o, h, c), low=min(o, l, c),
                    close=c, volume=random.uniform(100, 5000),
                )
            )
        return candles

    async def get_balance(self, currency: str = "ETH") -> Balance:
        if settings.TEST_MODE or self._w3 is None:
            return Balance(currency=currency, free=10.0, used=0.0, total=10.0)

        from web3 import Web3

        addr = Web3.to_checksum_address(
            settings.WALLET_ADDRESS or (self._account.address if self._account else "0x0")
        )
        if currency == "ETH":
            bal = self._w3.eth.get_balance(addr)
            eth_bal = float(Web3.from_wei(bal, "ether"))
            return Balance(currency="ETH", free=eth_bal, used=0, total=eth_bal)

        token_addr = TOKEN_ADDRESSES.get(currency)
        if token_addr:
            contract = self._w3.eth.contract(
                address=Web3.to_checksum_address(token_addr), abi=ERC20_ABI
            )
            decimals = contract.functions.decimals().call()
            raw_bal = contract.functions.balanceOf(addr).call()
            bal = raw_bal / (10**decimals)
            return Balance(currency=currency, free=bal, used=0, total=bal)

        return Balance(currency=currency, free=0, used=0, total=0)

    async def place_order(
        self,
        symbol: str,
        side: OrderSide,
        order_type: OrderType,
        amount: float,
        price: Optional[float] = None,
        params: Optional[Dict[str, Any]] = None,
    ) -> OrderResult:
        if settings.PAPER_MODE or settings.TEST_MODE:
            logger.info(f"[PAPER-DEX] {side.value} {amount} {symbol}")
            return OrderResult(
                order_id=f"dex_paper_{int(time.time()*1000)}",
                symbol=symbol,
                side=side,
                order_type=order_type,
                status=OrderStatus.FILLED,
                price=price or 0,
                amount=amount,
                filled=amount,
            )

        if self._w3 is None or self._account is None:
            raise RuntimeError("DEX not connected or wallet not configured")

        from web3 import Web3

        base, quote = symbol.split("/")
        slippage = (params or {}).get("slippage", 0.5) / 100
        deadline = int(time.time()) + 300

        base_addr = Web3.to_checksum_address(TOKEN_ADDRESSES.get(base, base))
        quote_addr = Web3.to_checksum_address(TOKEN_ADDRESSES.get(quote, quote))

        if side == OrderSide.BUY:
            amount_wei = Web3.to_wei(amount, "ether")
            path = [quote_addr, base_addr]
            amounts_out = self._router.functions.getAmountsOut(amount_wei, path).call()
            min_out = int(amounts_out[-1] * (1 - slippage))

            tx = self._router.functions.swapExactETHForTokens(
                min_out, path, self._account.address, deadline
            ).build_transaction({
                "from": self._account.address,
                "value": amount_wei,
                "gas": 300000,
                "gasPrice": self._w3.eth.gas_price,
                "nonce": self._w3.eth.get_transaction_count(self._account.address),
            })
        else:
            # Sell tokens for ETH
            token = self._w3.eth.contract(address=base_addr, abi=ERC20_ABI)
            decimals = token.functions.decimals().call()
            amount_raw = int(amount * (10**decimals))

            # Approve first
            approve_tx = token.functions.approve(
                Web3.to_checksum_address(settings.UNISWAP_ROUTER), amount_raw
            ).build_transaction({
                "from": self._account.address,
                "gas": 100000,
                "gasPrice": self._w3.eth.gas_price,
                "nonce": self._w3.eth.get_transaction_count(self._account.address),
            })
            signed_approve = self._w3.eth.account.sign_transaction(
                approve_tx, self._account.key
            )
            self._w3.eth.send_raw_transaction(signed_approve.raw_transaction)

            path = [base_addr, quote_addr]
            amounts_out = self._router.functions.getAmountsOut(amount_raw, path).call()
            min_out = int(amounts_out[-1] * (1 - slippage))

            tx = self._router.functions.swapExactTokensForETH(
                amount_raw, min_out, path, self._account.address, deadline
            ).build_transaction({
                "from": self._account.address,
                "gas": 300000,
                "gasPrice": self._w3.eth.gas_price,
                "nonce": self._w3.eth.get_transaction_count(self._account.address) + 1,
            })

        signed = self._w3.eth.account.sign_transaction(tx, self._account.key)
        tx_hash = self._w3.eth.send_raw_transaction(signed.raw_transaction)
        receipt = self._w3.eth.wait_for_transaction_receipt(tx_hash, timeout=120)

        return OrderResult(
            order_id=tx_hash.hex(),
            symbol=symbol,
            side=side,
            order_type=OrderType.MARKET,
            status=OrderStatus.FILLED if receipt["status"] == 1 else OrderStatus.FAILED,
            price=price or 0,
            amount=amount,
            filled=amount if receipt["status"] == 1 else 0,
            raw=dict(receipt),
        )

    async def cancel_order(self, order_id: str, symbol: str) -> bool:
        logger.warning("DEX orders cannot be cancelled after submission")
        return False

    async def get_order(self, order_id: str, symbol: str) -> OrderResult:
        return OrderResult(
            order_id=order_id,
            symbol=symbol,
            side=OrderSide.BUY,
            order_type=OrderType.MARKET,
            status=OrderStatus.FILLED,
            price=0,
            amount=0,
        )

    async def get_open_orders(self, symbol: Optional[str] = None) -> List[OrderResult]:
        return []  # DEX has no open orders concept

    async def get_orderbook(
        self, symbol: str, limit: int = 20
    ) -> Dict[str, List[List[float]]]:
        # DEX doesn't have traditional orderbook
        return {"bids": [], "asks": []}
