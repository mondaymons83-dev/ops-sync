# Trading Bot - Autonomous Multi-Strategy CEX/DEX Trading

Bot de trading automatizado con 15+ estrategias basadas en Elliott Waves, Análisis Técnico y principios de Trading en la Zona.

## Estado actual: EN PROGRESO (~50%)

### Completado
- Estructura del proyecto y dependencias (Poetry)
- Configuración centralizada (.env)
- Logging estructurado JSON
- **Conectores de exchange:**
  - Binance CEX (via ccxt) con paper trading
  - Coinbase CEX (via ccxt) con paper trading
  - DEX genérico (Uniswap V2 via Web3) con swaps on-chain
- **Indicadores técnicos completos:**
  - RSI, MACD, Bollinger Bands, EMA, SMA, WMA
  - ATR, Stochastic, VWAP, OBV, ADX
  - Ichimoku Cloud, Pivot Points, Donchian Channel
  - Money Flow Index, Accumulation/Distribution
- **Detección de Elliott Waves:**
  - Identificación automática de patrones 5-wave
  - Validación de reglas (Wave 2/3/4)
  - Cálculo de targets con Fibonacci
- **Fibonacci completo:**
  - Retracimientos (23.6%, 38.2%, 50%, 61.8%, 78.6%)
  - Extensiones (100%, 127.2%, 161.8%, 200%, 261.8%)
  - Detección automática de swing points
- **Reconocimiento de patrones:**
  - Head & Shoulders / Inverse H&S
  - Double Top/Bottom
  - Triangles (ascending, descending, symmetrical)
  - Flags (bull/bear)
  - Wedges (rising/falling)
- **Análisis de volumen:**
  - Volume Profile, MFI, VWMACD
  - Accumulation/Distribution, divergencias
- **5 Estrategias de Scalping (completas):**
  1. EMA Crossover Scalp
  2. Bollinger Band Bounce Scalp
  3. VWAP Mean Reversion Scalp
  4. Order Book Imbalance Scalp
  5. Momentum Burst Scalp
- **Base Strategy class** con state tracking, win rate, PnL

### Pendiente
- 5 Estrategias Intraday:
  1. Support/Resistance Breakout
  2. Elliott Wave Impulse Entry
  3. Moving Average Ribbon
  4. Fibonacci Retracement Entry
  5. Chart Pattern Detection
- 5 Estrategias Swing:
  1. Elliott Wave Full Cycle
  2. Golden/Death Cross
  3. Multi-Timeframe Trend
  4. Divergence Trading
  5. Flag/Pennant Breakout
- Risk Manager (position sizing: Kelly/Fixed/ATR)
- Trading Engine (signal → execution pipeline)
- Order Manager (tracking, trailing stops)
- Backtesting Engine
- CLI Interface
- Test mode end-to-end

## Setup

```bash
cd trading_bot
poetry install
cp .env.example .env  # editar con tus API keys
```

## Estructura

```
trading_bot/
├── app/              # Config, CLI (pendiente)
├── connectors/       # CEX (Binance, Coinbase) + DEX (Uniswap)
├── indicators/       # Technical, Elliott Wave, Fibonacci, Patterns, Volume
├── strategies/       # Base + Scalping (5) + Intraday (pendiente) + Swing (pendiente)
├── core/             # Engine, Risk Manager (pendiente)
├── data/             # Data feeds (pendiente)
├── backtesting/      # Backtest engine (pendiente)
├── utils/            # Logging
└── logs/             # Trading logs
```
