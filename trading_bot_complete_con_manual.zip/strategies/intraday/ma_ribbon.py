"""Moving Average Ribbon Intraday Strategy.

Uses a ribbon of EMAs (8, 13, 21, 34, 55) to determine trend direction
and strength. When all EMAs are fanning out in order, the trend is strong.

Based on Technical Analysis Guide principles:
- Fan-out = strong trend, enter on pullbacks to first EMA
- Convergence = trend weakening, prepare to exit
- Crossover = trend reversal

Timeframe: 15m
Hold time: 2-8 hours

Entry Long: All EMAs in bullish order (8>13>21>34>55) + price pulls back to EMA8/13
Entry Short: All EMAs in bearish order (8<13<21<34<55) + price pulls back to EMA8/13
Exit: EMAs start converging or ribbon order breaks
"""

from __future__ import annotations

import pandas as pd

from indicators.technical import atr, ema, rsi
from strategies.base import BaseStrategy, Signal, SignalType, TradingStyle


class MARibbonIntraday(BaseStrategy):
    name = "ma_ribbon_intraday"
    description = "Moving Average Ribbon fan-out/convergence trend trading"
    trading_style = TradingStyle.INTRADAY
    timeframe = "15m"
    min_candles = 60

    ribbon_periods = [8, 13, 21, 34, 55]
    pullback_tolerance_atr: float = 0.5

    def analyze(self, df: pd.DataFrame, symbol: str) -> Signal:
        if len(df) < self.min_candles:
            return Signal(
                signal_type=SignalType.HOLD, symbol=symbol,
                strategy_name=self.name, confidence=0,
            )

        close = df["close"]
        current_price = float(close.iloc[-1])
        atr_val = float(atr(df, 14).iloc[-1])
        rsi_val = float(rsi(close, 14).iloc[-1])

        # Calculate ribbon EMAs
        emas = {}
        for period in self.ribbon_periods:
            emas[period] = ema(close, period)

        current_emas = {p: float(emas[p].iloc[-1]) for p in self.ribbon_periods}
        prev_emas = {p: float(emas[p].iloc[-2]) for p in self.ribbon_periods}

        ema_values = [current_emas[p] for p in self.ribbon_periods]

        # Check if EMAs are in perfect bullish order
        bullish_order = all(
            ema_values[i] > ema_values[i + 1]
            for i in range(len(ema_values) - 1)
        )

        # Check if EMAs are in perfect bearish order
        bearish_order = all(
            ema_values[i] < ema_values[i + 1]
            for i in range(len(ema_values) - 1)
        )

        # Calculate ribbon spread (fan-out strength)
        ribbon_spread = abs(ema_values[0] - ema_values[-1]) / current_price
        is_fanning = ribbon_spread > 0.005  # >0.5% spread

        # Check for pullback to fast EMAs
        distance_to_ema8 = abs(current_price - current_emas[8]) / atr_val
        distance_to_ema13 = abs(current_price - current_emas[13]) / atr_val

        is_pullback_to_ribbon = distance_to_ema8 < self.pullback_tolerance_atr or distance_to_ema13 < self.pullback_tolerance_atr

        # Bullish entry: ribbon in order + pullback + not overbought
        if bullish_order and is_fanning:
            if is_pullback_to_ribbon and current_price > current_emas[8] and rsi_val < 70:
                confidence = 0.55
                if ribbon_spread > 0.01:
                    confidence += 0.1  # Strong fan-out
                if rsi_val < 60:
                    confidence += 0.05
                if distance_to_ema8 < 0.3:
                    confidence += 0.1  # Clean pullback

                return Signal(
                    signal_type=SignalType.LONG,
                    symbol=symbol,
                    strategy_name=self.name,
                    confidence=min(confidence, 0.85),
                    entry_price=current_price,
                    stop_loss=current_emas[21] - atr_val * 0.5,
                    take_profit=current_price + atr_val * 3,
                    reason=f"MA Ribbon bullish fan-out, pullback to EMA8, spread={ribbon_spread:.4f}",
                    metadata={"ribbon_spread": ribbon_spread, "ema_order": "bullish"},
                )

        # Bearish entry: ribbon in order + pullback + not oversold
        if bearish_order and is_fanning:
            if is_pullback_to_ribbon and current_price < current_emas[8] and rsi_val > 30:
                confidence = 0.55
                if ribbon_spread > 0.01:
                    confidence += 0.1
                if rsi_val > 40:
                    confidence += 0.05
                if distance_to_ema8 < 0.3:
                    confidence += 0.1

                return Signal(
                    signal_type=SignalType.SHORT,
                    symbol=symbol,
                    strategy_name=self.name,
                    confidence=min(confidence, 0.85),
                    entry_price=current_price,
                    stop_loss=current_emas[21] + atr_val * 0.5,
                    take_profit=current_price - atr_val * 3,
                    reason=f"MA Ribbon bearish fan-out, pullback to EMA8, spread={ribbon_spread:.4f}",
                    metadata={"ribbon_spread": ribbon_spread, "ema_order": "bearish"},
                )

        # Exit: ribbon converging
        if self.state.in_position:
            prev_spread = abs(prev_emas[self.ribbon_periods[0]] - prev_emas[self.ribbon_periods[-1]]) / float(close.iloc[-2])
            converging = ribbon_spread < prev_spread * 0.8

            if self.state.position_side == SignalType.LONG:
                if not bullish_order or converging:
                    return Signal(
                        signal_type=SignalType.EXIT_LONG, symbol=symbol,
                        strategy_name=self.name, confidence=0.7,
                        reason="MA Ribbon order broken or converging",
                    )
            if self.state.position_side == SignalType.SHORT:
                if not bearish_order or converging:
                    return Signal(
                        signal_type=SignalType.EXIT_SHORT, symbol=symbol,
                        strategy_name=self.name, confidence=0.7,
                        reason="MA Ribbon order broken or converging",
                    )

        return Signal(
            signal_type=SignalType.HOLD, symbol=symbol,
            strategy_name=self.name, confidence=0,
        )
