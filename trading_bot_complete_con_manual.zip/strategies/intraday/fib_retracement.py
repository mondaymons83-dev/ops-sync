"""Fibonacci Retracement Entry Intraday Strategy.

Based on the Technical Analysis Guide and Elliott Wave principles:
- Key retracement levels: 38.2%, 50%, 61.8%
- Enter when price bounces from a Fibonacci level with confirmation
- 61.8% is the "golden ratio" - strongest level
- Use RSI and candlestick patterns for confirmation

Timeframe: 15m
Hold time: 2-8 hours

Entry Long: Price at/near Fib support (38.2-61.8% retrace) + RSI oversold + bullish candle
Entry Short: Price at/near Fib resistance (38.2-61.8% retrace) + RSI overbought + bearish candle
Exit: Next Fib extension level or opposite signal
"""

from __future__ import annotations

import pandas as pd

from indicators.fibonacci import auto_fibonacci, nearest_fib_level
from indicators.technical import atr, rsi, ema
from strategies.base import BaseStrategy, Signal, SignalType, TradingStyle


class FibRetracementIntraday(BaseStrategy):
    name = "fib_retracement_intraday"
    description = "Trade bounces from Fibonacci retracement levels"
    trading_style = TradingStyle.INTRADAY
    timeframe = "15m"
    min_candles = 60

    fib_tolerance_pct: float = 0.5
    rsi_period: int = 14

    def analyze(self, df: pd.DataFrame, symbol: str) -> Signal:
        if len(df) < self.min_candles:
            return Signal(
                signal_type=SignalType.HOLD, symbol=symbol,
                strategy_name=self.name, confidence=0,
            )

        close = df["close"]
        current_price = float(close.iloc[-1])
        prev_price = float(close.iloc[-2])
        atr_val = float(atr(df, 14).iloc[-1])
        rsi_val = float(rsi(close, self.rsi_period).iloc[-1])
        ema_21 = float(ema(close, 21).iloc[-1])

        # Get Fibonacci levels
        fib = auto_fibonacci(df, lookback=5)
        near_level = nearest_fib_level(current_price, fib, self.fib_tolerance_pct)

        if near_level is None:
            # Check if we should exit
            if self.state.in_position:
                return self._check_exit(df, symbol, current_price, fib, atr_val)
            return Signal(
                signal_type=SignalType.HOLD, symbol=symbol,
                strategy_name=self.name, confidence=0,
            )

        # Determine if this is a support or resistance level based on trend direction
        is_uptrend = fib.direction == "up"

        # Bullish bounce from Fib support in uptrend
        if is_uptrend and current_price <= near_level.price * 1.005:
            # Candlestick confirmation: current candle bullish
            current_open = float(df["open"].iloc[-1])
            is_bullish_candle = current_price > current_open

            if is_bullish_candle and rsi_val < 55:
                confidence = 0.5

                # Golden ratio (61.8%) is strongest
                if abs(near_level.ratio - 0.618) < 0.05:
                    confidence += 0.2
                elif abs(near_level.ratio - 0.5) < 0.05:
                    confidence += 0.15
                elif abs(near_level.ratio - 0.382) < 0.05:
                    confidence += 0.1

                # RSI support
                if rsi_val < 40:
                    confidence += 0.1

                # Price above trend EMA
                if current_price > ema_21:
                    confidence += 0.05

                # Calculate targets from extension levels
                take_profit = current_price + atr_val * 3
                for ext in fib.extension_levels:
                    if ext.price > current_price:
                        take_profit = ext.price
                        break

                return Signal(
                    signal_type=SignalType.LONG,
                    symbol=symbol,
                    strategy_name=self.name,
                    confidence=min(confidence, 0.85),
                    entry_price=current_price,
                    stop_loss=current_price - atr_val * 1.5,
                    take_profit=take_profit,
                    reason=f"Fib bounce at {near_level.label} ({near_level.price:.2f}), RSI={rsi_val:.1f}",
                    metadata={
                        "fib_level": near_level.ratio,
                        "fib_price": near_level.price,
                        "direction": fib.direction,
                    },
                )

        # Bearish bounce from Fib resistance in downtrend
        if not is_uptrend and current_price >= near_level.price * 0.995:
            current_open = float(df["open"].iloc[-1])
            is_bearish_candle = current_price < current_open

            if is_bearish_candle and rsi_val > 45:
                confidence = 0.5

                if abs(near_level.ratio - 0.618) < 0.05:
                    confidence += 0.2
                elif abs(near_level.ratio - 0.5) < 0.05:
                    confidence += 0.15
                elif abs(near_level.ratio - 0.382) < 0.05:
                    confidence += 0.1

                if rsi_val > 60:
                    confidence += 0.1

                if current_price < ema_21:
                    confidence += 0.05

                take_profit = current_price - atr_val * 3
                for ext in fib.extension_levels:
                    if ext.price < current_price:
                        take_profit = ext.price
                        break

                return Signal(
                    signal_type=SignalType.SHORT,
                    symbol=symbol,
                    strategy_name=self.name,
                    confidence=min(confidence, 0.85),
                    entry_price=current_price,
                    stop_loss=current_price + atr_val * 1.5,
                    take_profit=take_profit,
                    reason=f"Fib rejection at {near_level.label} ({near_level.price:.2f}), RSI={rsi_val:.1f}",
                    metadata={
                        "fib_level": near_level.ratio,
                        "fib_price": near_level.price,
                        "direction": fib.direction,
                    },
                )

        # Check exit for existing position
        if self.state.in_position:
            return self._check_exit(df, symbol, current_price, fib, atr_val)

        return Signal(
            signal_type=SignalType.HOLD, symbol=symbol,
            strategy_name=self.name, confidence=0,
        )

    def _check_exit(self, df: pd.DataFrame, symbol: str, current_price: float, fib, atr_val: float) -> Signal:
        """Check if current position should be exited based on Fib levels."""
        if not self.state.in_position:
            return Signal(
                signal_type=SignalType.HOLD, symbol=symbol,
                strategy_name=self.name, confidence=0,
            )

        # Exit long at extension levels
        if self.state.position_side == SignalType.LONG:
            for ext in fib.extension_levels:
                if ext.ratio >= 1.0 and current_price >= ext.price * 0.998:
                    return Signal(
                        signal_type=SignalType.EXIT_LONG, symbol=symbol,
                        strategy_name=self.name, confidence=0.7,
                        reason=f"Reached Fib extension {ext.label}",
                    )

        # Exit short at extension levels
        if self.state.position_side == SignalType.SHORT:
            for ext in fib.extension_levels:
                if ext.ratio >= 1.0 and current_price <= ext.price * 1.002:
                    return Signal(
                        signal_type=SignalType.EXIT_SHORT, symbol=symbol,
                        strategy_name=self.name, confidence=0.7,
                        reason=f"Reached Fib extension {ext.label}",
                    )

        return Signal(
            signal_type=SignalType.HOLD, symbol=symbol,
            strategy_name=self.name, confidence=0,
        )
