"""Chart Pattern Detection Intraday Strategy.

Uses the pattern recognition engine to identify and trade confirmed
chart patterns: Head & Shoulders, Double Top/Bottom, Triangles, Flags, Wedges.

Based on Technical Analysis Guide:
- Wait for pattern confirmation (breakout of neckline/trendline)
- Target = pattern height projected from breakout point
- Stop = opposite side of pattern

Timeframe: 15m
Hold time: 2-8 hours

Entry: Pattern detected with high confidence + price at entry zone
Exit: Pattern target or pattern invalidation
"""

from __future__ import annotations

import pandas as pd

from indicators.patterns import (
    PatternResult,
    PatternSignal,
    PatternType,
    detect_all_patterns,
)
from indicators.technical import atr, rsi
from indicators.volume import volume_profile
from strategies.base import BaseStrategy, Signal, SignalType, TradingStyle


class PatternDetectionIntraday(BaseStrategy):
    name = "pattern_detection_intraday"
    description = "Trade confirmed chart patterns (H&S, triangles, flags, etc.)"
    trading_style = TradingStyle.INTRADAY
    timeframe = "15m"
    min_candles = 60

    min_pattern_confidence: float = 0.55
    max_patterns_to_consider: int = 3

    def analyze(self, df: pd.DataFrame, symbol: str) -> Signal:
        if len(df) < self.min_candles:
            return Signal(
                signal_type=SignalType.HOLD, symbol=symbol,
                strategy_name=self.name, confidence=0,
            )

        close = df["close"]
        current_price = float(close.iloc[-1])
        atr_val = float(atr(df, 14).iloc[-1])
        rsi_val = float(rsi(close, 14).iloc[-1])
        vol = volume_profile(df, 20)

        # Detect all chart patterns
        patterns = detect_all_patterns(df, lookback=5)

        if not patterns:
            if self.state.in_position:
                return self._check_exit(current_price, atr_val, symbol)
            return Signal(
                signal_type=SignalType.HOLD, symbol=symbol,
                strategy_name=self.name, confidence=0,
            )

        # Consider top patterns by confidence
        top_patterns = patterns[: self.max_patterns_to_consider]

        for pattern in top_patterns:
            if pattern.confidence < self.min_pattern_confidence:
                continue

            signal = self._evaluate_pattern(
                pattern, current_price, atr_val, rsi_val, vol, symbol
            )
            if signal.signal_type != SignalType.HOLD:
                return signal

        if self.state.in_position:
            return self._check_exit(current_price, atr_val, symbol)

        return Signal(
            signal_type=SignalType.HOLD, symbol=symbol,
            strategy_name=self.name, confidence=0,
        )

    def _evaluate_pattern(
        self,
        pattern: PatternResult,
        current_price: float,
        atr_val: float,
        rsi_val: float,
        vol,
        symbol: str,
    ) -> Signal:
        """Evaluate a single pattern for trading signal."""

        # Check if price is near the entry zone
        if pattern.entry_price is None:
            return Signal(
                signal_type=SignalType.HOLD, symbol=symbol,
                strategy_name=self.name, confidence=0,
            )

        entry_distance = abs(current_price - pattern.entry_price) / atr_val

        # Must be within 1 ATR of entry price
        if entry_distance > 1.0:
            return Signal(
                signal_type=SignalType.HOLD, symbol=symbol,
                strategy_name=self.name, confidence=0,
            )

        confidence = pattern.confidence

        # Volume confirmation
        if vol.is_high_volume:
            confidence += 0.1

        # RSI filter
        if pattern.signal == PatternSignal.BULLISH:
            if rsi_val > 75:
                confidence -= 0.15  # Overbought, reduce confidence
            elif rsi_val < 45:
                confidence += 0.05  # Room to run

            if confidence >= 0.5:
                return Signal(
                    signal_type=SignalType.LONG,
                    symbol=symbol,
                    strategy_name=self.name,
                    confidence=min(confidence, 0.9),
                    entry_price=current_price,
                    stop_loss=pattern.stop_loss or (current_price - atr_val * 2),
                    take_profit=pattern.take_profit or (current_price + atr_val * 4),
                    reason=f"Pattern: {pattern.pattern_type.value}, {pattern.notes}",
                    metadata={
                        "pattern_type": pattern.pattern_type.value,
                        "pattern_confidence": pattern.confidence,
                    },
                )

        elif pattern.signal == PatternSignal.BEARISH:
            if rsi_val < 25:
                confidence -= 0.15
            elif rsi_val > 55:
                confidence += 0.05

            if confidence >= 0.5:
                return Signal(
                    signal_type=SignalType.SHORT,
                    symbol=symbol,
                    strategy_name=self.name,
                    confidence=min(confidence, 0.9),
                    entry_price=current_price,
                    stop_loss=pattern.stop_loss or (current_price + atr_val * 2),
                    take_profit=pattern.take_profit or (current_price - atr_val * 4),
                    reason=f"Pattern: {pattern.pattern_type.value}, {pattern.notes}",
                    metadata={
                        "pattern_type": pattern.pattern_type.value,
                        "pattern_confidence": pattern.confidence,
                    },
                )

        return Signal(
            signal_type=SignalType.HOLD, symbol=symbol,
            strategy_name=self.name, confidence=0,
        )

    def _check_exit(self, current_price: float, atr_val: float, symbol: str) -> Signal:
        """Check exit based on last signal's targets."""
        if not self.state.in_position or not self.state.last_signal:
            return Signal(
                signal_type=SignalType.HOLD, symbol=symbol,
                strategy_name=self.name, confidence=0,
            )

        last = self.state.last_signal
        if self.state.position_side == SignalType.LONG:
            if last.take_profit and current_price >= last.take_profit:
                return Signal(
                    signal_type=SignalType.EXIT_LONG, symbol=symbol,
                    strategy_name=self.name, confidence=0.8,
                    reason="Pattern target reached",
                )
        elif self.state.position_side == SignalType.SHORT:
            if last.take_profit and current_price <= last.take_profit:
                return Signal(
                    signal_type=SignalType.EXIT_SHORT, symbol=symbol,
                    strategy_name=self.name, confidence=0.8,
                    reason="Pattern target reached",
                )

        return Signal(
            signal_type=SignalType.HOLD, symbol=symbol,
            strategy_name=self.name, confidence=0,
        )
