"""Elliott Wave Impulse Entry Intraday Strategy.

Based on "Five Waves to Financial Freedom" by Ramki:
- Enter at the start of Wave 3 after Wave 2 retracement (50-61.8% of Wave 1)
- Wave 3 is typically the strongest and longest impulse wave
- Target: 161.8% extension of Wave 1 from Wave 2 end
- Stop: Below start of Wave 1 (Wave 2 cannot retrace 100%)

Timeframe: 15m
Hold time: 2-8 hours

Entry Long: Wave 2 retraces 50-61.8% of Wave 1 + bullish reversal signal
Entry Short: Bearish Wave 2 retraces 50-61.8% of Wave 1 + bearish reversal
Exit: Wave 3 target (161.8%) or wave structure violation
"""

from __future__ import annotations

import pandas as pd

from indicators.elliott_wave import WavePosition, WaveType, detect_waves
from indicators.fibonacci import auto_fibonacci, nearest_fib_level
from indicators.technical import atr, macd, rsi
from strategies.base import BaseStrategy, Signal, SignalType, TradingStyle


class ElliottImpulseIntraday(BaseStrategy):
    name = "elliott_impulse_intraday"
    description = "Enter Wave 3 after Wave 2 Fibonacci retracement (Ramki method)"
    trading_style = TradingStyle.INTRADAY
    timeframe = "15m"
    min_candles = 80

    wave_lookback: int = 5
    min_retrace: float = 0.382
    ideal_retrace_low: float = 0.50
    ideal_retrace_high: float = 0.618
    max_retrace: float = 0.786

    def analyze(self, df: pd.DataFrame, symbol: str) -> Signal:
        if len(df) < self.min_candles:
            return Signal(
                signal_type=SignalType.HOLD, symbol=symbol,
                strategy_name=self.name, confidence=0,
            )

        close = df["close"]
        current_price = float(close.iloc[-1])
        atr_val = float(atr(df, 14).iloc[-1])
        rsi_val = float(rsi(close, 14).iloc[-1])
        macd_result = macd(close)

        # Detect Elliott Wave pattern
        wave_result = detect_waves(df, lookback=self.wave_lookback)

        if wave_result.wave_type == WaveType.UNKNOWN:
            return Signal(
                signal_type=SignalType.HOLD, symbol=symbol,
                strategy_name=self.name, confidence=0,
            )

        current_hist = float(macd_result.histogram.iloc[-1])
        prev_hist = float(macd_result.histogram.iloc[-2])

        # Bullish: Wave 2 complete or early Wave 3
        if wave_result.direction == "bullish":
            if wave_result.current_position in (
                WavePosition.WAVE_2, WavePosition.WAVE_3
            ):
                confidence = wave_result.confidence * 0.7

                # Check if retracement is in ideal zone
                if len(wave_result.waves) >= 3:
                    w1_start = wave_result.waves[0].price
                    w1_end = wave_result.waves[1].price
                    w2_end = wave_result.waves[2].price
                    w1_range = w1_end - w1_start

                    if w1_range > 0:
                        retrace_pct = (w1_end - w2_end) / w1_range

                        if self.ideal_retrace_low <= retrace_pct <= self.ideal_retrace_high:
                            confidence += 0.2  # Ideal 50-61.8% zone
                        elif self.min_retrace <= retrace_pct <= self.max_retrace:
                            confidence += 0.1  # Acceptable zone
                        else:
                            confidence -= 0.1  # Outside ideal zone

                # MACD confirmation: histogram turning positive
                if current_hist > prev_hist and current_hist > 0:
                    confidence += 0.1

                # RSI confirmation: not overbought
                if 40 < rsi_val < 65:
                    confidence += 0.05

                if confidence >= 0.5:
                    target = wave_result.next_target or (current_price + atr_val * 4)
                    stop = wave_result.stop_loss or (current_price - atr_val * 2)

                    return Signal(
                        signal_type=SignalType.LONG,
                        symbol=symbol,
                        strategy_name=self.name,
                        confidence=min(confidence, 0.9),
                        entry_price=current_price,
                        stop_loss=stop,
                        take_profit=target,
                        reason=f"Elliott Wave 3 entry (bullish), pos={wave_result.current_position.value}",
                        metadata={
                            "wave_position": wave_result.current_position.value,
                            "wave_confidence": wave_result.confidence,
                            "notes": wave_result.notes,
                        },
                    )

        # Bearish: Wave 2 complete or early Wave 3
        if wave_result.direction == "bearish":
            if wave_result.current_position in (
                WavePosition.WAVE_2, WavePosition.WAVE_3
            ):
                confidence = wave_result.confidence * 0.7

                if len(wave_result.waves) >= 3:
                    w1_start = wave_result.waves[0].price
                    w1_end = wave_result.waves[1].price
                    w2_end = wave_result.waves[2].price
                    w1_range = w1_start - w1_end

                    if w1_range > 0:
                        retrace_pct = (w2_end - w1_end) / w1_range
                        if self.ideal_retrace_low <= retrace_pct <= self.ideal_retrace_high:
                            confidence += 0.2
                        elif self.min_retrace <= retrace_pct <= self.max_retrace:
                            confidence += 0.1

                if current_hist < prev_hist and current_hist < 0:
                    confidence += 0.1

                if 35 < rsi_val < 60:
                    confidence += 0.05

                if confidence >= 0.5:
                    target = wave_result.next_target or (current_price - atr_val * 4)
                    stop = wave_result.stop_loss or (current_price + atr_val * 2)

                    return Signal(
                        signal_type=SignalType.SHORT,
                        symbol=symbol,
                        strategy_name=self.name,
                        confidence=min(confidence, 0.9),
                        entry_price=current_price,
                        stop_loss=stop,
                        take_profit=target,
                        reason=f"Elliott Wave 3 entry (bearish), pos={wave_result.current_position.value}",
                        metadata={
                            "wave_position": wave_result.current_position.value,
                            "wave_confidence": wave_result.confidence,
                        },
                    )

        # Exit: wave structure violation or target area
        if self.state.in_position:
            if wave_result.current_position in (
                WavePosition.WAVE_5, WavePosition.WAVE_A
            ):
                exit_type = (
                    SignalType.EXIT_LONG
                    if self.state.position_side == SignalType.LONG
                    else SignalType.EXIT_SHORT
                )
                return Signal(
                    signal_type=exit_type,
                    symbol=symbol,
                    strategy_name=self.name,
                    confidence=0.75,
                    reason=f"Wave structure suggests impulse complete ({wave_result.current_position.value})",
                )

        return Signal(
            signal_type=SignalType.HOLD, symbol=symbol,
            strategy_name=self.name, confidence=0,
        )
