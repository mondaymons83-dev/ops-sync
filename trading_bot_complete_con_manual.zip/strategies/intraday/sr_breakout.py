"""Support/Resistance Breakout Intraday Strategy.

Identifies key S/R levels from recent swing points and pivot points,
then enters on confirmed breakout with volume.

Timeframe: 15m
Hold time: 1-8 hours

Entry Long: Price breaks above resistance + volume confirmation + RSI not overbought
Entry Short: Price breaks below support + volume confirmation + RSI not oversold
Exit: Opposite S/R level or trailing stop based on ATR
"""

from __future__ import annotations

import pandas as pd

from indicators.technical import atr, pivot_points, rsi, sma
from indicators.fibonacci import find_swing_points
from indicators.volume import volume_profile
from strategies.base import BaseStrategy, Signal, SignalType, TradingStyle


class SRBreakoutIntraday(BaseStrategy):
    name = "sr_breakout_intraday"
    description = "Support/Resistance breakout with volume confirmation"
    trading_style = TradingStyle.INTRADAY
    timeframe = "15m"
    min_candles = 60

    sr_lookback: int = 5
    breakout_confirm_candles: int = 2
    volume_threshold: float = 1.3

    def analyze(self, df: pd.DataFrame, symbol: str) -> Signal:
        if len(df) < self.min_candles:
            return Signal(
                signal_type=SignalType.HOLD, symbol=symbol,
                strategy_name=self.name, confidence=0,
            )

        close = df["close"]
        current_price = float(close.iloc[-1])
        atr_val = float(atr(df, 14).iloc[-1])
        rsi_val = float(rsi(close, 14).iloc[-1])
        vol = volume_profile(df, 20)

        # Identify S/R levels from swing points
        highs, lows = find_swing_points(df, self.sr_lookback)

        if not highs or not lows:
            return Signal(
                signal_type=SignalType.HOLD, symbol=symbol,
                strategy_name=self.name, confidence=0,
            )

        # Get nearest resistance (swing high above current price)
        resistances = [h[1] for h in highs if h[1] > current_price * 0.995]
        supports = [l[1] for l in lows if l[1] < current_price * 1.005]

        # Also use pivot points as S/R
        pp, r1, r2, s1, s2 = pivot_points(df)
        if r1 > current_price:
            resistances.append(r1)
        if r2 > current_price:
            resistances.append(r2)
        if s1 < current_price:
            supports.append(s1)
        if s2 < current_price:
            supports.append(s2)

        nearest_resistance = min(resistances) if resistances else None
        nearest_support = max(supports) if supports else None

        # Check for breakout above resistance
        if nearest_resistance is not None:
            prev_closes = [float(close.iloc[-i]) for i in range(2, self.breakout_confirm_candles + 2)]
            was_below = all(c < nearest_resistance for c in prev_closes)

            if was_below and current_price > nearest_resistance:
                if vol.volume_ratio >= self.volume_threshold and rsi_val < 75:
                    confidence = 0.55
                    if vol.is_high_volume:
                        confidence += 0.15
                    if rsi_val < 65:
                        confidence += 0.1
                    # Stronger breakout = higher confidence
                    breakout_pct = (current_price - nearest_resistance) / nearest_resistance
                    if breakout_pct > 0.002:
                        confidence += 0.05

                    target = current_price + (current_price - nearest_support) if nearest_support else current_price + atr_val * 3
                    return Signal(
                        signal_type=SignalType.LONG,
                        symbol=symbol,
                        strategy_name=self.name,
                        confidence=min(confidence, 0.9),
                        entry_price=current_price,
                        stop_loss=nearest_resistance - atr_val * 0.5,
                        take_profit=target,
                        reason=f"Breakout above R={nearest_resistance:.2f}, Vol ratio={vol.volume_ratio:.1f}",
                        metadata={"resistance": nearest_resistance, "support": nearest_support},
                    )

        # Check for breakdown below support
        if nearest_support is not None:
            prev_closes = [float(close.iloc[-i]) for i in range(2, self.breakout_confirm_candles + 2)]
            was_above = all(c > nearest_support for c in prev_closes)

            if was_above and current_price < nearest_support:
                if vol.volume_ratio >= self.volume_threshold and rsi_val > 25:
                    confidence = 0.55
                    if vol.is_high_volume:
                        confidence += 0.15
                    if rsi_val > 35:
                        confidence += 0.1

                    target = current_price - (nearest_resistance - current_price) if nearest_resistance else current_price - atr_val * 3
                    return Signal(
                        signal_type=SignalType.SHORT,
                        symbol=symbol,
                        strategy_name=self.name,
                        confidence=min(confidence, 0.9),
                        entry_price=current_price,
                        stop_loss=nearest_support + atr_val * 0.5,
                        take_profit=target,
                        reason=f"Breakdown below S={nearest_support:.2f}, Vol ratio={vol.volume_ratio:.1f}",
                        metadata={"resistance": nearest_resistance, "support": nearest_support},
                    )

        # Exit signals
        if self.state.in_position:
            if self.state.position_side == SignalType.LONG and nearest_resistance is not None:
                if current_price >= nearest_resistance * 0.998:
                    return Signal(
                        signal_type=SignalType.EXIT_LONG, symbol=symbol,
                        strategy_name=self.name, confidence=0.7,
                        reason=f"Approaching next resistance {nearest_resistance:.2f}",
                    )
            if self.state.position_side == SignalType.SHORT and nearest_support is not None:
                if current_price <= nearest_support * 1.002:
                    return Signal(
                        signal_type=SignalType.EXIT_SHORT, symbol=symbol,
                        strategy_name=self.name, confidence=0.7,
                        reason=f"Approaching next support {nearest_support:.2f}",
                    )

        return Signal(
            signal_type=SignalType.HOLD, symbol=symbol,
            strategy_name=self.name, confidence=0,
        )
