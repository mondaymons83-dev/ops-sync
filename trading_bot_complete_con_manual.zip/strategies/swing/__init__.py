"""Swing trading strategies (4h timeframe)."""

from strategies.swing.elliott_full_cycle import ElliottFullCycleSwing
from strategies.swing.golden_cross import GoldenDeathCrossSwing
from strategies.swing.multi_timeframe import MultiTimeframeSwing
from strategies.swing.divergence import DivergenceSwing
from strategies.swing.flag_breakout import FlagBreakoutSwing

__all__ = [
    "ElliottFullCycleSwing",
    "GoldenDeathCrossSwing",
    "MultiTimeframeSwing",
    "DivergenceSwing",
    "FlagBreakoutSwing",
]
