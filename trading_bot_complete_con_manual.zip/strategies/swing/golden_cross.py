"""Golden/Death Cross Swing Strategy.

Classic long-term trend change indicator:
- Golden Cross: 50 SMA crosses above 200 SMA = bullish
- Death Cross: 50 SMA crosses below 200 SMA = bearish

Enhanced with volume confirmation and ADX for trend strength.

Timeframe: 4h (can also use daily)
Hold time: 5-14+ days

Entry Long: 50 SMA crosses above 200 SMA + ADX > 20 + volume above average
Entry Short: 50 SMA crosses below 200 SMA + ADX > 20 + volume above average
Exit: Opposite cross or ADX declining below 15
"""

from __future__ import annotations

import pandas as pd

from indicators.technical import adx, atr, ema, rsi, sma
from indicators.volume import volume_profile
from strategies.base import BaseStrategy, Signal, SignalType, TradingStyle


class GoldenDeathCrossSwing(BaseStrategy):
    name = "golden_death_cross_swing"
    description = "50/200 SMA Golden/Death Cross with ADX and volume confirmation"
    trading_style = TradingStyle.SWING
    timeframe = "4h"
    min_candles = 210

    fast_period: int = 50
    slow_period: int = 200
    adx_threshold: float = 20.0
    adx_exit_threshold: float = 15.0

    def analyze(self, df: pd.DataFrame, symbol: str) -> Signal:
        if len(df) < self.min_candles:
            return Signal(
                signal_type=SignalType.HOLD, symbol=symbol,
                strategy_name=self.name, confidence=0,
            )

        close = df["close"]
        current_price = float(close.iloc[-1])
        atr_val = float(atr(df, 14).iloc[-1])
        rsi_val = float(rsi(close, 14).iloc[-1])

        # Calculate SMAs
        fast_sma = sma(close, self.fast_period)
        slow_sma = sma(close, self.slow_period)

        current_fast = float(fast_sma.iloc[-1])
        current_slow = float(slow_sma.iloc[-1])
        prev_fast = float(fast_sma.iloc[-2])
        prev_slow = float(slow_sma.iloc[-2])

        # ADX for trend strength
        adx_result = adx(df, 14)
        current_adx = float(adx_result.adx.iloc[-1])
        plus_di = float(adx_result.plus_di.iloc[-1])
        minus_di = float(adx_result.minus_di.iloc[-1])

        # Volume
        vol = volume_profile(df, 20)

        # Golden Cross: fast crosses above slow
        golden_cross = prev_fast <= prev_slow and current_fast > current_slow
        # Death Cross: fast crosses below slow
        death_cross = prev_fast >= prev_slow and current_fast < current_slow

        # Golden Cross - bullish
        if golden_cross and current_adx > self.adx_threshold:
            confidence = 0.55

            if vol.is_high_volume:
                confidence += 0.1
            if plus_di > minus_di:
                confidence += 0.1
            if rsi_val < 65:
                confidence += 0.05
            if current_adx > 25:
                confidence += 0.05

            return Signal(
                signal_type=SignalType.LONG,
                symbol=symbol,
                strategy_name=self.name,
                confidence=min(confidence, 0.85),
                entry_price=current_price,
                stop_loss=current_slow - atr_val * 1.0,
                take_profit=current_price + atr_val * 6,
                reason=f"Golden Cross (50/200 SMA), ADX={current_adx:.1f}, +DI={plus_di:.1f}",
                metadata={
                    "cross_type": "golden",
                    "adx": current_adx,
                    "volume_ratio": vol.volume_ratio,
                },
            )

        # Death Cross - bearish
        if death_cross and current_adx > self.adx_threshold:
            confidence = 0.55

            if vol.is_high_volume:
                confidence += 0.1
            if minus_di > plus_di:
                confidence += 0.1
            if rsi_val > 35:
                confidence += 0.05
            if current_adx > 25:
                confidence += 0.05

            return Signal(
                signal_type=SignalType.SHORT,
                symbol=symbol,
                strategy_name=self.name,
                confidence=min(confidence, 0.85),
                entry_price=current_price,
                stop_loss=current_slow + atr_val * 1.0,
                take_profit=current_price - atr_val * 6,
                reason=f"Death Cross (50/200 SMA), ADX={current_adx:.1f}, -DI={minus_di:.1f}",
                metadata={
                    "cross_type": "death",
                    "adx": current_adx,
                    "volume_ratio": vol.volume_ratio,
                },
            )

        # Exit: opposite cross or ADX declining
        if self.state.in_position:
            if self.state.position_side == SignalType.LONG:
                # Exit on death cross or ADX collapsing
                if death_cross or current_adx < self.adx_exit_threshold:
                    return Signal(
                        signal_type=SignalType.EXIT_LONG, symbol=symbol,
                        strategy_name=self.name, confidence=0.75,
                        reason=f"{'Death cross' if death_cross else 'ADX declining'} - exit long",
                    )
                # Also exit if price drops far below fast SMA
                if current_price < current_fast - atr_val * 2:
                    return Signal(
                        signal_type=SignalType.EXIT_LONG, symbol=symbol,
                        strategy_name=self.name, confidence=0.65,
                        reason="Price far below 50 SMA, trend weakening",
                    )

            if self.state.position_side == SignalType.SHORT:
                if golden_cross or current_adx < self.adx_exit_threshold:
                    return Signal(
                        signal_type=SignalType.EXIT_SHORT, symbol=symbol,
                        strategy_name=self.name, confidence=0.75,
                        reason=f"{'Golden cross' if golden_cross else 'ADX declining'} - exit short",
                    )
                if current_price > current_fast + atr_val * 2:
                    return Signal(
                        signal_type=SignalType.EXIT_SHORT, symbol=symbol,
                        strategy_name=self.name, confidence=0.65,
                        reason="Price far above 50 SMA, trend weakening",
                    )

        return Signal(
            signal_type=SignalType.HOLD, symbol=symbol,
            strategy_name=self.name, confidence=0,
        )
