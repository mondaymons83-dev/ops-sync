"""Multi-Timeframe Trend Swing Strategy.

Based on the overview principle: "Always consult a higher timeframe
to contextualize movements and potential patterns."

Uses two timeframe levels:
- Higher TF (4h): Determines overall trend direction
- Lower TF (1h simulated): Finds entry points within the trend

Entry rules:
- Higher TF trend must be established (EMA alignment + ADX)
- Lower TF shows pullback entry opportunity (RSI + price near EMA)

Timeframe: 4h (primary), uses internal sub-analysis
Hold time: 3-14 days

Entry Long: Higher TF bullish + lower TF pullback to support
Entry Short: Higher TF bearish + lower TF pullback to resistance
Exit: Higher TF trend reversal or trailing stop
"""

from __future__ import annotations

import pandas as pd

from indicators.technical import adx, atr, ema, rsi, sma
from indicators.volume import volume_profile
from strategies.base import BaseStrategy, Signal, SignalType, TradingStyle


class MultiTimeframeSwing(BaseStrategy):
    name = "multi_timeframe_swing"
    description = "Confirm trend on higher TF, enter on lower TF pullback"
    trading_style = TradingStyle.SWING
    timeframe = "4h"
    min_candles = 100

    htf_ema_fast: int = 21
    htf_ema_slow: int = 55
    ltf_ema: int = 8
    adx_threshold: float = 20.0
    pullback_atr_mult: float = 1.0

    def analyze(self, df: pd.DataFrame, symbol: str) -> Signal:
        if len(df) < self.min_candles:
            return Signal(
                signal_type=SignalType.HOLD, symbol=symbol,
                strategy_name=self.name, confidence=0,
            )

        close = df["close"]
        current_price = float(close.iloc[-1])
        atr_val = float(atr(df, 14).iloc[-1])

        # --- Higher Timeframe Analysis (full df = 4h) ---
        htf_ema_fast = ema(close, self.htf_ema_fast)
        htf_ema_slow = ema(close, self.htf_ema_slow)
        htf_adx = adx(df, 14)
        htf_rsi = rsi(close, 14)

        current_htf_fast = float(htf_ema_fast.iloc[-1])
        current_htf_slow = float(htf_ema_slow.iloc[-1])
        current_adx = float(htf_adx.adx.iloc[-1])
        plus_di = float(htf_adx.plus_di.iloc[-1])
        minus_di = float(htf_adx.minus_di.iloc[-1])
        htf_rsi_val = float(htf_rsi.iloc[-1])

        htf_bullish = (
            current_htf_fast > current_htf_slow
            and current_adx > self.adx_threshold
            and plus_di > minus_di
        )
        htf_bearish = (
            current_htf_fast < current_htf_slow
            and current_adx > self.adx_threshold
            and minus_di > plus_di
        )

        # --- Lower Timeframe Analysis (recent candles = simulated 1h) ---
        # Use the last 20 candles as "lower timeframe" context
        ltf_df = df.tail(25)
        ltf_close = ltf_df["close"]
        ltf_ema_val = ema(ltf_close, self.ltf_ema)
        ltf_rsi = rsi(ltf_close, 7)
        ltf_atr = atr(ltf_df, 7)

        current_ltf_ema = float(ltf_ema_val.iloc[-1])
        current_ltf_rsi = float(ltf_rsi.iloc[-1])
        current_ltf_atr = float(ltf_atr.iloc[-1])

        # Volume confirmation
        vol = volume_profile(df, 20)

        # Pullback detection: price near LTF EMA
        distance_to_ltf_ema = abs(current_price - current_ltf_ema) / atr_val
        is_pullback = distance_to_ltf_ema < self.pullback_atr_mult

        # --- LONG: HTF bullish + LTF pullback ---
        if htf_bullish and is_pullback and current_price > current_ltf_ema:
            if current_ltf_rsi < 60 and htf_rsi_val < 70:
                confidence = 0.5

                if current_adx > 25:
                    confidence += 0.1
                if vol.volume_ratio > 1.0:
                    confidence += 0.05
                if distance_to_ltf_ema < 0.5:
                    confidence += 0.1  # Clean pullback
                if htf_rsi_val < 60:
                    confidence += 0.05

                return Signal(
                    signal_type=SignalType.LONG,
                    symbol=symbol,
                    strategy_name=self.name,
                    confidence=min(confidence, 0.85),
                    entry_price=current_price,
                    stop_loss=current_htf_slow - atr_val * 0.5,
                    take_profit=current_price + atr_val * 5,
                    reason=f"HTF bullish trend + LTF pullback, ADX={current_adx:.1f}",
                    metadata={
                        "htf_trend": "bullish",
                        "adx": current_adx,
                        "ltf_rsi": current_ltf_rsi,
                    },
                )

        # --- SHORT: HTF bearish + LTF pullback ---
        if htf_bearish and is_pullback and current_price < current_ltf_ema:
            if current_ltf_rsi > 40 and htf_rsi_val > 30:
                confidence = 0.5

                if current_adx > 25:
                    confidence += 0.1
                if vol.volume_ratio > 1.0:
                    confidence += 0.05
                if distance_to_ltf_ema < 0.5:
                    confidence += 0.1
                if htf_rsi_val > 40:
                    confidence += 0.05

                return Signal(
                    signal_type=SignalType.SHORT,
                    symbol=symbol,
                    strategy_name=self.name,
                    confidence=min(confidence, 0.85),
                    entry_price=current_price,
                    stop_loss=current_htf_slow + atr_val * 0.5,
                    take_profit=current_price - atr_val * 5,
                    reason=f"HTF bearish trend + LTF pullback, ADX={current_adx:.1f}",
                    metadata={
                        "htf_trend": "bearish",
                        "adx": current_adx,
                        "ltf_rsi": current_ltf_rsi,
                    },
                )

        # --- EXIT ---
        if self.state.in_position:
            if self.state.position_side == SignalType.LONG:
                if not htf_bullish or htf_rsi_val > 80:
                    return Signal(
                        signal_type=SignalType.EXIT_LONG, symbol=symbol,
                        strategy_name=self.name, confidence=0.7,
                        reason="HTF trend no longer bullish or overbought",
                    )

            if self.state.position_side == SignalType.SHORT:
                if not htf_bearish or htf_rsi_val < 20:
                    return Signal(
                        signal_type=SignalType.EXIT_SHORT, symbol=symbol,
                        strategy_name=self.name, confidence=0.7,
                        reason="HTF trend no longer bearish or oversold",
                    )

        return Signal(
            signal_type=SignalType.HOLD, symbol=symbol,
            strategy_name=self.name, confidence=0,
        )
