"""Divergence Trading Swing Strategy.

Based on Technical Analysis Guide principles:
- Bullish divergence: Price makes lower low, RSI/MACD makes higher low
- Bearish divergence: Price makes higher high, RSI/MACD makes lower high
- Divergence signals potential trend reversal

Enhanced with volume divergence confirmation.

Timeframe: 4h
Hold time: 3-14 days

Entry Long: Bullish RSI divergence + MACD histogram turning + volume divergence
Entry Short: Bearish RSI divergence + MACD histogram turning + volume divergence
Exit: Divergence resolves or new divergence in opposite direction
"""

from __future__ import annotations

import numpy as np
import pandas as pd

from indicators.technical import atr, ema, macd, rsi
from indicators.volume import detect_volume_divergence, volume_profile
from indicators.fibonacci import find_swing_points
from strategies.base import BaseStrategy, Signal, SignalType, TradingStyle


class DivergenceSwing(BaseStrategy):
    name = "divergence_swing"
    description = "Trade RSI/MACD divergences for trend reversals"
    trading_style = TradingStyle.SWING
    timeframe = "4h"
    min_candles = 80

    rsi_period: int = 14
    divergence_lookback: int = 20
    swing_lookback: int = 5

    def analyze(self, df: pd.DataFrame, symbol: str) -> Signal:
        if len(df) < self.min_candles:
            return Signal(
                signal_type=SignalType.HOLD, symbol=symbol,
                strategy_name=self.name, confidence=0,
            )

        close = df["close"]
        current_price = float(close.iloc[-1])
        atr_val = float(atr(df, 14).iloc[-1])
        rsi_series = rsi(close, self.rsi_period)
        current_rsi = float(rsi_series.iloc[-1])
        macd_result = macd(close)
        current_hist = float(macd_result.histogram.iloc[-1])
        prev_hist = float(macd_result.histogram.iloc[-2])
        ema_50 = float(ema(close, 50).iloc[-1])
        vol = volume_profile(df, 20)
        vol_div = detect_volume_divergence(df, 10)

        # Find swing points for divergence detection
        highs, lows = find_swing_points(df, self.swing_lookback)

        # --- Detect Bullish Divergence ---
        bullish_div = self._detect_bullish_divergence(
            df, lows, rsi_series, macd_result.histogram
        )

        # --- Detect Bearish Divergence ---
        bearish_div = self._detect_bearish_divergence(
            df, highs, rsi_series, macd_result.histogram
        )

        # --- LONG: Bullish divergence ---
        if bullish_div["found"]:
            confidence = 0.5

            if bullish_div["rsi_div"]:
                confidence += 0.15
            if bullish_div["macd_div"]:
                confidence += 0.1
            if vol_div == "bullish_divergence":
                confidence += 0.1
            if current_hist > prev_hist:
                confidence += 0.05  # MACD histogram turning
            if current_rsi < 40:
                confidence += 0.05  # Oversold area

            if confidence >= 0.5:
                return Signal(
                    signal_type=SignalType.LONG,
                    symbol=symbol,
                    strategy_name=self.name,
                    confidence=min(confidence, 0.85),
                    entry_price=current_price,
                    stop_loss=current_price - atr_val * 2.5,
                    take_profit=current_price + atr_val * 5,
                    reason=f"Bullish divergence: RSI={bullish_div['rsi_div']}, MACD={bullish_div['macd_div']}",
                    metadata={
                        "divergence_type": "bullish",
                        "rsi_divergence": bullish_div["rsi_div"],
                        "macd_divergence": bullish_div["macd_div"],
                        "volume_divergence": vol_div,
                    },
                )

        # --- SHORT: Bearish divergence ---
        if bearish_div["found"]:
            confidence = 0.5

            if bearish_div["rsi_div"]:
                confidence += 0.15
            if bearish_div["macd_div"]:
                confidence += 0.1
            if vol_div == "bearish_divergence":
                confidence += 0.1
            if current_hist < prev_hist:
                confidence += 0.05
            if current_rsi > 60:
                confidence += 0.05

            if confidence >= 0.5:
                return Signal(
                    signal_type=SignalType.SHORT,
                    symbol=symbol,
                    strategy_name=self.name,
                    confidence=min(confidence, 0.85),
                    entry_price=current_price,
                    stop_loss=current_price + atr_val * 2.5,
                    take_profit=current_price - atr_val * 5,
                    reason=f"Bearish divergence: RSI={bearish_div['rsi_div']}, MACD={bearish_div['macd_div']}",
                    metadata={
                        "divergence_type": "bearish",
                        "rsi_divergence": bearish_div["rsi_div"],
                        "macd_divergence": bearish_div["macd_div"],
                        "volume_divergence": vol_div,
                    },
                )

        # --- EXIT ---
        if self.state.in_position:
            if self.state.position_side == SignalType.LONG:
                if bearish_div["found"] or current_rsi > 75:
                    return Signal(
                        signal_type=SignalType.EXIT_LONG, symbol=symbol,
                        strategy_name=self.name, confidence=0.7,
                        reason="Bearish divergence or RSI overbought",
                    )
            if self.state.position_side == SignalType.SHORT:
                if bullish_div["found"] or current_rsi < 25:
                    return Signal(
                        signal_type=SignalType.EXIT_SHORT, symbol=symbol,
                        strategy_name=self.name, confidence=0.7,
                        reason="Bullish divergence or RSI oversold",
                    )

        return Signal(
            signal_type=SignalType.HOLD, symbol=symbol,
            strategy_name=self.name, confidence=0,
        )

    def _detect_bullish_divergence(
        self,
        df: pd.DataFrame,
        lows: list,
        rsi_series: pd.Series,
        macd_hist: pd.Series,
    ) -> dict:
        """Detect bullish divergence: price lower low + indicator higher low."""
        result = {"found": False, "rsi_div": False, "macd_div": False}

        if len(lows) < 2:
            return result

        # Compare last two swing lows
        prev_low_idx, prev_low_price = lows[-2]
        curr_low_idx, curr_low_price = lows[-1]

        # Price makes lower low
        if curr_low_price < prev_low_price:
            # RSI makes higher low (bullish divergence)
            if prev_low_idx < len(rsi_series) and curr_low_idx < len(rsi_series):
                prev_rsi = float(rsi_series.iloc[prev_low_idx])
                curr_rsi = float(rsi_series.iloc[curr_low_idx])
                if curr_rsi > prev_rsi:
                    result["rsi_div"] = True
                    result["found"] = True

            # MACD histogram makes higher low
            if prev_low_idx < len(macd_hist) and curr_low_idx < len(macd_hist):
                prev_macd = float(macd_hist.iloc[prev_low_idx])
                curr_macd = float(macd_hist.iloc[curr_low_idx])
                if curr_macd > prev_macd:
                    result["macd_div"] = True
                    result["found"] = True

        return result

    def _detect_bearish_divergence(
        self,
        df: pd.DataFrame,
        highs: list,
        rsi_series: pd.Series,
        macd_hist: pd.Series,
    ) -> dict:
        """Detect bearish divergence: price higher high + indicator lower high."""
        result = {"found": False, "rsi_div": False, "macd_div": False}

        if len(highs) < 2:
            return result

        prev_high_idx, prev_high_price = highs[-2]
        curr_high_idx, curr_high_price = highs[-1]

        # Price makes higher high
        if curr_high_price > prev_high_price:
            # RSI makes lower high (bearish divergence)
            if prev_high_idx < len(rsi_series) and curr_high_idx < len(rsi_series):
                prev_rsi = float(rsi_series.iloc[prev_high_idx])
                curr_rsi = float(rsi_series.iloc[curr_high_idx])
                if curr_rsi < prev_rsi:
                    result["rsi_div"] = True
                    result["found"] = True

            # MACD histogram makes lower high
            if prev_high_idx < len(macd_hist) and curr_high_idx < len(macd_hist):
                prev_macd = float(macd_hist.iloc[prev_high_idx])
                curr_macd = float(macd_hist.iloc[curr_high_idx])
                if curr_macd < prev_macd:
                    result["macd_div"] = True
                    result["found"] = True

        return result
