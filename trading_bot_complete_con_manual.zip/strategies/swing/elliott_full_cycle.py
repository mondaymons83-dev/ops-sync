"""Elliott Wave Full Cycle Swing Strategy.

Based on "Five Waves to Financial Freedom" by Ramki:
- Trade the complete 5-wave impulse + ABC correction cycle
- Enter at Wave 1 start or Wave 3 start for maximum profit
- Hold through the impulse, exit before or during correction
- Use higher timeframe for context (4h/daily)

Key principles:
- After 5 waves complete, expect ABC correction LARGER than Wave 2 or Wave 4
- Wave 3 target: 161.8-261.8% of Wave 1
- Wave 5 target: 61.8-100% of Wave 1-3 distance
- Correction target: 38.2-61.8% of entire impulse

Timeframe: 4h
Hold time: 2-14 days
"""

from __future__ import annotations

import pandas as pd

from indicators.elliott_wave import (
    WavePosition,
    WaveType,
    detect_waves,
)
from indicators.fibonacci import calculate_retracements
from indicators.technical import atr, ema, macd, rsi
from strategies.base import BaseStrategy, Signal, SignalType, TradingStyle


class ElliottFullCycleSwing(BaseStrategy):
    name = "elliott_full_cycle_swing"
    description = "Trade complete Elliott Wave 5-wave impulse + ABC correction"
    trading_style = TradingStyle.SWING
    timeframe = "4h"
    min_candles = 120

    wave_lookback: int = 7

    def analyze(self, df: pd.DataFrame, symbol: str) -> Signal:
        if len(df) < self.min_candles:
            return Signal(
                signal_type=SignalType.HOLD, symbol=symbol,
                strategy_name=self.name, confidence=0,
            )

        close = df["close"]
        current_price = float(close.iloc[-1])
        atr_val = float(atr(df, 14).iloc[-1])
        rsi_val = float(rsi(close, 14).iloc[-1])
        macd_result = macd(close)
        current_hist = float(macd_result.histogram.iloc[-1])
        prev_hist = float(macd_result.histogram.iloc[-2])
        ema_50 = float(ema(close, 50).iloc[-1])

        wave_result = detect_waves(df, lookback=self.wave_lookback)

        if wave_result.wave_type == WaveType.UNKNOWN:
            return Signal(
                signal_type=SignalType.HOLD, symbol=symbol,
                strategy_name=self.name, confidence=0,
            )

        # --- IMPULSE ENTRIES ---

        # Enter at Wave 2 end / Wave 3 start (strongest entry)
        if wave_result.direction == "bullish":
            if wave_result.current_position in (
                WavePosition.WAVE_2, WavePosition.WAVE_3
            ):
                confidence = wave_result.confidence * 0.6

                # MACD turning bullish
                if current_hist > prev_hist:
                    confidence += 0.1
                # Price above long-term trend
                if current_price > ema_50:
                    confidence += 0.1
                # RSI not extreme
                if 35 < rsi_val < 65:
                    confidence += 0.05

                if confidence >= 0.5:
                    target = wave_result.next_target or (current_price + atr_val * 6)
                    stop = wave_result.stop_loss or (current_price - atr_val * 3)

                    return Signal(
                        signal_type=SignalType.LONG,
                        symbol=symbol,
                        strategy_name=self.name,
                        confidence=min(confidence, 0.9),
                        entry_price=current_price,
                        stop_loss=stop,
                        take_profit=target,
                        reason=f"Elliott bullish impulse entry at {wave_result.current_position.value}",
                        metadata={
                            "wave_type": wave_result.wave_type.value,
                            "wave_position": wave_result.current_position.value,
                            "wave_confidence": wave_result.confidence,
                        },
                    )

            # Enter correction (short) after Wave 5
            if wave_result.current_position in (
                WavePosition.WAVE_5, WavePosition.WAVE_A
            ):
                confidence = wave_result.confidence * 0.5

                if current_hist < prev_hist:
                    confidence += 0.1
                if rsi_val > 65:
                    confidence += 0.1

                if confidence >= 0.5 and len(wave_result.waves) >= 6:
                    # Target: 38.2-61.8% retracement of entire impulse
                    impulse_start = wave_result.waves[0].price
                    impulse_end = wave_result.waves[5].price
                    retrace_levels = calculate_retracements(
                        impulse_start, impulse_end, direction="up"
                    )
                    # Target 50% retracement
                    target = None
                    for level in retrace_levels:
                        if abs(level.ratio - 0.5) < 0.05:
                            target = level.price
                            break

                    return Signal(
                        signal_type=SignalType.SHORT,
                        symbol=symbol,
                        strategy_name=self.name,
                        confidence=min(confidence, 0.85),
                        entry_price=current_price,
                        stop_loss=impulse_end * 1.02,
                        take_profit=target or (current_price - atr_val * 5),
                        reason="Elliott correction entry after 5-wave completion",
                        metadata={
                            "wave_position": wave_result.current_position.value,
                        },
                    )

        # Bearish impulse
        if wave_result.direction == "bearish":
            if wave_result.current_position in (
                WavePosition.WAVE_2, WavePosition.WAVE_3
            ):
                confidence = wave_result.confidence * 0.6

                if current_hist < prev_hist:
                    confidence += 0.1
                if current_price < ema_50:
                    confidence += 0.1
                if 35 < rsi_val < 65:
                    confidence += 0.05

                if confidence >= 0.5:
                    target = wave_result.next_target or (current_price - atr_val * 6)
                    stop = wave_result.stop_loss or (current_price + atr_val * 3)

                    return Signal(
                        signal_type=SignalType.SHORT,
                        symbol=symbol,
                        strategy_name=self.name,
                        confidence=min(confidence, 0.9),
                        entry_price=current_price,
                        stop_loss=stop,
                        take_profit=target,
                        reason=f"Elliott bearish impulse entry at {wave_result.current_position.value}",
                        metadata={
                            "wave_position": wave_result.current_position.value,
                        },
                    )

            # Correction bounce (long) after bearish Wave 5
            if wave_result.current_position in (
                WavePosition.WAVE_5, WavePosition.WAVE_A
            ):
                confidence = wave_result.confidence * 0.5

                if current_hist > prev_hist:
                    confidence += 0.1
                if rsi_val < 35:
                    confidence += 0.1

                if confidence >= 0.5 and len(wave_result.waves) >= 6:
                    impulse_start = wave_result.waves[0].price
                    impulse_end = wave_result.waves[5].price
                    retrace_levels = calculate_retracements(
                        impulse_end, impulse_start, direction="down"
                    )
                    target = None
                    for level in retrace_levels:
                        if abs(level.ratio - 0.5) < 0.05:
                            target = level.price
                            break

                    return Signal(
                        signal_type=SignalType.LONG,
                        symbol=symbol,
                        strategy_name=self.name,
                        confidence=min(confidence, 0.85),
                        entry_price=current_price,
                        stop_loss=impulse_end * 0.98,
                        take_profit=target or (current_price + atr_val * 5),
                        reason="Elliott correction bounce after bearish 5-wave",
                        metadata={
                            "wave_position": wave_result.current_position.value,
                        },
                    )

        # --- EXIT LOGIC ---
        if self.state.in_position:
            # Exit long if we reach Wave 5 or correction starts
            if self.state.position_side == SignalType.LONG:
                if wave_result.current_position in (
                    WavePosition.WAVE_5, WavePosition.WAVE_A, WavePosition.WAVE_B
                ):
                    if wave_result.direction == "bullish":
                        return Signal(
                            signal_type=SignalType.EXIT_LONG, symbol=symbol,
                            strategy_name=self.name, confidence=0.75,
                            reason=f"Impulse likely complete, now at {wave_result.current_position.value}",
                        )

            # Exit short if correction may be ending
            if self.state.position_side == SignalType.SHORT:
                if wave_result.current_position == WavePosition.WAVE_C:
                    return Signal(
                        signal_type=SignalType.EXIT_SHORT, symbol=symbol,
                        strategy_name=self.name, confidence=0.7,
                        reason="ABC correction likely complete (Wave C)",
                    )

        return Signal(
            signal_type=SignalType.HOLD, symbol=symbol,
            strategy_name=self.name, confidence=0,
        )
