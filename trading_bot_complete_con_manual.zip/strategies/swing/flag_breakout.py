"""Flag/Pennant Breakout Swing Strategy.

Based on Technical Analysis Guide:
- Bull flag: strong upward pole + slight downward consolidation channel
- Bear flag: strong downward pole + slight upward consolidation channel
- Pennant: converging trendlines after a sharp move
- Target: pole height projected from breakout point

Enhanced with volume confirmation (volume should decrease during flag,
increase on breakout).

Timeframe: 4h
Hold time: 3-14 days

Entry Long: Bull flag/pennant breakout + volume spike
Entry Short: Bear flag/pennant breakout + volume spike
Exit: Target (pole projection) or pattern invalidation
"""

from __future__ import annotations

import pandas as pd

from indicators.patterns import (
    PatternSignal,
    PatternType,
    detect_all_patterns,
)
from indicators.technical import atr, ema, rsi
from indicators.volume import volume_profile
from strategies.base import BaseStrategy, Signal, SignalType, TradingStyle


class FlagBreakoutSwing(BaseStrategy):
    name = "flag_breakout_swing"
    description = "Trade bull/bear flag and pennant breakouts with pole projection"
    trading_style = TradingStyle.SWING
    timeframe = "4h"
    min_candles = 60

    min_confidence: float = 0.5
    volume_breakout_mult: float = 1.3

    def analyze(self, df: pd.DataFrame, symbol: str) -> Signal:
        if len(df) < self.min_candles:
            return Signal(
                signal_type=SignalType.HOLD, symbol=symbol,
                strategy_name=self.name, confidence=0,
            )

        close = df["close"]
        current_price = float(close.iloc[-1])
        atr_val = float(atr(df, 14).iloc[-1])
        rsi_val = float(rsi(close, 14).iloc[-1])
        ema_21 = float(ema(close, 21).iloc[-1])
        vol = volume_profile(df, 20)

        # Detect patterns
        patterns = detect_all_patterns(df, lookback=5)

        # Filter for flag and pennant patterns only
        flag_types = {
            PatternType.BULL_FLAG,
            PatternType.BEAR_FLAG,
            PatternType.BULL_PENNANT,
            PatternType.BEAR_PENNANT,
        }

        flag_patterns = [p for p in patterns if p.pattern_type in flag_types]

        if not flag_patterns:
            if self.state.in_position:
                return self._check_exit(current_price, atr_val, symbol)
            return Signal(
                signal_type=SignalType.HOLD, symbol=symbol,
                strategy_name=self.name, confidence=0,
            )

        # Take the best flag pattern
        best = flag_patterns[0]

        if best.confidence < self.min_confidence:
            if self.state.in_position:
                return self._check_exit(current_price, atr_val, symbol)
            return Signal(
                signal_type=SignalType.HOLD, symbol=symbol,
                strategy_name=self.name, confidence=0,
            )

        # Check if breakout is happening (price at/past entry level)
        if best.entry_price is None:
            return Signal(
                signal_type=SignalType.HOLD, symbol=symbol,
                strategy_name=self.name, confidence=0,
            )

        # Bull flag/pennant breakout
        if best.signal == PatternSignal.BULLISH:
            if current_price >= best.entry_price:
                confidence = best.confidence

                # Volume must increase on breakout
                if vol.volume_ratio >= self.volume_breakout_mult:
                    confidence += 0.15
                elif vol.volume_ratio >= 1.0:
                    confidence += 0.05
                else:
                    confidence -= 0.1  # Weak breakout without volume

                # Trend alignment
                if current_price > ema_21:
                    confidence += 0.05

                # RSI filter
                if rsi_val > 80:
                    confidence -= 0.1  # Already overbought

                if confidence >= 0.5:
                    return Signal(
                        signal_type=SignalType.LONG,
                        symbol=symbol,
                        strategy_name=self.name,
                        confidence=min(confidence, 0.9),
                        entry_price=current_price,
                        stop_loss=best.stop_loss or (current_price - atr_val * 2),
                        take_profit=best.take_profit or (current_price + atr_val * 5),
                        reason=f"{best.pattern_type.value} breakout, {best.notes}",
                        metadata={
                            "pattern_type": best.pattern_type.value,
                            "volume_ratio": vol.volume_ratio,
                        },
                    )

        # Bear flag/pennant breakout
        if best.signal == PatternSignal.BEARISH:
            if current_price <= best.entry_price:
                confidence = best.confidence

                if vol.volume_ratio >= self.volume_breakout_mult:
                    confidence += 0.15
                elif vol.volume_ratio >= 1.0:
                    confidence += 0.05
                else:
                    confidence -= 0.1

                if current_price < ema_21:
                    confidence += 0.05

                if rsi_val < 20:
                    confidence -= 0.1

                if confidence >= 0.5:
                    return Signal(
                        signal_type=SignalType.SHORT,
                        symbol=symbol,
                        strategy_name=self.name,
                        confidence=min(confidence, 0.9),
                        entry_price=current_price,
                        stop_loss=best.stop_loss or (current_price + atr_val * 2),
                        take_profit=best.take_profit or (current_price - atr_val * 5),
                        reason=f"{best.pattern_type.value} breakout, {best.notes}",
                        metadata={
                            "pattern_type": best.pattern_type.value,
                            "volume_ratio": vol.volume_ratio,
                        },
                    )

        if self.state.in_position:
            return self._check_exit(current_price, atr_val, symbol)

        return Signal(
            signal_type=SignalType.HOLD, symbol=symbol,
            strategy_name=self.name, confidence=0,
        )

    def _check_exit(self, current_price: float, atr_val: float, symbol: str) -> Signal:
        """Check if we should exit based on target or invalidation."""
        if not self.state.in_position or not self.state.last_signal:
            return Signal(
                signal_type=SignalType.HOLD, symbol=symbol,
                strategy_name=self.name, confidence=0,
            )

        last = self.state.last_signal

        if self.state.position_side == SignalType.LONG:
            if last.take_profit and current_price >= last.take_profit:
                return Signal(
                    signal_type=SignalType.EXIT_LONG, symbol=symbol,
                    strategy_name=self.name, confidence=0.8,
                    reason="Flag target reached (pole projection)",
                )
            # Invalidation: price drops below flag low
            if last.stop_loss and current_price <= last.stop_loss:
                return Signal(
                    signal_type=SignalType.EXIT_LONG, symbol=symbol,
                    strategy_name=self.name, confidence=0.9,
                    reason="Flag pattern invalidated",
                )

        if self.state.position_side == SignalType.SHORT:
            if last.take_profit and current_price <= last.take_profit:
                return Signal(
                    signal_type=SignalType.EXIT_SHORT, symbol=symbol,
                    strategy_name=self.name, confidence=0.8,
                    reason="Flag target reached (pole projection)",
                )
            if last.stop_loss and current_price >= last.stop_loss:
                return Signal(
                    signal_type=SignalType.EXIT_SHORT, symbol=symbol,
                    strategy_name=self.name, confidence=0.9,
                    reason="Flag pattern invalidated",
                )

        return Signal(
            signal_type=SignalType.HOLD, symbol=symbol,
            strategy_name=self.name, confidence=0,
        )
