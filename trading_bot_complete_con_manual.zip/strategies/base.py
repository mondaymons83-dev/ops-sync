"""Base strategy class that all trading strategies inherit from.

Implements the Strategy Pattern for pluggable strategies.
Each strategy must implement:
- analyze(): Process market data and generate signals
- should_enter(): Determine if we should open a position
- should_exit(): Determine if we should close a position
"""

from __future__ import annotations

from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from datetime import datetime, timezone
from enum import Enum
from typing import Any, Dict, List, Optional

import pandas as pd

from connectors.base import Candle, OrderSide


class TradingStyle(str, Enum):
    SCALPING = "scalping"
    INTRADAY = "intraday"
    SWING = "swing"


class SignalType(str, Enum):
    LONG = "long"
    SHORT = "short"
    EXIT_LONG = "exit_long"
    EXIT_SHORT = "exit_short"
    HOLD = "hold"


@dataclass
class Signal:
    signal_type: SignalType
    symbol: str
    strategy_name: str
    confidence: float  # 0-1
    entry_price: Optional[float] = None
    stop_loss: Optional[float] = None
    take_profit: Optional[float] = None
    position_size_pct: Optional[float] = None  # % of portfolio
    reason: str = ""
    metadata: Dict[str, Any] = field(default_factory=dict)
    timestamp: datetime = field(default_factory=lambda: datetime.now(timezone.utc))

    @property
    def is_entry(self) -> bool:
        return self.signal_type in (SignalType.LONG, SignalType.SHORT)

    @property
    def is_exit(self) -> bool:
        return self.signal_type in (SignalType.EXIT_LONG, SignalType.EXIT_SHORT)

    @property
    def side(self) -> OrderSide:
        if self.signal_type in (SignalType.LONG, SignalType.EXIT_SHORT):
            return OrderSide.BUY
        return OrderSide.SELL


@dataclass
class StrategyState:
    """Tracks the internal state of a strategy."""
    is_active: bool = True
    in_position: bool = False
    position_side: Optional[SignalType] = None
    entry_price: Optional[float] = None
    entry_time: Optional[datetime] = None
    trade_count: int = 0
    win_count: int = 0
    loss_count: int = 0
    total_pnl: float = 0.0
    last_signal: Optional[Signal] = None


class BaseStrategy(ABC):
    """Abstract base class for all trading strategies."""

    name: str = "base_strategy"
    description: str = ""
    trading_style: TradingStyle = TradingStyle.INTRADAY
    timeframe: str = "1h"
    min_candles: int = 50  # Minimum candles needed to generate signals
    symbols: List[str] = []

    def __init__(self, **kwargs: Any) -> None:
        self.state = StrategyState()
        for key, value in kwargs.items():
            if hasattr(self, key):
                setattr(self, key, value)

    @abstractmethod
    def analyze(self, df: pd.DataFrame, symbol: str) -> Signal:
        """Analyze market data and return a trading signal.

        Args:
            df: DataFrame with columns [open, high, low, close, volume]
            symbol: Trading pair symbol

        Returns:
            Signal object with entry/exit recommendation
        """
        ...

    def should_enter(self, signal: Signal) -> bool:
        """Check if conditions allow entering a trade."""
        if not self.state.is_active:
            return False
        if self.state.in_position:
            return False
        if signal.signal_type == SignalType.HOLD:
            return False
        if signal.confidence < 0.5:
            return False
        return True

    def should_exit(self, signal: Signal, current_price: float) -> bool:
        """Check if we should exit current position."""
        if not self.state.in_position:
            return False
        if signal.is_exit:
            return True

        # Check stop loss
        if self.state.entry_price and self.state.position_side == SignalType.LONG:
            if signal.stop_loss and current_price <= signal.stop_loss:
                return True
            if signal.take_profit and current_price >= signal.take_profit:
                return True

        if self.state.entry_price and self.state.position_side == SignalType.SHORT:
            if signal.stop_loss and current_price >= signal.stop_loss:
                return True
            if signal.take_profit and current_price <= signal.take_profit:
                return True

        return False

    def update_state_on_entry(self, signal: Signal) -> None:
        """Update strategy state when entering a position."""
        self.state.in_position = True
        self.state.position_side = signal.signal_type
        self.state.entry_price = signal.entry_price
        self.state.entry_time = datetime.now(timezone.utc)
        self.state.trade_count += 1
        self.state.last_signal = signal

    def update_state_on_exit(self, exit_price: float) -> None:
        """Update strategy state when exiting a position."""
        if self.state.entry_price:
            if self.state.position_side == SignalType.LONG:
                pnl = (exit_price - self.state.entry_price) / self.state.entry_price
            else:
                pnl = (self.state.entry_price - exit_price) / self.state.entry_price

            self.state.total_pnl += pnl
            if pnl > 0:
                self.state.win_count += 1
            else:
                self.state.loss_count += 1

        self.state.in_position = False
        self.state.position_side = None
        self.state.entry_price = None
        self.state.entry_time = None

    @property
    def win_rate(self) -> float:
        total = self.state.win_count + self.state.loss_count
        return self.state.win_count / total if total > 0 else 0.0

    def get_info(self) -> Dict[str, Any]:
        return {
            "name": self.name,
            "style": self.trading_style.value,
            "timeframe": self.timeframe,
            "trades": self.state.trade_count,
            "win_rate": f"{self.win_rate:.1%}",
            "pnl": f"{self.state.total_pnl:.2%}",
            "in_position": self.state.in_position,
        }
