"""Order Book Imbalance Scalp Strategy.

Detects bid/ask imbalance in the order book for quick entries.
Timeframe: 1m
Hold time: seconds to minutes

Entry Long: Bid volume >> Ask volume (imbalance ratio > threshold)
Entry Short: Ask volume >> Bid volume
Exit: Imbalance normalizes or quick profit target hit
"""

from __future__ import annotations

from typing import Dict, List

import pandas as pd

from indicators.technical import rsi, atr
from strategies.base import BaseStrategy, Signal, SignalType, TradingStyle


class OrderBookImbalanceScalp(BaseStrategy):
    name = "orderbook_imbalance_scalp"
    description = "Order book bid/ask imbalance for ultra-fast scalping"
    trading_style = TradingStyle.SCALPING
    timeframe = "1m"
    min_candles = 10

    imbalance_threshold: float = 2.0  # Bid/ask ratio threshold
    profit_target_atr_mult: float = 0.5
    stop_loss_atr_mult: float = 0.3

    def analyze(self, df: pd.DataFrame, symbol: str) -> Signal:
        if len(df) < self.min_candles:
            return Signal(signal_type=SignalType.HOLD, symbol=symbol,
                          strategy_name=self.name, confidence=0)

        close = df["close"]
        current_price = float(close.iloc[-1])
        rsi_val = float(rsi(close, 14).iloc[-1])
        atr_val = float(atr(df, 14).iloc[-1])

        # Use price action as proxy for order flow when orderbook not available
        # Detect buying/selling pressure from candle structure
        last_5 = df.tail(5)
        buy_pressure = 0.0
        sell_pressure = 0.0

        for _, candle in last_5.iterrows():
            body = candle["close"] - candle["open"]
            total_range = candle["high"] - candle["low"]
            if total_range == 0:
                continue

            if body > 0:  # Bullish candle
                buy_pressure += (body / total_range) * candle["volume"]
            else:
                sell_pressure += (abs(body) / total_range) * candle["volume"]

        if sell_pressure == 0:
            imbalance_ratio = buy_pressure / 1.0 if buy_pressure > 0 else 1.0
        elif buy_pressure == 0:
            imbalance_ratio = -sell_pressure / 1.0 if sell_pressure > 0 else 1.0
        else:
            imbalance_ratio = buy_pressure / sell_pressure

        # Long: strong buying pressure
        if imbalance_ratio > self.imbalance_threshold and rsi_val < 70:
            confidence = min(0.5 + (imbalance_ratio - self.imbalance_threshold) * 0.1, 0.85)

            return Signal(
                signal_type=SignalType.LONG,
                symbol=symbol,
                strategy_name=self.name,
                confidence=confidence,
                entry_price=current_price,
                stop_loss=current_price - atr_val * self.stop_loss_atr_mult,
                take_profit=current_price + atr_val * self.profit_target_atr_mult,
                reason=f"Buy imbalance ratio: {imbalance_ratio:.2f}",
                metadata={"imbalance_ratio": imbalance_ratio},
            )

        # Short: strong selling pressure
        if imbalance_ratio < (1 / self.imbalance_threshold) and rsi_val > 30:
            confidence = min(0.5 + ((1 / imbalance_ratio) - self.imbalance_threshold) * 0.1, 0.85)

            return Signal(
                signal_type=SignalType.SHORT,
                symbol=symbol,
                strategy_name=self.name,
                confidence=confidence,
                entry_price=current_price,
                stop_loss=current_price + atr_val * self.stop_loss_atr_mult,
                take_profit=current_price - atr_val * self.profit_target_atr_mult,
                reason=f"Sell imbalance ratio: {1/imbalance_ratio:.2f}",
                metadata={"imbalance_ratio": imbalance_ratio},
            )

        return Signal(signal_type=SignalType.HOLD, symbol=symbol,
                      strategy_name=self.name, confidence=0)

    def analyze_with_orderbook(
        self,
        df: pd.DataFrame,
        symbol: str,
        orderbook: Dict[str, List[List[float]]],
    ) -> Signal:
        """Enhanced analysis using actual orderbook data."""
        if not orderbook or not orderbook.get("bids") or not orderbook.get("asks"):
            return self.analyze(df, symbol)

        close = df["close"]
        current_price = float(close.iloc[-1])
        atr_val = float(atr(df, 14).iloc[-1])

        bid_volume = sum(level[1] for level in orderbook["bids"][:10])
        ask_volume = sum(level[1] for level in orderbook["asks"][:10])

        if ask_volume == 0:
            ratio = 10.0
        else:
            ratio = bid_volume / ask_volume

        if ratio > self.imbalance_threshold:
            confidence = min(0.5 + (ratio - self.imbalance_threshold) * 0.15, 0.9)
            return Signal(
                signal_type=SignalType.LONG,
                symbol=symbol,
                strategy_name=self.name,
                confidence=confidence,
                entry_price=current_price,
                stop_loss=current_price - atr_val * self.stop_loss_atr_mult,
                take_profit=current_price + atr_val * self.profit_target_atr_mult,
                reason=f"Orderbook bid/ask ratio: {ratio:.2f}",
            )

        if ratio < (1 / self.imbalance_threshold):
            confidence = min(0.5 + ((1 / ratio) - self.imbalance_threshold) * 0.15, 0.9)
            return Signal(
                signal_type=SignalType.SHORT,
                symbol=symbol,
                strategy_name=self.name,
                confidence=confidence,
                entry_price=current_price,
                stop_loss=current_price + atr_val * self.stop_loss_atr_mult,
                take_profit=current_price - atr_val * self.profit_target_atr_mult,
                reason=f"Orderbook ask/bid ratio: {1/ratio:.2f}",
            )

        return Signal(signal_type=SignalType.HOLD, symbol=symbol,
                      strategy_name=self.name, confidence=0)
