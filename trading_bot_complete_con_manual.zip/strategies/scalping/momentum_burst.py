"""Momentum Burst Scalp Strategy.

Detects sudden momentum bursts using RSI + MACD divergence on short timeframes.
Combined with volume spike detection for confirmation.
Timeframe: 1m-5m

Entry Long: RSI crosses above 50 + MACD histogram turns positive + volume spike
Entry Short: RSI crosses below 50 + MACD histogram turns negative + volume spike
Exit: Momentum fades (histogram shrinks) or trailing stop
"""

from __future__ import annotations

import pandas as pd

from indicators.technical import rsi, macd, atr, ema
from indicators.volume import volume_profile
from strategies.base import BaseStrategy, Signal, SignalType, TradingStyle


class MomentumBurstScalp(BaseStrategy):
    name = "momentum_burst_scalp"
    description = "Momentum burst detection with RSI/MACD/Volume confirmation"
    trading_style = TradingStyle.SCALPING
    timeframe = "1m"
    min_candles = 30

    rsi_period: int = 7  # Shorter for scalping
    macd_fast: int = 8
    macd_slow: int = 21
    macd_signal: int = 5
    volume_spike_mult: float = 2.0

    def analyze(self, df: pd.DataFrame, symbol: str) -> Signal:
        if len(df) < self.min_candles:
            return Signal(signal_type=SignalType.HOLD, symbol=symbol,
                          strategy_name=self.name, confidence=0)

        close = df["close"]
        current_price = float(close.iloc[-1])

        # Indicators
        rsi_val = rsi(close, self.rsi_period)
        macd_result = macd(close, self.macd_fast, self.macd_slow, self.macd_signal)
        atr_val = float(atr(df, 14).iloc[-1])
        vol = volume_profile(df, 20)

        current_rsi = float(rsi_val.iloc[-1])
        prev_rsi = float(rsi_val.iloc[-2])
        current_hist = float(macd_result.histogram.iloc[-1])
        prev_hist = float(macd_result.histogram.iloc[-2])
        prev_prev_hist = float(macd_result.histogram.iloc[-3]) if len(df) > 3 else prev_hist

        # Momentum burst detection
        hist_accelerating_up = current_hist > prev_hist > prev_prev_hist
        hist_accelerating_down = current_hist < prev_hist < prev_prev_hist
        rsi_crossing_up = prev_rsi < 50 and current_rsi > 50
        rsi_crossing_down = prev_rsi > 50 and current_rsi < 50

        # Price momentum - last 3 candles
        price_momentum = (float(close.iloc[-1]) - float(close.iloc[-3])) / float(close.iloc[-3])

        # Long: bullish momentum burst
        if (hist_accelerating_up or rsi_crossing_up) and current_hist > 0:
            confidence = 0.5
            if vol.is_high_volume:
                confidence += 0.15
            if rsi_crossing_up:
                confidence += 0.1
            if hist_accelerating_up:
                confidence += 0.1
            if price_momentum > 0.001:
                confidence += 0.05

            return Signal(
                signal_type=SignalType.LONG,
                symbol=symbol,
                strategy_name=self.name,
                confidence=min(confidence, 0.9),
                entry_price=current_price,
                stop_loss=current_price - atr_val * 1.0,
                take_profit=current_price + atr_val * 1.5,
                reason=f"Bullish momentum burst, RSI={current_rsi:.1f}, MACD hist={current_hist:.4f}",
                metadata={"price_momentum": price_momentum, "volume_ratio": vol.volume_ratio},
            )

        # Short: bearish momentum burst
        if (hist_accelerating_down or rsi_crossing_down) and current_hist < 0:
            confidence = 0.5
            if vol.is_high_volume:
                confidence += 0.15
            if rsi_crossing_down:
                confidence += 0.1
            if hist_accelerating_down:
                confidence += 0.1
            if price_momentum < -0.001:
                confidence += 0.05

            return Signal(
                signal_type=SignalType.SHORT,
                symbol=symbol,
                strategy_name=self.name,
                confidence=min(confidence, 0.9),
                entry_price=current_price,
                stop_loss=current_price + atr_val * 1.0,
                take_profit=current_price - atr_val * 1.5,
                reason=f"Bearish momentum burst, RSI={current_rsi:.1f}, MACD hist={current_hist:.4f}",
                metadata={"price_momentum": price_momentum, "volume_ratio": vol.volume_ratio},
            )

        # Exit: momentum fading
        if self.state.in_position:
            if self.state.position_side == SignalType.LONG:
                if current_hist < prev_hist and current_rsi > 70:
                    return Signal(
                        signal_type=SignalType.EXIT_LONG, symbol=symbol,
                        strategy_name=self.name, confidence=0.7,
                        reason="Bullish momentum fading",
                    )
            elif self.state.position_side == SignalType.SHORT:
                if current_hist > prev_hist and current_rsi < 30:
                    return Signal(
                        signal_type=SignalType.EXIT_SHORT, symbol=symbol,
                        strategy_name=self.name, confidence=0.7,
                        reason="Bearish momentum fading",
                    )

        return Signal(signal_type=SignalType.HOLD, symbol=symbol,
                      strategy_name=self.name, confidence=0)
