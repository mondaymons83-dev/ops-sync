"""Bollinger Band Bounce Scalp Strategy.

Price touches or penetrates Bollinger Band then reverses.
Uses volume confirmation and RSI for entry timing.
Timeframe: 1m-5m

Entry Long: Price touches lower BB + RSI oversold + volume spike
Entry Short: Price touches upper BB + RSI overbought + volume spike
Exit: Price reaches middle BB or opposite band
"""

from __future__ import annotations

import pandas as pd

from indicators.technical import bollinger_bands, rsi, atr, sma
from indicators.volume import volume_profile
from strategies.base import BaseStrategy, Signal, SignalType, TradingStyle


class BollingerBounceScalp(BaseStrategy):
    name = "bollinger_bounce_scalp"
    description = "Bollinger Band bounce with volume and RSI confirmation"
    trading_style = TradingStyle.SCALPING
    timeframe = "1m"
    min_candles = 25

    bb_period: int = 20
    bb_std: float = 2.0
    rsi_period: int = 14

    def analyze(self, df: pd.DataFrame, symbol: str) -> Signal:
        if len(df) < self.min_candles:
            return Signal(signal_type=SignalType.HOLD, symbol=symbol,
                          strategy_name=self.name, confidence=0)

        close = df["close"]
        bb = bollinger_bands(close, self.bb_period, self.bb_std)
        rsi_val = rsi(close, self.rsi_period)
        vol = volume_profile(df)
        atr_val = float(atr(df, 14).iloc[-1])

        current_price = float(close.iloc[-1])
        current_rsi = float(rsi_val.iloc[-1])
        upper = float(bb.upper.iloc[-1])
        lower = float(bb.lower.iloc[-1])
        middle = float(bb.middle.iloc[-1])
        pct_b = float(bb.percent_b.iloc[-1])

        # Long: price at or below lower band
        if pct_b <= 0.05 and current_rsi < 35:
            confidence = 0.55
            if vol.is_high_volume:
                confidence += 0.15
            if current_rsi < 25:
                confidence += 0.1

            return Signal(
                signal_type=SignalType.LONG,
                symbol=symbol,
                strategy_name=self.name,
                confidence=confidence,
                entry_price=current_price,
                stop_loss=lower - atr_val * 0.5,
                take_profit=middle,
                reason=f"BB lower bounce, %B={pct_b:.2f}, RSI={current_rsi:.1f}",
            )

        # Short: price at or above upper band
        if pct_b >= 0.95 and current_rsi > 65:
            confidence = 0.55
            if vol.is_high_volume:
                confidence += 0.15
            if current_rsi > 75:
                confidence += 0.1

            return Signal(
                signal_type=SignalType.SHORT,
                symbol=symbol,
                strategy_name=self.name,
                confidence=confidence,
                entry_price=current_price,
                stop_loss=upper + atr_val * 0.5,
                take_profit=middle,
                reason=f"BB upper bounce, %B={pct_b:.2f}, RSI={current_rsi:.1f}",
            )

        # Exit at middle band
        if self.state.in_position:
            if self.state.position_side == SignalType.LONG and current_price >= middle:
                return Signal(
                    signal_type=SignalType.EXIT_LONG,
                    symbol=symbol,
                    strategy_name=self.name,
                    confidence=0.7,
                    reason="Reached middle BB",
                )
            if self.state.position_side == SignalType.SHORT and current_price <= middle:
                return Signal(
                    signal_type=SignalType.EXIT_SHORT,
                    symbol=symbol,
                    strategy_name=self.name,
                    confidence=0.7,
                    reason="Reached middle BB",
                )

        return Signal(signal_type=SignalType.HOLD, symbol=symbol,
                      strategy_name=self.name, confidence=0)
