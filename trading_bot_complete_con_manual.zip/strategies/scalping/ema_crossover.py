"""EMA Crossover Scalp Strategy.

Fast EMA crosses slow EMA with RSI confirmation.
Timeframe: 1m-5m
Hold time: 1-15 minutes

Entry Long: Fast EMA crosses above Slow EMA + RSI > 50 + RSI < 70
Entry Short: Fast EMA crosses below Slow EMA + RSI < 50 + RSI > 30
Exit: Opposite crossover or RSI extreme
"""

from __future__ import annotations

import pandas as pd

from indicators.technical import ema, rsi, atr, candles_to_df
from strategies.base import BaseStrategy, Signal, SignalType, TradingStyle


class EMAcrossoverScalp(BaseStrategy):
    name = "ema_crossover_scalp"
    description = "Fast/Slow EMA crossover with RSI filter for scalping"
    trading_style = TradingStyle.SCALPING
    timeframe = "1m"
    min_candles = 30

    fast_period: int = 8
    slow_period: int = 21
    rsi_period: int = 14
    rsi_overbought: float = 70.0
    rsi_oversold: float = 30.0

    def analyze(self, df: pd.DataFrame, symbol: str) -> Signal:
        if len(df) < self.min_candles:
            return Signal(signal_type=SignalType.HOLD, symbol=symbol,
                          strategy_name=self.name, confidence=0)

        close = df["close"]
        fast_ema = ema(close, self.fast_period)
        slow_ema = ema(close, self.slow_period)
        rsi_val = rsi(close, self.rsi_period)
        atr_val = atr(df, 14)

        current_fast = float(fast_ema.iloc[-1])
        current_slow = float(slow_ema.iloc[-1])
        prev_fast = float(fast_ema.iloc[-2])
        prev_slow = float(slow_ema.iloc[-2])
        current_rsi = float(rsi_val.iloc[-1])
        current_atr = float(atr_val.iloc[-1])
        current_price = float(close.iloc[-1])

        # Bullish crossover
        if prev_fast <= prev_slow and current_fast > current_slow:
            if self.rsi_oversold < current_rsi < self.rsi_overbought:
                confidence = 0.6
                if 50 < current_rsi < 65:
                    confidence += 0.1
                return Signal(
                    signal_type=SignalType.LONG,
                    symbol=symbol,
                    strategy_name=self.name,
                    confidence=confidence,
                    entry_price=current_price,
                    stop_loss=current_price - current_atr * 1.5,
                    take_profit=current_price + current_atr * 2.0,
                    reason=f"Bullish EMA crossover, RSI={current_rsi:.1f}",
                )

        # Bearish crossover
        if prev_fast >= prev_slow and current_fast < current_slow:
            if self.rsi_oversold < current_rsi < self.rsi_overbought:
                confidence = 0.6
                if 35 < current_rsi < 50:
                    confidence += 0.1
                return Signal(
                    signal_type=SignalType.SHORT,
                    symbol=symbol,
                    strategy_name=self.name,
                    confidence=confidence,
                    entry_price=current_price,
                    stop_loss=current_price + current_atr * 1.5,
                    take_profit=current_price - current_atr * 2.0,
                    reason=f"Bearish EMA crossover, RSI={current_rsi:.1f}",
                )

        # Exit signals
        if self.state.in_position:
            if self.state.position_side == SignalType.LONG and current_rsi > self.rsi_overbought:
                return Signal(
                    signal_type=SignalType.EXIT_LONG,
                    symbol=symbol,
                    strategy_name=self.name,
                    confidence=0.7,
                    reason="RSI overbought exit",
                )
            if self.state.position_side == SignalType.SHORT and current_rsi < self.rsi_oversold:
                return Signal(
                    signal_type=SignalType.EXIT_SHORT,
                    symbol=symbol,
                    strategy_name=self.name,
                    confidence=0.7,
                    reason="RSI oversold exit",
                )

        return Signal(signal_type=SignalType.HOLD, symbol=symbol,
                      strategy_name=self.name, confidence=0)
