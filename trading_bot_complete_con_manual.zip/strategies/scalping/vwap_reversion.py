"""VWAP Mean Reversion Scalp Strategy.

Price reverts to VWAP after significant deviation.
Timeframe: 1m-5m

Entry Long: Price > 1.5 ATR below VWAP + RSI oversold
Entry Short: Price > 1.5 ATR above VWAP + RSI overbought
Exit: Price returns to VWAP or small profit target
"""

from __future__ import annotations

import pandas as pd

from indicators.technical import vwap, rsi, atr
from strategies.base import BaseStrategy, Signal, SignalType, TradingStyle


class VWAPReversionScalp(BaseStrategy):
    name = "vwap_reversion_scalp"
    description = "Mean reversion to VWAP with ATR deviation filter"
    trading_style = TradingStyle.SCALPING
    timeframe = "1m"
    min_candles = 30

    atr_multiplier: float = 1.5
    rsi_period: int = 14

    def analyze(self, df: pd.DataFrame, symbol: str) -> Signal:
        if len(df) < self.min_candles:
            return Signal(signal_type=SignalType.HOLD, symbol=symbol,
                          strategy_name=self.name, confidence=0)

        close = df["close"]
        vwap_val = vwap(df)
        rsi_val = rsi(close, self.rsi_period)
        atr_val = atr(df, 14)

        current_price = float(close.iloc[-1])
        current_vwap = float(vwap_val.iloc[-1])
        current_rsi = float(rsi_val.iloc[-1])
        current_atr = float(atr_val.iloc[-1])

        deviation = current_price - current_vwap
        atr_threshold = current_atr * self.atr_multiplier

        # Long: price significantly below VWAP
        if deviation < -atr_threshold and current_rsi < 40:
            confidence = 0.55
            if current_rsi < 30:
                confidence += 0.1
            if abs(deviation) > atr_threshold * 2:
                confidence += 0.1

            return Signal(
                signal_type=SignalType.LONG,
                symbol=symbol,
                strategy_name=self.name,
                confidence=confidence,
                entry_price=current_price,
                stop_loss=current_price - current_atr,
                take_profit=current_vwap,
                reason=f"Below VWAP by {abs(deviation)/current_atr:.1f} ATR, RSI={current_rsi:.1f}",
            )

        # Short: price significantly above VWAP
        if deviation > atr_threshold and current_rsi > 60:
            confidence = 0.55
            if current_rsi > 70:
                confidence += 0.1
            if deviation > atr_threshold * 2:
                confidence += 0.1

            return Signal(
                signal_type=SignalType.SHORT,
                symbol=symbol,
                strategy_name=self.name,
                confidence=confidence,
                entry_price=current_price,
                stop_loss=current_price + current_atr,
                take_profit=current_vwap,
                reason=f"Above VWAP by {deviation/current_atr:.1f} ATR, RSI={current_rsi:.1f}",
            )

        # Exit when price returns to VWAP
        if self.state.in_position:
            if self.state.position_side == SignalType.LONG and current_price >= current_vwap:
                return Signal(
                    signal_type=SignalType.EXIT_LONG, symbol=symbol,
                    strategy_name=self.name, confidence=0.8,
                    reason="Price returned to VWAP",
                )
            if self.state.position_side == SignalType.SHORT and current_price <= current_vwap:
                return Signal(
                    signal_type=SignalType.EXIT_SHORT, symbol=symbol,
                    strategy_name=self.name, confidence=0.8,
                    reason="Price returned to VWAP",
                )

        return Signal(signal_type=SignalType.HOLD, symbol=symbol,
                      strategy_name=self.name, confidence=0)
