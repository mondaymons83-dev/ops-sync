# Trading Bot - Manual para Agente Bot

Este manual está diseñado para que un agente bot (AI) pueda operar el trading bot de forma autónoma sin intervención humana.

---

## 1. INSTALACIÓN

```bash
# Entrar al directorio del proyecto
cd trading_bot

# Instalar dependencias con Poetry
poetry install

# Copiar configuración (si no existe .env)
cp .env.example .env
```

### Verificar instalación
```bash
poetry run python -c "import sys; sys.path.insert(0,'.'); from app.cli import cli; print('OK')"
```

---

## 2. CONFIGURACIÓN (.env)

El archivo `.env` controla todo el comportamiento del bot. Variables críticas:

```env
# MODO DE OPERACIÓN
PAPER_MODE=true          # true = trading simulado (sin dinero real), false = trading real
TEST_MODE=true           # true = usa datos sintéticos, false = datos reales del exchange

# EXCHANGE (elegir uno)
DEFAULT_EXCHANGE=binance  # opciones: binance, coinbase, dex

# API KEYS (solo necesario si PAPER_MODE=false)
BINANCE_API_KEY=tu_key
BINANCE_API_SECRET=tu_secret
COINBASE_API_KEY=tu_key
COINBASE_API_SECRET=tu_secret
COINBASE_PASSPHRASE=tu_passphrase

# DEX (Uniswap)
WEB3_RPC_URL=https://eth-mainnet.g.alchemy.com/v2/tu_key
WALLET_ADDRESS=0x...
WALLET_PRIVATE_KEY=0x...

# TRADING
DEFAULT_SYMBOL=BTC/USDT   # par a tradear
POSITION_SIZING_METHOD=kelly  # opciones: kelly, fixed, atr

# RIESGO
MAX_POSITION_SIZE_PCT=5.0    # máximo % del portfolio por trade
MAX_OPEN_POSITIONS=5          # máximo de posiciones abiertas simultáneas
MAX_DAILY_LOSS_PCT=5.0        # si pierde este %, para de tradear el día
MAX_DRAWDOWN_PCT=15.0         # si el drawdown llega a esto, para todo
RISK_REWARD_MIN=1.5           # mínimo ratio riesgo/recompensa aceptable
```

### Cambiar configuración desde código Python:
```python
import os
os.environ["PAPER_MODE"] = "true"
os.environ["DEFAULT_SYMBOL"] = "ETH/USDT"
os.environ["POSITION_SIZING_METHOD"] = "fixed"
```

---

## 3. COMANDOS CLI

Todos los comandos se ejecutan con `poetry run tradingbot <comando>` o desde Python.

### 3.1 Listar estrategias disponibles
```bash
poetry run tradingbot strategies
```
Muestra las 15 estrategias con nombre, estilo, timeframe y descripción.

### 3.2 Ver estado y configuración actual
```bash
poetry run tradingbot status
```
Muestra: modo (paper/live), exchange, parámetros de riesgo, timeframes, estado de API keys.

### 3.3 Iniciar trading
```bash
# Trading con TODAS las estrategias (paper mode por defecto)
poetry run tradingbot run

# Solo estrategias de un estilo específico
poetry run tradingbot run --style scalping
poetry run tradingbot run --style intraday
poetry run tradingbot run --style swing

# Cambiar símbolo y exchange
poetry run tradingbot run --symbol ETH/USDT --exchange binance

# Cambiar intervalo de polling (segundos)
poetry run tradingbot run --interval 30

# Trading en vivo (CUIDADO - usa dinero real)
poetry run tradingbot run --live
```

### 3.4 Backtesting
```bash
# Backtest de TODAS las estrategias
poetry run tradingbot backtest

# Backtest de un estilo específico
poetry run tradingbot backtest --style swing
poetry run tradingbot backtest --style intraday
poetry run tradingbot backtest --style scalping

# Backtest de una estrategia específica por nombre
poetry run tradingbot backtest --strategy elliott_full_cycle_swing

# Cambiar parámetros
poetry run tradingbot backtest --bars 1000 --capital 50000 --symbol ETH/USDT
```

---

## 4. USO DESDE PYTHON (para agente bot)

### 4.1 Importar y ejecutar una estrategia individual
```python
import sys
sys.path.insert(0, '/ruta/al/trading_bot')

import pandas as pd
import numpy as np

# Crear datos sintéticos de ejemplo
def crear_datos(bars=200, precio_base=50000.0):
    np.random.seed(42)
    dates = pd.date_range(end=pd.Timestamp.now(), periods=bars, freq="4h")
    prices = [precio_base]
    for _ in range(bars - 1):
        change = np.random.normal(0, 0.02) * prices[-1]
        prices.append(max(prices[-1] + change, 100))
    df = pd.DataFrame(index=dates)
    df["close"] = prices
    df["open"] = df["close"].shift(1).fillna(precio_base)
    df["high"] = df[["open", "close"]].max(axis=1) * (1 + np.random.uniform(0, 0.01, bars))
    df["low"] = df[["open", "close"]].min(axis=1) * (1 - np.random.uniform(0, 0.01, bars))
    df["volume"] = np.random.uniform(100, 1000, bars)
    return df

# Instanciar estrategia
from strategies.swing.divergence import DivergenceSwing
strategy = DivergenceSwing()

# Generar señal
df = crear_datos(200)
signal = strategy.analyze(df, "BTC/USDT")

print(f"Señal: {signal.signal_type.value}")
print(f"Confianza: {signal.confidence}")
print(f"Precio entrada: {signal.entry_price}")
print(f"Stop loss: {signal.stop_loss}")
print(f"Take profit: {signal.take_profit}")
print(f"Razón: {signal.reason}")
```

### 4.2 Correr backtesting desde Python
```python
from backtesting.engine import BacktestEngine
from strategies.swing.elliott_full_cycle import ElliottFullCycleSwing

strategy = ElliottFullCycleSwing()
df = crear_datos(500)

engine = BacktestEngine(
    strategy=strategy,
    df=df,
    initial_capital=10000.0,
    commission_pct=0.1,    # 0.1% comisión
    slippage_pct=0.05,     # 0.05% slippage
)

result = engine.run(symbol="BTC/USDT")

# Ver resumen
result.print_summary()

# Acceder a métricas individuales
print(f"Retorno total: {result.total_return_pct}%")
print(f"Sharpe ratio: {result.sharpe_ratio}")
print(f"Sortino ratio: {result.sortino_ratio}")
print(f"Max drawdown: {result.max_drawdown_pct}%")
print(f"Win rate: {result.win_rate}%")
print(f"Profit factor: {result.profit_factor}")
print(f"Total trades: {result.total_trades}")

# Acceder a la curva de equity
equity_curve = result.equity_curve  # Lista de floats

# Acceder a trades individuales
for trade in result.trades:
    print(f"  {trade.side} | Entry: {trade.entry_price:.2f} | "
          f"Exit: {trade.exit_price:.2f} | PnL: {trade.pnl:+.2f} | "
          f"Razón salida: {trade.reason_exit}")
```

### 4.3 Risk Manager independiente
```python
from core.risk_manager import RiskManager

rm = RiskManager(
    portfolio_value=10000.0,
    sizing_method="kelly",       # "kelly", "fixed", o "atr"
    max_position_pct=5.0,
    max_open_positions=5,
    max_daily_loss_pct=5.0,
    max_drawdown_pct=15.0,
    min_risk_reward=1.5,
)

# Evaluar un trade potencial
check = rm.check_risk(
    entry_price=50000.0,
    stop_loss=49000.0,       # $1000 de riesgo
    take_profit=52000.0,     # $2000 de ganancia
    confidence=0.7,
    win_rate=0.55,
    atr_value=800.0,
)

print(f"Aprobado: {check.approved}")
print(f"Tamaño posición: {check.position_size} unidades")
print(f"Tamaño %: {check.position_size_pct}%")
print(f"Risk/Reward: {check.risk_reward_ratio}")
print(f"Razón: {check.reason}")

# Registrar trades
rm.on_position_opened()
rm.on_position_closed(pnl=150.0)  # Ganancia de $150

# Ver estadísticas
stats = rm.get_stats()
print(stats)
```

### 4.4 Trading Engine completo (async)
```python
import asyncio

from connectors.binance_connector import BinanceConnector
from core.engine import EngineConfig, TradingEngine
from core.risk_manager import RiskManager
from strategies.intraday.sr_breakout import SRBreakoutIntraday
from strategies.intraday.ma_ribbon import MARibbonIntraday
from strategies.swing.golden_cross import GoldenDeathCrossSwing

async def main():
    connector = BinanceConnector()  # Usa paper mode si PAPER_MODE=true en .env
    
    strategies = [
        SRBreakoutIntraday(),
        MARibbonIntraday(),
        GoldenDeathCrossSwing(),
    ]
    
    risk_manager = RiskManager(
        portfolio_value=10000.0,
        sizing_method="kelly",
    )
    
    engine = TradingEngine(
        connector=connector,
        strategies=strategies,
        risk_manager=risk_manager,
        config=EngineConfig(
            symbols=["BTC/USDT", "ETH/USDT"],
            poll_interval_seconds=60,
            max_signals_per_cycle=3,
            trailing_stop_pct=1.5,
        ),
    )
    
    # Opción A: Correr un solo ciclo (útil para testing)
    result = await engine.run_single_cycle()
    print(result)
    
    # Opción B: Correr loop continuo (se detiene con Ctrl+C)
    # await engine.start()
    
    # Ver estado
    status = engine.get_status()
    print(status)

asyncio.run(main())
```

---

## 5. LISTA COMPLETA DE ESTRATEGIAS

### Scalping (timeframe: 1m, hold: 1-15 min)
| # | Nombre | Descripción |
|---|--------|-------------|
| 1 | `ema_crossover_scalp` | EMA 8/21 crossover con filtro RSI |
| 2 | `bollinger_bounce_scalp` | Rebote en Bollinger Bands con volumen |
| 3 | `vwap_reversion_scalp` | Reversión a la media VWAP |
| 4 | `orderbook_imbalance_scalp` | Imbalance bid/ask del order book |
| 5 | `momentum_burst_scalp` | Burst de momentum RSI+MACD+Volumen |

### Intraday (timeframe: 15m, hold: 2-8 hrs)
| # | Nombre | Descripción |
|---|--------|-------------|
| 6 | `sr_breakout_intraday` | Breakout de soporte/resistencia con volumen |
| 7 | `elliott_impulse_intraday` | Entrada en Wave 3 (método Ramki) |
| 8 | `ma_ribbon_intraday` | Ribbon de MAs (8,13,21,34,55) fan-out |
| 9 | `fib_retracement_intraday` | Rebote en niveles Fibonacci (38.2/50/61.8%) |
| 10 | `pattern_detection_intraday` | Patrones: H&S, triángulos, flags, wedges |

### Swing (timeframe: 4h, hold: 2-14 días)
| # | Nombre | Descripción |
|---|--------|-------------|
| 11 | `elliott_full_cycle_swing` | Ciclo completo Elliott 5 ondas + ABC |
| 12 | `golden_death_cross_swing` | Golden/Death Cross 50/200 SMA + ADX |
| 13 | `multi_timeframe_swing` | Tendencia HTF + entrada en LTF pullback |
| 14 | `divergence_swing` | Divergencias RSI/MACD para reversiones |
| 15 | `flag_breakout_swing` | Breakout de bull/bear flags con proyección |

---

## 6. ESTRUCTURA DE SEÑALES

Toda estrategia devuelve un objeto `Signal` con estos campos:

```python
signal.signal_type    # "long", "short", "exit_long", "exit_short", "hold"
signal.symbol         # "BTC/USDT"
signal.strategy_name  # "elliott_impulse_intraday"
signal.confidence     # 0.0 a 1.0 (mínimo 0.5 para ejecutar)
signal.entry_price    # precio de entrada sugerido
signal.stop_loss      # precio de stop loss
signal.take_profit    # precio de take profit
signal.reason         # texto explicando la señal
signal.metadata       # dict con datos extra de la estrategia
signal.is_entry       # True si es LONG o SHORT
signal.is_exit        # True si es EXIT_LONG o EXIT_SHORT
signal.side           # OrderSide.BUY o OrderSide.SELL
```

---

## 7. FLUJO DE DECISIÓN DEL ENGINE

```
1. Fetch candles del exchange
2. Para cada estrategia:
   a. strategy.analyze(df, symbol) → Signal
   b. Si signal != HOLD → agregar a lista
3. Ordenar señales por confianza (mayor primero)
4. Procesar exits primero:
   a. strategy.should_exit(signal, price) → True/False
   b. Si True → cerrar posición → calcular PnL
5. Procesar entries:
   a. strategy.should_enter(signal) → True/False
   b. risk_manager.check_risk(...) → RiskCheck
   c. Si aprobado → order_manager.submit_order(signal, amount)
6. Monitorear posiciones abiertas:
   a. Trailing stop → actualizar y verificar
   b. Stop loss fijo → verificar
   c. Take profit → verificar
   d. Max hold time → verificar
7. Repetir cada N segundos (configurable)
```

---

## 8. ARCHIVOS DEL PROYECTO

```
trading_bot/
├── app/
│   ├── config.py          # Configuración centralizada (.env)
│   └── cli.py             # Interfaz CLI (Click)
├── connectors/
│   ├── base.py            # Interfaz abstracta de connectors
│   ├── binance_connector.py
│   ├── coinbase_connector.py
│   └── dex_connector.py   # Uniswap V2
├── core/
│   ├── engine.py          # Trading Engine principal
│   ├── risk_manager.py    # Gestión de riesgo y position sizing
│   └── order_manager.py   # Tracking de órdenes y trailing stops
├── indicators/
│   ├── technical.py       # RSI, MACD, BB, EMA, SMA, ATR, etc.
│   ├── fibonacci.py       # Retracimientos y extensiones Fib
│   ├── elliott_wave.py    # Detector de ondas Elliott
│   ├── patterns.py        # Reconocimiento de patrones gráficos
│   └── volume.py          # Análisis de volumen
├── strategies/
│   ├── base.py            # BaseStrategy + Signal + StrategyState
│   ├── scalping/          # 5 estrategias scalping (1m)
│   ├── intraday/          # 5 estrategias intraday (15m)
│   └── swing/             # 5 estrategias swing (4h)
├── backtesting/
│   └── engine.py          # Motor de backtesting
├── .env.example           # Template de configuración
└── pyproject.toml         # Dependencias (Poetry)
```

---

## 9. ERRORES COMUNES Y SOLUCIONES

| Error | Causa | Solución |
|-------|-------|----------|
| `ModuleNotFoundError` | Dependencias no instaladas | `poetry install` |
| `No candles returned` | Exchange no accesible en test mode | Poner `TEST_MODE=true` en `.env` |
| `Risk check rejected: Max open positions` | Ya hay 5 posiciones abiertas | Esperar que cierren o aumentar `MAX_OPEN_POSITIONS` |
| `Risk check rejected: Daily loss limit` | Se alcanzó el límite diario | Esperar al día siguiente o ajustar `MAX_DAILY_LOSS_PCT` |
| `Risk/reward too low` | La señal no tiene suficiente R:R | Ajustar `RISK_REWARD_MIN` en `.env` |
| Signal siempre `HOLD` | No hay suficientes candles | Aumentar la cantidad de datos históricos |

---

## 10. EJEMPLO COMPLETO: WORKFLOW DE AGENTE BOT

```python
"""
Workflow completo para un agente bot que opera el trading bot.
Ejecutar este script periódicamente (ej: cada hora).
"""
import sys
sys.path.insert(0, '/ruta/al/trading_bot')

import os
os.environ["PAPER_MODE"] = "true"
os.environ["TEST_MODE"] = "true"

import asyncio
from connectors.binance_connector import BinanceConnector
from core.engine import EngineConfig, TradingEngine
from core.risk_manager import RiskManager
from strategies.intraday import *
from strategies.swing import *

async def ciclo_trading():
    connector = BinanceConnector()
    
    strategies = [
        SRBreakoutIntraday(),
        ElliottImpulseIntraday(),
        MARibbonIntraday(),
        FibRetracementIntraday(),
        PatternDetectionIntraday(),
        ElliottFullCycleSwing(),
        GoldenDeathCrossSwing(),
        MultiTimeframeSwing(),
        DivergenceSwing(),
        FlagBreakoutSwing(),
    ]
    
    engine = TradingEngine(
        connector=connector,
        strategies=strategies,
        config=EngineConfig(
            symbols=["BTC/USDT"],
            poll_interval_seconds=60,
        ),
    )
    
    # Correr un ciclo
    result = await engine.run_single_cycle()
    
    # Interpretar resultado
    status = engine.get_status()
    
    # Decisiones del agente basadas en el estado:
    risk = status["risk"]
    portfolio = status["portfolio"]
    
    if risk["daily_pnl"] < 0 and abs(risk["daily_pnl"]) > risk["portfolio_value"] * 0.03:
        print("ALERTA: Pérdida diaria > 3%. Considerar reducir exposición.")
    
    if portfolio["open_positions"] >= 4:
        print("ALERTA: Cerca del límite de posiciones abiertas.")
    
    print(f"Portfolio: ${risk['portfolio_value']:.2f}")
    print(f"PnL diario: ${risk['daily_pnl']:+.2f}")
    print(f"Posiciones abiertas: {portfolio['open_positions']}")
    print(f"Win rate: {portfolio['win_rate']}%")
    
    return status

# Ejecutar
result = asyncio.run(ciclo_trading())
```

---

## 11. NOTAS IMPORTANTES PARA EL AGENTE

1. **SIEMPRE empezar en PAPER_MODE=true** hasta validar que todo funciona correctamente.
2. **Nunca hardcodear API keys** en el código. Siempre usar `.env`.
3. **El bot NO necesita internet** si `TEST_MODE=true` (usa datos sintéticos).
4. **Para trading real**: poner `PAPER_MODE=false`, `TEST_MODE=false`, y configurar las API keys del exchange.
5. **Los logs** van a `logs/trading.log` en formato JSON. Parsear con `json.loads()` por línea.
6. **Confianza mínima**: ninguna señal con `confidence < 0.5` será ejecutada.
7. **El Risk Manager es independiente**: se puede usar sin el engine para evaluar trades de otras fuentes.
8. **El backtesting NO conecta a ningún exchange**: usa datos que le pasás como DataFrame.
