"""Risk Manager - Position sizing and risk controls.

Implements three position sizing methods:
1. Kelly Criterion: Optimal sizing based on win rate and reward/risk ratio
2. Fixed Percentage: Simple fixed % of portfolio per trade
3. ATR-based: Position size inversely proportional to volatility

Also enforces:
- Maximum daily loss limit
- Maximum drawdown limit
- Maximum open positions
- Minimum risk/reward ratio validation

Based on "Trading en la Zona" principles:
- Accept uncertainty in every trade
- Never risk more than you can afford to lose
- Consistency requires discipline
"""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime, timezone
from enum import Enum
from typing import Dict, List, Optional

from app.config import settings
from utils.logging import logger


class SizingMethod(str, Enum):
    KELLY = "kelly"
    FIXED = "fixed"
    ATR = "atr"


@dataclass
class RiskCheck:
    approved: bool
    position_size: float  # Amount in quote currency
    position_size_pct: float  # % of portfolio
    reason: str
    risk_reward_ratio: float = 0.0


@dataclass
class DailyStats:
    date: str
    trades: int = 0
    wins: int = 0
    losses: int = 0
    total_pnl: float = 0.0
    max_drawdown: float = 0.0
    peak_equity: float = 0.0


class RiskManager:
    """Central risk management for all trading operations."""

    def __init__(
        self,
        portfolio_value: float = 10000.0,
        sizing_method: str = "kelly",
        max_position_pct: float = 5.0,
        max_open_positions: int = 5,
        max_daily_loss_pct: float = 5.0,
        max_drawdown_pct: float = 15.0,
        min_risk_reward: float = 1.5,
    ) -> None:
        self.portfolio_value = portfolio_value
        self.initial_portfolio = portfolio_value
        self.sizing_method = SizingMethod(sizing_method)
        self.max_position_pct = max_position_pct
        self.max_open_positions = max_open_positions
        self.max_daily_loss_pct = max_daily_loss_pct
        self.max_drawdown_pct = max_drawdown_pct
        self.min_risk_reward = min_risk_reward

        self.open_positions: int = 0
        self.daily_stats = DailyStats(
            date=datetime.now(timezone.utc).strftime("%Y-%m-%d"),
            peak_equity=portfolio_value,
        )
        self.peak_equity: float = portfolio_value
        self._trade_history: List[Dict] = []

    def check_risk(
        self,
        entry_price: float,
        stop_loss: float,
        take_profit: float,
        confidence: float = 0.5,
        win_rate: float = 0.5,
        atr_value: float = 0.0,
    ) -> RiskCheck:
        """Evaluate a potential trade against risk parameters.

        Returns RiskCheck with approval status and position size.
        """
        # Reset daily stats if new day
        today = datetime.now(timezone.utc).strftime("%Y-%m-%d")
        if self.daily_stats.date != today:
            self.daily_stats = DailyStats(
                date=today, peak_equity=self.portfolio_value
            )

        # --- Check max open positions ---
        if self.open_positions >= self.max_open_positions:
            return RiskCheck(
                approved=False,
                position_size=0,
                position_size_pct=0,
                reason=f"Max open positions reached ({self.max_open_positions})",
            )

        # --- Check daily loss limit ---
        daily_loss_pct = abs(self.daily_stats.total_pnl) / self.portfolio_value * 100
        if self.daily_stats.total_pnl < 0 and daily_loss_pct >= self.max_daily_loss_pct:
            return RiskCheck(
                approved=False,
                position_size=0,
                position_size_pct=0,
                reason=f"Daily loss limit reached ({daily_loss_pct:.1f}% >= {self.max_daily_loss_pct}%)",
            )

        # --- Check max drawdown ---
        current_drawdown = (self.peak_equity - self.portfolio_value) / self.peak_equity * 100
        if current_drawdown >= self.max_drawdown_pct:
            return RiskCheck(
                approved=False,
                position_size=0,
                position_size_pct=0,
                reason=f"Max drawdown reached ({current_drawdown:.1f}% >= {self.max_drawdown_pct}%)",
            )

        # --- Calculate risk/reward ratio ---
        risk = abs(entry_price - stop_loss)
        reward = abs(take_profit - entry_price)

        if risk == 0:
            return RiskCheck(
                approved=False,
                position_size=0,
                position_size_pct=0,
                reason="Invalid stop loss (zero risk)",
            )

        risk_reward = reward / risk

        if risk_reward < self.min_risk_reward:
            return RiskCheck(
                approved=False,
                position_size=0,
                position_size_pct=0,
                reason=f"Risk/reward too low ({risk_reward:.2f} < {self.min_risk_reward})",
                risk_reward_ratio=risk_reward,
            )

        # --- Calculate position size ---
        position_size_pct = self._calculate_position_size(
            win_rate=win_rate,
            risk_reward=risk_reward,
            confidence=confidence,
            risk_per_unit=risk,
            atr_value=atr_value,
        )

        # Cap at max position size
        position_size_pct = min(position_size_pct, self.max_position_pct)

        # Calculate actual position size in quote currency
        position_value = self.portfolio_value * (position_size_pct / 100)
        position_size = position_value / entry_price if entry_price > 0 else 0

        logger.info(
            f"Risk check APPROVED: size={position_size_pct:.1f}%, "
            f"R:R={risk_reward:.2f}, method={self.sizing_method.value}",
            extra={"action": "risk_check"},
        )

        return RiskCheck(
            approved=True,
            position_size=position_size,
            position_size_pct=position_size_pct,
            reason=f"Approved: {self.sizing_method.value} sizing, R:R={risk_reward:.2f}",
            risk_reward_ratio=risk_reward,
        )

    def _calculate_position_size(
        self,
        win_rate: float,
        risk_reward: float,
        confidence: float,
        risk_per_unit: float,
        atr_value: float,
    ) -> float:
        """Calculate position size percentage based on selected method."""

        if self.sizing_method == SizingMethod.KELLY:
            return self._kelly_sizing(win_rate, risk_reward, confidence)
        elif self.sizing_method == SizingMethod.FIXED:
            return self._fixed_sizing()
        elif self.sizing_method == SizingMethod.ATR:
            return self._atr_sizing(atr_value, risk_per_unit)
        else:
            return self._fixed_sizing()

    def _kelly_sizing(
        self, win_rate: float, risk_reward: float, confidence: float
    ) -> float:
        """Kelly Criterion: f* = (bp - q) / b

        Where:
        - b = win/loss ratio (risk_reward)
        - p = probability of winning (win_rate)
        - q = probability of losing (1 - win_rate)

        We use fractional Kelly (25-50%) to be conservative.
        """
        p = max(0.01, min(0.99, win_rate))
        q = 1 - p
        b = max(0.01, risk_reward)

        kelly = (b * p - q) / b

        if kelly <= 0:
            # Kelly says don't bet, use minimum
            return 0.5

        # Fractional Kelly (scale by confidence, max 50% Kelly)
        fraction = 0.25 + (confidence * 0.25)  # 25-50% Kelly
        position_pct = kelly * fraction * 100

        # Clamp to reasonable range
        return max(0.5, min(position_pct, self.max_position_pct))

    def _fixed_sizing(self) -> float:
        """Fixed percentage of portfolio."""
        return min(2.0, self.max_position_pct)

    def _atr_sizing(self, atr_value: float, risk_per_unit: float) -> float:
        """ATR-based sizing: smaller positions in volatile markets.

        Position size = (portfolio * risk_pct) / (ATR * multiplier)
        Normalized to percentage of portfolio.
        """
        if atr_value <= 0 or risk_per_unit <= 0:
            return self._fixed_sizing()

        # Risk 1% of portfolio per ATR unit
        risk_pct = 1.0
        risk_amount = self.portfolio_value * (risk_pct / 100)

        # Position value = risk_amount / (risk_per_unit / entry_price approximation)
        position_value = risk_amount / (risk_per_unit / max(atr_value, 0.01))
        position_pct = (position_value / self.portfolio_value) * 100

        return max(0.5, min(position_pct, self.max_position_pct))

    def on_position_opened(self) -> None:
        """Called when a new position is opened."""
        self.open_positions += 1
        self.daily_stats.trades += 1

    def on_position_closed(self, pnl: float) -> None:
        """Called when a position is closed with its PnL (in quote currency)."""
        self.open_positions = max(0, self.open_positions - 1)
        self.portfolio_value += pnl
        self.daily_stats.total_pnl += pnl

        if pnl > 0:
            self.daily_stats.wins += 1
        else:
            self.daily_stats.losses += 1

        # Update peak equity for drawdown tracking
        if self.portfolio_value > self.peak_equity:
            self.peak_equity = self.portfolio_value
        if self.portfolio_value > self.daily_stats.peak_equity:
            self.daily_stats.peak_equity = self.portfolio_value

        # Track drawdown
        current_dd = (self.peak_equity - self.portfolio_value) / self.peak_equity
        if current_dd > self.daily_stats.max_drawdown:
            self.daily_stats.max_drawdown = current_dd

        self._trade_history.append({
            "timestamp": datetime.now(timezone.utc).isoformat(),
            "pnl": pnl,
            "portfolio_value": self.portfolio_value,
        })

        logger.info(
            f"Position closed: PnL={pnl:+.2f}, Portfolio={self.portfolio_value:.2f}",
            extra={"action": "position_closed"},
        )

    def get_stats(self) -> Dict:
        """Get current risk manager statistics."""
        total_return = (self.portfolio_value - self.initial_portfolio) / self.initial_portfolio
        max_dd = (self.peak_equity - min(
            (t["portfolio_value"] for t in self._trade_history),
            default=self.portfolio_value,
        )) / self.peak_equity if self._trade_history else 0.0

        return {
            "portfolio_value": round(self.portfolio_value, 2),
            "initial_value": self.initial_portfolio,
            "total_return_pct": round(total_return * 100, 2),
            "max_drawdown_pct": round(max_dd * 100, 2),
            "open_positions": self.open_positions,
            "sizing_method": self.sizing_method.value,
            "daily_pnl": round(self.daily_stats.total_pnl, 2),
            "daily_trades": self.daily_stats.trades,
            "daily_win_rate": (
                round(self.daily_stats.wins / max(self.daily_stats.trades, 1) * 100, 1)
            ),
        }
