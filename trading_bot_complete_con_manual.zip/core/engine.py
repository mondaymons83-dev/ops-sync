"""Trading Engine - Main orchestration pipeline.

Signal -> Risk Check -> Order Execution pipeline.

Manages:
- Strategy execution across multiple symbols
- Signal aggregation and filtering
- Risk management integration
- Order submission and monitoring
- Position lifecycle (entry, monitoring, exit)

Runs as an async event loop, processing each strategy on its timeframe.
"""

from __future__ import annotations

import asyncio
from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Any, Dict, List, Optional

import pandas as pd

from app.config import settings
from connectors.base import BaseConnector, OrderType
from core.order_manager import OrderManager
from core.risk_manager import RiskManager
from indicators.technical import atr, candles_to_df
from strategies.base import BaseStrategy, Signal, SignalType, TradingStyle
from utils.logging import logger


@dataclass
class EngineConfig:
    symbols: List[str] = field(default_factory=lambda: ["BTC/USDT"])
    poll_interval_seconds: int = 60
    max_signals_per_cycle: int = 3
    trailing_stop_pct: float = 1.5


class TradingEngine:
    """Main trading engine that orchestrates strategies, risk, and execution."""

    def __init__(
        self,
        connector: BaseConnector,
        strategies: List[BaseStrategy],
        risk_manager: Optional[RiskManager] = None,
        config: Optional[EngineConfig] = None,
    ) -> None:
        self.connector = connector
        self.strategies = strategies
        self.risk_manager = risk_manager or RiskManager(
            portfolio_value=10000.0,
            sizing_method=settings.POSITION_SIZING_METHOD,
            max_position_pct=settings.MAX_POSITION_SIZE_PCT,
            max_open_positions=settings.MAX_OPEN_POSITIONS,
            max_daily_loss_pct=settings.MAX_DAILY_LOSS_PCT,
            max_drawdown_pct=settings.MAX_DRAWDOWN_PCT,
            min_risk_reward=settings.RISK_REWARD_MIN,
        )
        self.order_manager = OrderManager(connector)
        self.config = config or EngineConfig()

        self._running = False
        self._cycle_count = 0

    async def start(self) -> None:
        """Start the trading engine loop."""
        logger.info("Starting Trading Engine...")
        logger.info(f"Strategies: {[s.name for s in self.strategies]}")
        logger.info(f"Symbols: {self.config.symbols}")
        logger.info(f"Paper mode: {settings.PAPER_MODE}")

        await self.connector.connect()
        self._running = True

        try:
            while self._running:
                await self._run_cycle()
                self._cycle_count += 1
                await asyncio.sleep(self.config.poll_interval_seconds)
        except KeyboardInterrupt:
            logger.info("Engine stopped by user")
        except Exception as e:
            logger.error(f"Engine error: {e}", exc_info=True)
        finally:
            await self.stop()

    async def stop(self) -> None:
        """Stop the trading engine."""
        self._running = False
        logger.info("Stopping Trading Engine...")

        # Close all open positions
        for order in self.order_manager.open_orders:
            try:
                await self.order_manager.close_position(
                    order.symbol, reason="engine_shutdown"
                )
            except Exception as e:
                logger.error(f"Error closing {order.symbol}: {e}")

        await self.connector.disconnect()
        logger.info(f"Engine stopped after {self._cycle_count} cycles")
        self._log_final_summary()

    async def _run_cycle(self) -> None:
        """Run one complete trading cycle."""
        logger.info(
            f"=== Cycle {self._cycle_count + 1} ===",
            extra={"action": "cycle_start"},
        )

        for symbol in self.config.symbols:
            try:
                await self._process_symbol(symbol)
            except Exception as e:
                logger.error(f"Error processing {symbol}: {e}")

    async def _process_symbol(self, symbol: str) -> None:
        """Process all strategies for a given symbol."""

        # Check existing positions first
        await self._monitor_positions(symbol)

        # Collect signals from all strategies
        signals: List[Signal] = []

        for strategy in self.strategies:
            try:
                # Fetch candles for the strategy's timeframe
                candles = await self.connector.get_candles(
                    symbol,
                    timeframe=strategy.timeframe,
                    limit=max(strategy.min_candles + 20, 100),
                )

                if len(candles) < strategy.min_candles:
                    continue

                df = candles_to_df(candles)
                signal = strategy.analyze(df, symbol)

                if signal.signal_type != SignalType.HOLD:
                    signals.append(signal)
                    logger.info(
                        f"Signal from {strategy.name}: {signal.signal_type.value} "
                        f"{symbol} (confidence={signal.confidence:.2f})",
                        extra={
                            "action": "signal",
                            "strategy": strategy.name,
                            "symbol": symbol,
                        },
                    )

            except Exception as e:
                logger.error(f"Strategy {strategy.name} error on {symbol}: {e}")

        # Process signals
        if signals:
            await self._process_signals(signals, symbol)

    async def _process_signals(self, signals: List[Signal], symbol: str) -> None:
        """Process collected signals: filter, risk-check, and execute."""

        # Sort by confidence descending
        signals.sort(key=lambda s: s.confidence, reverse=True)

        # Process exit signals first
        exit_signals = [s for s in signals if s.is_exit]
        entry_signals = [s for s in signals if s.is_entry]

        # Handle exits
        for signal in exit_signals:
            position = self.order_manager.get_position(symbol)
            if position:
                # Find the strategy that generated this signal
                for strategy in self.strategies:
                    if strategy.name == signal.strategy_name:
                        if strategy.should_exit(signal, float(position.avg_fill_price)):
                            ticker = await self.connector.get_ticker(symbol)
                            closed = await self.order_manager.close_position(
                                symbol,
                                reason=signal.reason,
                                current_price=ticker.last,
                            )
                            if closed:
                                strategy.update_state_on_exit(ticker.last)
                                self.risk_manager.on_position_closed(closed.pnl)
                            break

        # Handle entries (limit to max per cycle)
        processed = 0
        for signal in entry_signals:
            if processed >= self.config.max_signals_per_cycle:
                break

            # Skip if already in position for this symbol
            if self.order_manager.get_position(symbol):
                continue

            # Find strategy
            strategy = None
            for s in self.strategies:
                if s.name == signal.strategy_name:
                    strategy = s
                    break

            if not strategy or not strategy.should_enter(signal):
                continue

            # Risk check
            if signal.entry_price and signal.stop_loss and signal.take_profit:
                # Get ATR for risk calculation
                candles = await self.connector.get_candles(symbol, strategy.timeframe, 20)
                df = candles_to_df(candles)
                atr_val = float(atr(df, 14).iloc[-1]) if len(df) >= 14 else 0.0

                risk_check = self.risk_manager.check_risk(
                    entry_price=signal.entry_price,
                    stop_loss=signal.stop_loss,
                    take_profit=signal.take_profit,
                    confidence=signal.confidence,
                    win_rate=strategy.win_rate,
                    atr_value=atr_val,
                )

                if not risk_check.approved:
                    logger.info(
                        f"Risk check rejected {signal.strategy_name}: {risk_check.reason}",
                        extra={"action": "risk_rejected", "symbol": symbol},
                    )
                    continue

                # Determine max hold time based on trading style
                max_hold = None
                if strategy.trading_style == TradingStyle.SCALPING:
                    max_hold = settings.SCALP_MAX_HOLD_MINUTES
                elif strategy.trading_style == TradingStyle.INTRADAY:
                    max_hold = settings.INTRADAY_MAX_HOLD_HOURS * 60
                elif strategy.trading_style == TradingStyle.SWING:
                    max_hold = settings.SWING_MAX_HOLD_DAYS * 24 * 60

                # Submit order
                order = await self.order_manager.submit_order(
                    signal=signal,
                    amount=risk_check.position_size,
                    order_type=OrderType.MARKET,
                    trailing_stop_pct=self.config.trailing_stop_pct,
                    max_hold_minutes=max_hold,
                )

                if order.is_open:
                    strategy.update_state_on_entry(signal)
                    self.risk_manager.on_position_opened()
                    processed += 1

                    logger.info(
                        f"Order filled: {signal.strategy_name} {signal.signal_type.value} "
                        f"{risk_check.position_size:.4f} {symbol} @ {signal.entry_price:.2f}",
                        extra={"action": "order_filled", "symbol": symbol},
                    )

    async def _monitor_positions(self, symbol: str) -> None:
        """Monitor existing positions for stop loss, take profit, trailing stop, and max hold."""
        position = self.order_manager.get_position(symbol)
        if not position:
            return

        try:
            ticker = await self.connector.get_ticker(symbol)
            current_price = ticker.last

            close_reason = None

            # Check trailing stop
            if self.order_manager.update_trailing_stop(symbol, current_price):
                close_reason = "trailing_stop"

            # Check fixed stop loss
            elif self.order_manager.check_stop_loss(symbol, current_price):
                close_reason = "stopped"

            # Check take profit
            elif self.order_manager.check_take_profit(symbol, current_price):
                close_reason = "target_hit"

            # Check max hold time
            elif self.order_manager.check_max_hold(symbol):
                close_reason = "expired"

            if close_reason:
                closed = await self.order_manager.close_position(
                    symbol, reason=close_reason, current_price=current_price
                )
                if closed:
                    self.risk_manager.on_position_closed(closed.pnl)

                    # Update strategy state
                    for strategy in self.strategies:
                        if strategy.name == position.strategy_name:
                            strategy.update_state_on_exit(current_price)
                            break

                    logger.info(
                        f"Position auto-closed ({close_reason}): {symbol} PnL={closed.pnl:+.4f}",
                        extra={"action": close_reason, "symbol": symbol},
                    )

        except Exception as e:
            logger.error(f"Position monitor error for {symbol}: {e}")

    async def run_single_cycle(self) -> Dict[str, Any]:
        """Run a single trading cycle (useful for testing)."""
        await self.connector.connect()
        try:
            await self._run_cycle()
        finally:
            pass  # Don't disconnect for single cycle

        return {
            "cycle": self._cycle_count,
            "risk_stats": self.risk_manager.get_stats(),
            "portfolio": self.order_manager.get_portfolio_summary(),
            "strategies": [s.get_info() for s in self.strategies],
        }

    def _log_final_summary(self) -> None:
        """Log final trading session summary."""
        risk_stats = self.risk_manager.get_stats()
        portfolio = self.order_manager.get_portfolio_summary()

        logger.info("=" * 60)
        logger.info("TRADING SESSION SUMMARY")
        logger.info("=" * 60)
        logger.info(f"Total cycles: {self._cycle_count}")
        logger.info(f"Portfolio: {risk_stats['portfolio_value']:.2f} "
                     f"(return: {risk_stats['total_return_pct']:+.2f}%)")
        logger.info(f"Total trades: {portfolio['total_trades']}")
        logger.info(f"Win rate: {portfolio['win_rate']}%")
        logger.info(f"Net PnL: {portfolio['net_pnl']:.4f}")
        logger.info(f"Max drawdown: {risk_stats['max_drawdown_pct']:.2f}%")

        for strategy in self.strategies:
            info = strategy.get_info()
            logger.info(
                f"  {info['name']}: {info['trades']} trades, "
                f"WR={info['win_rate']}, PnL={info['pnl']}"
            )

    def get_status(self) -> Dict[str, Any]:
        """Get current engine status."""
        return {
            "running": self._running,
            "cycle_count": self._cycle_count,
            "paper_mode": settings.PAPER_MODE,
            "symbols": self.config.symbols,
            "strategies": [s.get_info() for s in self.strategies],
            "risk": self.risk_manager.get_stats(),
            "portfolio": self.order_manager.get_portfolio_summary(),
        }
