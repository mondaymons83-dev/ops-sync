"""Order Manager - Order tracking, trailing stops, and lifecycle management.

Handles:
- Order creation and tracking
- Trailing stop updates
- Order status monitoring
- Partial fills
- Order lifecycle events (created, filled, cancelled, expired)
"""

from __future__ import annotations

import asyncio
from dataclasses import dataclass, field
from datetime import datetime, timedelta, timezone
from enum import Enum
from typing import Any, Dict, List, Optional

from connectors.base import BaseConnector, OrderResult, OrderSide, OrderStatus, OrderType
from strategies.base import Signal, SignalType
from utils.logging import logger


class ManagedOrderStatus(str, Enum):
    PENDING = "pending"
    ACTIVE = "active"
    FILLED = "filled"
    PARTIALLY_FILLED = "partially_filled"
    CANCELLED = "cancelled"
    EXPIRED = "expired"
    STOPPED = "stopped"  # Hit stop loss
    TARGET_HIT = "target_hit"  # Hit take profit


@dataclass
class ManagedOrder:
    """An order tracked by the order manager with additional metadata."""
    order_id: str
    symbol: str
    side: OrderSide
    order_type: OrderType
    amount: float
    price: float
    status: ManagedOrderStatus = ManagedOrderStatus.PENDING

    # Risk levels
    stop_loss: Optional[float] = None
    take_profit: Optional[float] = None
    trailing_stop_pct: Optional[float] = None
    trailing_stop_price: Optional[float] = None

    # Tracking
    filled_amount: float = 0.0
    avg_fill_price: float = 0.0
    fees: float = 0.0
    pnl: float = 0.0

    # Strategy info
    strategy_name: str = ""
    signal_confidence: float = 0.0
    reason: str = ""

    # Timestamps
    created_at: datetime = field(default_factory=lambda: datetime.now(timezone.utc))
    filled_at: Optional[datetime] = None
    closed_at: Optional[datetime] = None
    max_hold_until: Optional[datetime] = None

    # Exchange order result
    exchange_order: Optional[OrderResult] = None

    @property
    def is_open(self) -> bool:
        return self.status in (
            ManagedOrderStatus.ACTIVE,
            ManagedOrderStatus.PARTIALLY_FILLED,
        )

    @property
    def is_closed(self) -> bool:
        return self.status in (
            ManagedOrderStatus.FILLED,
            ManagedOrderStatus.CANCELLED,
            ManagedOrderStatus.EXPIRED,
            ManagedOrderStatus.STOPPED,
            ManagedOrderStatus.TARGET_HIT,
        )

    @property
    def hold_duration(self) -> Optional[timedelta]:
        if self.filled_at:
            end = self.closed_at or datetime.now(timezone.utc)
            return end - self.filled_at
        return None


class OrderManager:
    """Manages order lifecycle, trailing stops, and position tracking."""

    def __init__(self, connector: BaseConnector) -> None:
        self.connector = connector
        self._orders: Dict[str, ManagedOrder] = {}
        self._position_orders: Dict[str, str] = {}  # symbol -> order_id for active positions

    @property
    def open_orders(self) -> List[ManagedOrder]:
        return [o for o in self._orders.values() if o.is_open]

    @property
    def all_orders(self) -> List[ManagedOrder]:
        return list(self._orders.values())

    @property
    def closed_orders(self) -> List[ManagedOrder]:
        return [o for o in self._orders.values() if o.is_closed]

    def get_position(self, symbol: str) -> Optional[ManagedOrder]:
        """Get the active position for a symbol."""
        order_id = self._position_orders.get(symbol)
        if order_id and order_id in self._orders:
            order = self._orders[order_id]
            if order.is_open:
                return order
        return None

    async def submit_order(
        self,
        signal: Signal,
        amount: float,
        order_type: OrderType = OrderType.MARKET,
        trailing_stop_pct: Optional[float] = None,
        max_hold_minutes: Optional[int] = None,
    ) -> ManagedOrder:
        """Submit an order based on a trading signal."""

        side = signal.side
        price = signal.entry_price or 0.0

        logger.info(
            f"Submitting {side.value} {order_type.value} order: "
            f"{amount} {signal.symbol} @ {price}",
            extra={"action": "submit_order", "symbol": signal.symbol},
        )

        # Place order on exchange
        exchange_result = await self.connector.place_order(
            symbol=signal.symbol,
            side=side,
            order_type=order_type,
            amount=amount,
            price=price if order_type == OrderType.LIMIT else None,
        )

        # Create managed order
        max_hold = None
        if max_hold_minutes:
            max_hold = datetime.now(timezone.utc) + timedelta(minutes=max_hold_minutes)

        managed = ManagedOrder(
            order_id=exchange_result.order_id,
            symbol=signal.symbol,
            side=side,
            order_type=order_type,
            amount=amount,
            price=price,
            stop_loss=signal.stop_loss,
            take_profit=signal.take_profit,
            trailing_stop_pct=trailing_stop_pct,
            strategy_name=signal.strategy_name,
            signal_confidence=signal.confidence,
            reason=signal.reason,
            exchange_order=exchange_result,
            max_hold_until=max_hold,
        )

        # Update status based on exchange response
        if exchange_result.status == OrderStatus.FILLED:
            managed.status = ManagedOrderStatus.ACTIVE
            managed.filled_amount = exchange_result.filled
            managed.avg_fill_price = exchange_result.price or price
            managed.filled_at = datetime.now(timezone.utc)
            managed.fees = exchange_result.fee

            # Initialize trailing stop
            if trailing_stop_pct and managed.avg_fill_price > 0:
                if side == OrderSide.BUY:
                    managed.trailing_stop_price = managed.avg_fill_price * (1 - trailing_stop_pct / 100)
                else:
                    managed.trailing_stop_price = managed.avg_fill_price * (1 + trailing_stop_pct / 100)

            self._position_orders[signal.symbol] = managed.order_id
        elif exchange_result.status == OrderStatus.OPEN:
            managed.status = ManagedOrderStatus.PENDING
        else:
            managed.status = ManagedOrderStatus.CANCELLED

        self._orders[managed.order_id] = managed

        logger.info(
            f"Order {managed.order_id}: {managed.status.value}, "
            f"filled={managed.filled_amount}/{amount}",
            extra={"action": "order_created", "symbol": signal.symbol},
        )

        return managed

    async def close_position(
        self,
        symbol: str,
        reason: str = "manual_close",
        current_price: Optional[float] = None,
    ) -> Optional[ManagedOrder]:
        """Close an active position."""
        position = self.get_position(symbol)
        if not position:
            logger.warning(f"No open position for {symbol}")
            return None

        # Determine close side (opposite of entry)
        close_side = OrderSide.SELL if position.side == OrderSide.BUY else OrderSide.BUY

        exchange_result = await self.connector.place_order(
            symbol=symbol,
            side=close_side,
            order_type=OrderType.MARKET,
            amount=position.filled_amount,
        )

        close_price = current_price or exchange_result.price or position.avg_fill_price

        # Calculate PnL
        if position.side == OrderSide.BUY:
            position.pnl = (close_price - position.avg_fill_price) * position.filled_amount
        else:
            position.pnl = (position.avg_fill_price - close_price) * position.filled_amount

        position.pnl -= position.fees  # Subtract fees

        position.closed_at = datetime.now(timezone.utc)
        position.status = ManagedOrderStatus(reason) if reason in [e.value for e in ManagedOrderStatus] else ManagedOrderStatus.FILLED

        # Remove from active positions
        if symbol in self._position_orders:
            del self._position_orders[symbol]

        logger.info(
            f"Position closed: {symbol} PnL={position.pnl:+.4f} ({reason})",
            extra={"action": "position_closed", "symbol": symbol},
        )

        return position

    def update_trailing_stop(self, symbol: str, current_price: float) -> bool:
        """Update trailing stop for an active position.

        Returns True if the trailing stop was hit.
        """
        position = self.get_position(symbol)
        if not position or not position.trailing_stop_pct:
            return False

        if position.side == OrderSide.BUY:
            # Long position: trail stop upward
            new_stop = current_price * (1 - position.trailing_stop_pct / 100)
            if position.trailing_stop_price is None or new_stop > position.trailing_stop_price:
                position.trailing_stop_price = new_stop
                logger.info(
                    f"Trailing stop updated: {symbol} -> {new_stop:.4f}",
                    extra={"action": "trailing_stop_update", "symbol": symbol},
                )

            # Check if stop hit
            if current_price <= position.trailing_stop_price:
                return True

        else:
            # Short position: trail stop downward
            new_stop = current_price * (1 + position.trailing_stop_pct / 100)
            if position.trailing_stop_price is None or new_stop < position.trailing_stop_price:
                position.trailing_stop_price = new_stop

            if current_price >= position.trailing_stop_price:
                return True

        return False

    def check_stop_loss(self, symbol: str, current_price: float) -> bool:
        """Check if the fixed stop loss has been hit."""
        position = self.get_position(symbol)
        if not position or not position.stop_loss:
            return False

        if position.side == OrderSide.BUY:
            return current_price <= position.stop_loss
        else:
            return current_price >= position.stop_loss

    def check_take_profit(self, symbol: str, current_price: float) -> bool:
        """Check if the take profit has been hit."""
        position = self.get_position(symbol)
        if not position or not position.take_profit:
            return False

        if position.side == OrderSide.BUY:
            return current_price >= position.take_profit
        else:
            return current_price <= position.take_profit

    def check_max_hold(self, symbol: str) -> bool:
        """Check if the maximum hold time has been exceeded."""
        position = self.get_position(symbol)
        if not position or not position.max_hold_until:
            return False
        return datetime.now(timezone.utc) >= position.max_hold_until

    def get_portfolio_summary(self) -> Dict[str, Any]:
        """Get summary of all positions and orders."""
        total_pnl = sum(o.pnl for o in self.closed_orders)
        total_fees = sum(o.fees for o in self._orders.values())
        wins = sum(1 for o in self.closed_orders if o.pnl > 0)
        losses = sum(1 for o in self.closed_orders if o.pnl <= 0)

        return {
            "open_positions": len(self.open_orders),
            "total_trades": len(self.closed_orders),
            "wins": wins,
            "losses": losses,
            "win_rate": round(wins / max(wins + losses, 1) * 100, 1),
            "total_pnl": round(total_pnl, 4),
            "total_fees": round(total_fees, 4),
            "net_pnl": round(total_pnl - total_fees, 4),
            "active_symbols": list(self._position_orders.keys()),
        }
