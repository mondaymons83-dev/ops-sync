"""Elliott Wave detection engine.

Based on "Five Waves to Financial Freedom" by Ramki:

Core rules:
1. Wave 2 never retraces beyond the start of Wave 1
2. Wave 3 is never the shortest impulse wave
3. Wave 4 never overlaps Wave 1 (except in diagonal triangles)

Key Fibonacci relationships:
- Wave 2: typically retraces 50-61.8% of Wave 1 (max 100%)
- Wave 3: typically 100-161.8% of Wave 1 (extended: 200-461.8%)
- Wave 4: typically retraces 23.6-38.2% of Wave 3
- Wave 5: 38.2-61.8% of distance from start of Wave 1 to end of Wave 3

After 5 waves complete, expect a correction (ABC) LARGER than Wave 2 or Wave 4.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum
from typing import Dict, List, Optional, Tuple

import numpy as np
import pandas as pd

from indicators.fibonacci import find_swing_points


class WaveType(str, Enum):
    IMPULSE = "impulse"
    CORRECTIVE = "corrective"
    UNKNOWN = "unknown"


class WavePosition(str, Enum):
    WAVE_1 = "wave_1"
    WAVE_2 = "wave_2"
    WAVE_3 = "wave_3"
    WAVE_4 = "wave_4"
    WAVE_5 = "wave_5"
    WAVE_A = "wave_a"
    WAVE_B = "wave_b"
    WAVE_C = "wave_c"
    UNKNOWN = "unknown"


@dataclass
class WavePoint:
    index: int
    price: float
    label: str


@dataclass
class ElliottWaveResult:
    wave_type: WaveType
    current_position: WavePosition
    direction: str  # "bullish" or "bearish"
    waves: List[WavePoint]
    confidence: float  # 0-1
    next_target: Optional[float] = None
    stop_loss: Optional[float] = None
    notes: List[str] = field(default_factory=list)


def _validate_impulse_rules(
    points: List[Tuple[int, float]], direction: str
) -> Tuple[bool, List[str]]:
    """Validate Elliott Wave impulse rules.

    Points should be [wave_0, wave_1, wave_2, wave_3, wave_4, wave_5].
    For bullish: wave_0 < wave_1 > wave_2 < wave_3 > wave_4 < wave_5
    """
    notes: List[str] = []
    if len(points) < 4:
        return False, ["Insufficient points for wave validation"]

    if direction == "bullish":
        # Rule 1: Wave 2 never goes below Wave 0 (start of Wave 1)
        if len(points) >= 3 and points[2][1] <= points[0][1]:
            notes.append("VIOLATION: Wave 2 below start of Wave 1")
            return False, notes

        # Rule 3: Wave 4 cannot overlap Wave 1
        if len(points) >= 5 and points[4][1] <= points[1][1]:
            notes.append("VIOLATION: Wave 4 overlaps Wave 1")
            return False, notes

        if len(points) >= 6:
            # Rule 2: Wave 3 cannot be the shortest
            w1_len = points[1][1] - points[0][1]
            w3_len = points[3][1] - points[2][1]
            w5_len = points[5][1] - points[4][1]
            if w3_len < w1_len and w3_len < w5_len:
                notes.append("VIOLATION: Wave 3 is shortest impulse")
                return False, notes

            if w3_len >= w1_len * 1.618:
                notes.append("Wave 3 extended (>161.8% of Wave 1)")

    else:  # bearish
        if len(points) >= 3 and points[2][1] >= points[0][1]:
            notes.append("VIOLATION: Wave 2 above start of Wave 1")
            return False, notes

        if len(points) >= 5 and points[4][1] >= points[1][1]:
            notes.append("VIOLATION: Wave 4 overlaps Wave 1")
            return False, notes

        if len(points) >= 6:
            w1_len = points[0][1] - points[1][1]
            w3_len = points[2][1] - points[3][1]
            w5_len = points[4][1] - points[5][1]
            if w3_len < w1_len and w3_len < w5_len:
                notes.append("VIOLATION: Wave 3 is shortest impulse")
                return False, notes

    notes.append("All impulse rules validated")
    return True, notes


def detect_waves(
    df: pd.DataFrame,
    lookback: int = 5,
    min_wave_pct: float = 1.0,
) -> ElliottWaveResult:
    """Detect Elliott Wave patterns in price data.

    Algorithm:
    1. Find significant swing highs and lows
    2. Attempt to fit 5-wave impulse pattern
    3. Validate against Elliott Wave rules
    4. Calculate targets and confidence
    """
    highs, lows = find_swing_points(df, lookback)

    if len(highs) < 2 or len(lows) < 2:
        return ElliottWaveResult(
            wave_type=WaveType.UNKNOWN,
            current_position=WavePosition.UNKNOWN,
            direction="unknown",
            waves=[],
            confidence=0.0,
            notes=["Insufficient swing points detected"],
        )

    # Merge and sort all swing points
    all_points: List[Tuple[int, float, str]] = []
    for idx, price in highs:
        all_points.append((idx, price, "high"))
    for idx, price in lows:
        all_points.append((idx, price, "low"))
    all_points.sort(key=lambda x: x[0])

    # Filter alternating highs and lows
    alternating: List[Tuple[int, float, str]] = [all_points[0]]
    for pt in all_points[1:]:
        if pt[2] != alternating[-1][2]:
            alternating.append(pt)
        else:
            # Keep the more extreme point
            if pt[2] == "high" and pt[1] > alternating[-1][1]:
                alternating[-1] = pt
            elif pt[2] == "low" and pt[1] < alternating[-1][1]:
                alternating[-1] = pt

    # Need at least 6 points for a 5-wave pattern
    if len(alternating) < 6:
        # Try to identify partial waves
        return _identify_partial_pattern(alternating, df)

    # Try to fit bullish 5-wave pattern from end
    result = _try_fit_impulse(alternating, "bullish", df)
    if result.confidence > 0.3:
        return result

    # Try bearish
    result = _try_fit_impulse(alternating, "bearish", df)
    if result.confidence > 0.3:
        return result

    return _identify_partial_pattern(alternating, df)


def _try_fit_impulse(
    alternating: List[Tuple[int, float, str]],
    direction: str,
    df: pd.DataFrame,
) -> ElliottWaveResult:
    """Try to fit a 5-wave impulse pattern."""
    best_result = ElliottWaveResult(
        wave_type=WaveType.UNKNOWN,
        current_position=WavePosition.UNKNOWN,
        direction=direction,
        waves=[],
        confidence=0.0,
    )

    # Search backwards through alternating points for the best 5-wave fit
    for start in range(max(0, len(alternating) - 12), len(alternating) - 5):
        candidate = alternating[start : start + 6]

        if direction == "bullish":
            # Expect: low, high, low, high, low, high (0,1,2,3,4,5)
            if candidate[0][2] != "low":
                continue
            points = [(c[0], c[1]) for c in candidate]
        else:
            # Expect: high, low, high, low, high, low
            if candidate[0][2] != "high":
                continue
            points = [(c[0], c[1]) for c in candidate]

        valid, notes = _validate_impulse_rules(points, direction)
        if not valid:
            continue

        # Calculate confidence based on Fibonacci ratios
        confidence = _calculate_confidence(points, direction)

        if confidence > best_result.confidence:
            wave_labels = ["0", "1", "2", "3", "4", "5"]
            waves = [
                WavePoint(index=p[0], price=p[1], label=f"Wave {wave_labels[i]}")
                for i, p in enumerate(points)
            ]

            # Determine current position
            last_idx = df.index[-1] if not df.empty else points[-1][0]
            current_pos = _determine_position(points, direction, df)

            # Calculate next target
            target = _calculate_target(points, direction, current_pos)
            stop = _calculate_stop(points, direction, current_pos)

            best_result = ElliottWaveResult(
                wave_type=WaveType.IMPULSE,
                current_position=current_pos,
                direction=direction,
                waves=waves,
                confidence=confidence,
                next_target=target,
                stop_loss=stop,
                notes=notes,
            )

    return best_result


def _calculate_confidence(
    points: List[Tuple[int, float]], direction: str
) -> float:
    """Calculate confidence score based on Fibonacci relationships."""
    if len(points) < 4:
        return 0.1

    score = 0.0
    max_score = 0.0

    if direction == "bullish":
        w1 = points[1][1] - points[0][1]
        w2_retrace = (points[1][1] - points[2][1]) / w1 if w1 != 0 else 0

        # Wave 2 retrace between 38.2% and 78.6% is ideal
        max_score += 1
        if 0.382 <= w2_retrace <= 0.786:
            score += 1
        elif 0.236 <= w2_retrace <= 1.0:
            score += 0.5

        if len(points) >= 4:
            w3 = points[3][1] - points[2][1]
            w3_ratio = w3 / w1 if w1 != 0 else 0

            # Wave 3 should be at least 100% of Wave 1
            max_score += 1
            if w3_ratio >= 1.618:
                score += 1  # Extended - very common
            elif w3_ratio >= 1.0:
                score += 0.8

        if len(points) >= 5:
            w3 = points[3][1] - points[2][1]
            w4_retrace = (points[3][1] - points[4][1]) / w3 if w3 != 0 else 0

            # Wave 4 should retrace 23.6-50% of Wave 3
            max_score += 1
            if 0.236 <= w4_retrace <= 0.5:
                score += 1
            elif 0.1 <= w4_retrace <= 0.618:
                score += 0.5

    else:  # bearish - mirror logic
        w1 = points[0][1] - points[1][1]
        w2_retrace = (points[2][1] - points[1][1]) / w1 if w1 != 0 else 0
        max_score += 1
        if 0.382 <= w2_retrace <= 0.786:
            score += 1
        elif 0.236 <= w2_retrace <= 1.0:
            score += 0.5

        if len(points) >= 4:
            w3 = points[2][1] - points[3][1]
            w3_ratio = w3 / w1 if w1 != 0 else 0
            max_score += 1
            if w3_ratio >= 1.618:
                score += 1
            elif w3_ratio >= 1.0:
                score += 0.8

    return score / max_score if max_score > 0 else 0.0


def _determine_position(
    points: List[Tuple[int, float]],
    direction: str,
    df: pd.DataFrame,
) -> WavePosition:
    """Determine where we currently are in the wave count."""
    if len(points) < 6:
        return WavePosition.UNKNOWN

    last_price = float(df["close"].iloc[-1])
    last_wave_end = points[-1]

    # Check if we're past the 5th wave - possibly in correction
    if direction == "bullish":
        if last_price < points[-1][1]:
            # Price declining after Wave 5 top
            retrace = (points[-1][1] - last_price) / (points[-1][1] - points[-2][1])
            if retrace > 0.5:
                return WavePosition.WAVE_C
            elif retrace > 0.2:
                return WavePosition.WAVE_B
            else:
                return WavePosition.WAVE_A
        else:
            return WavePosition.WAVE_5
    else:
        if last_price > points[-1][1]:
            retrace = (last_price - points[-1][1]) / (points[-2][1] - points[-1][1])
            if retrace > 0.5:
                return WavePosition.WAVE_C
            elif retrace > 0.2:
                return WavePosition.WAVE_B
            else:
                return WavePosition.WAVE_A
        else:
            return WavePosition.WAVE_5

    return WavePosition.UNKNOWN


def _calculate_target(
    points: List[Tuple[int, float]],
    direction: str,
    position: WavePosition,
) -> Optional[float]:
    """Calculate next price target based on wave position."""
    if len(points) < 4:
        return None

    if direction == "bullish":
        w1 = points[1][1] - points[0][1]

        if position in (WavePosition.WAVE_2, WavePosition.WAVE_3):
            # Target for Wave 3: 161.8% of Wave 1 from Wave 2 end
            return points[2][1] + w1 * 1.618

        if position == WavePosition.WAVE_4:
            # Target for Wave 5
            w0_to_w3 = points[3][1] - points[0][1]
            return points[4][1] + w0_to_w3 * 0.618

        if position in (WavePosition.WAVE_5, WavePosition.WAVE_A):
            # Expect correction, target Wave A low
            w5 = points[5][1] - points[4][1] if len(points) >= 6 else w1
            return points[5][1] - w5 * 0.618 if len(points) >= 6 else None

    else:  # bearish
        w1 = points[0][1] - points[1][1]

        if position in (WavePosition.WAVE_2, WavePosition.WAVE_3):
            return points[2][1] - w1 * 1.618

        if position == WavePosition.WAVE_4:
            w0_to_w3 = points[0][1] - points[3][1]
            return points[4][1] - w0_to_w3 * 0.618

    return None


def _calculate_stop(
    points: List[Tuple[int, float]],
    direction: str,
    position: WavePosition,
) -> Optional[float]:
    """Calculate stop loss based on wave position and Elliott rules."""
    if len(points) < 3:
        return None

    if direction == "bullish":
        if position in (WavePosition.WAVE_2, WavePosition.WAVE_3):
            # Stop below Wave 1 start (Wave 2 cannot go below)
            return points[0][1] * 0.99

        if position == WavePosition.WAVE_4:
            # Stop below Wave 1 top (Wave 4 cannot overlap Wave 1)
            return points[1][1] * 0.99

        if position == WavePosition.WAVE_5:
            # Stop below Wave 4 low
            return points[4][1] * 0.99 if len(points) >= 5 else None

    else:
        if position in (WavePosition.WAVE_2, WavePosition.WAVE_3):
            return points[0][1] * 1.01

        if position == WavePosition.WAVE_4:
            return points[1][1] * 1.01

    return None


def _identify_partial_pattern(
    alternating: List[Tuple[int, float, str]],
    df: pd.DataFrame,
) -> ElliottWaveResult:
    """Identify partial wave patterns when we can't find a complete 5-wave."""
    if len(alternating) < 3:
        return ElliottWaveResult(
            wave_type=WaveType.UNKNOWN,
            current_position=WavePosition.UNKNOWN,
            direction="unknown",
            waves=[],
            confidence=0.0,
            notes=["Too few swing points for pattern detection"],
        )

    # Check recent trend direction
    last_close = float(df["close"].iloc[-1])
    recent_high = max(p[1] for p in alternating[-4:])
    recent_low = min(p[1] for p in alternating[-4:])

    if last_close > (recent_high + recent_low) / 2:
        direction = "bullish"
    else:
        direction = "bearish"

    # Try to identify the most recent wave segment
    last_3 = alternating[-3:]
    waves = [
        WavePoint(index=p[0], price=p[1], label=f"Point {i}")
        for i, p in enumerate(last_3)
    ]

    return ElliottWaveResult(
        wave_type=WaveType.CORRECTIVE if len(alternating) <= 4 else WaveType.IMPULSE,
        current_position=WavePosition.WAVE_1 if direction == "bullish" else WavePosition.WAVE_A,
        direction=direction,
        waves=waves,
        confidence=0.2,
        notes=[f"Partial pattern: {len(alternating)} swing points detected"],
    )
