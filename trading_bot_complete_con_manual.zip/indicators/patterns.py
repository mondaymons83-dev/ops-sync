"""Chart pattern recognition: Head & Shoulders, Double Top/Bottom, Triangles, Flags, Wedges.

Based on the Technical Analysis Guide by CryptoKane & SatoshiGainz.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum
from typing import List, Optional, Tuple

import numpy as np
import pandas as pd

from indicators.fibonacci import find_swing_points


class PatternType(str, Enum):
    HEAD_AND_SHOULDERS = "head_and_shoulders"
    INVERSE_HEAD_AND_SHOULDERS = "inverse_head_and_shoulders"
    DOUBLE_TOP = "double_top"
    DOUBLE_BOTTOM = "double_bottom"
    TRIPLE_TOP = "triple_top"
    TRIPLE_BOTTOM = "triple_bottom"
    ASCENDING_TRIANGLE = "ascending_triangle"
    DESCENDING_TRIANGLE = "descending_triangle"
    SYMMETRICAL_TRIANGLE = "symmetrical_triangle"
    BULL_FLAG = "bull_flag"
    BEAR_FLAG = "bear_flag"
    BULL_PENNANT = "bull_pennant"
    BEAR_PENNANT = "bear_pennant"
    RISING_WEDGE = "rising_wedge"
    FALLING_WEDGE = "falling_wedge"
    CUP_AND_HANDLE = "cup_and_handle"
    ROUNDING_BOTTOM = "rounding_bottom"


class PatternSignal(str, Enum):
    BULLISH = "bullish"
    BEARISH = "bearish"
    NEUTRAL = "neutral"


@dataclass
class PatternResult:
    pattern_type: PatternType
    signal: PatternSignal
    confidence: float  # 0-1
    entry_price: Optional[float] = None
    stop_loss: Optional[float] = None
    take_profit: Optional[float] = None
    start_index: int = 0
    end_index: int = 0
    notes: str = ""


def detect_all_patterns(
    df: pd.DataFrame, lookback: int = 5
) -> List[PatternResult]:
    """Run all pattern detectors and return found patterns."""
    patterns: List[PatternResult] = []

    detectors = [
        _detect_head_and_shoulders,
        _detect_double_top_bottom,
        _detect_triangles,
        _detect_flags,
        _detect_wedges,
    ]

    for detector in detectors:
        try:
            found = detector(df, lookback)
            patterns.extend(found)
        except Exception:
            continue

    # Sort by confidence descending
    patterns.sort(key=lambda p: p.confidence, reverse=True)
    return patterns


def _detect_head_and_shoulders(
    df: pd.DataFrame, lookback: int = 5
) -> List[PatternResult]:
    """Detect Head & Shoulders and Inverse H&S patterns."""
    results: List[PatternResult] = []
    highs, lows = find_swing_points(df, lookback)

    if len(highs) < 3:
        return results

    # Check last 3 swing highs for H&S
    for i in range(len(highs) - 2):
        h1_idx, h1_price = highs[i]
        h2_idx, h2_price = highs[i + 1]
        h3_idx, h3_price = highs[i + 2]

        # Head should be highest
        if h2_price > h1_price and h2_price > h3_price:
            # Shoulders should be roughly equal (within 3%)
            shoulder_diff = abs(h1_price - h3_price) / max(h1_price, h3_price)
            if shoulder_diff < 0.03:
                # Find neckline from lows between shoulders
                neckline_lows = [
                    l for l in lows if h1_idx < l[0] < h3_idx
                ]
                if len(neckline_lows) >= 1:
                    neckline = min(l[1] for l in neckline_lows)
                    height = h2_price - neckline
                    last_close = float(df["close"].iloc[-1])

                    confidence = 0.6
                    if shoulder_diff < 0.015:
                        confidence += 0.1
                    if last_close < neckline:
                        confidence += 0.2  # Already broken neckline

                    results.append(PatternResult(
                        pattern_type=PatternType.HEAD_AND_SHOULDERS,
                        signal=PatternSignal.BEARISH,
                        confidence=min(confidence, 0.95),
                        entry_price=neckline,
                        stop_loss=h3_price * 1.01,
                        take_profit=neckline - height,
                        start_index=h1_idx,
                        end_index=h3_idx,
                        notes=f"Head: {h2_price:.2f}, Neckline: {neckline:.2f}",
                    ))

    # Inverse H&S (bullish)
    if len(lows) >= 3:
        for i in range(len(lows) - 2):
            l1_idx, l1_price = lows[i]
            l2_idx, l2_price = lows[i + 1]
            l3_idx, l3_price = lows[i + 2]

            if l2_price < l1_price and l2_price < l3_price:
                shoulder_diff = abs(l1_price - l3_price) / max(l1_price, l3_price)
                if shoulder_diff < 0.03:
                    neckline_highs = [
                        h for h in highs if l1_idx < h[0] < l3_idx
                    ]
                    if len(neckline_highs) >= 1:
                        neckline = max(h[1] for h in neckline_highs)
                        height = neckline - l2_price

                        results.append(PatternResult(
                            pattern_type=PatternType.INVERSE_HEAD_AND_SHOULDERS,
                            signal=PatternSignal.BULLISH,
                            confidence=0.65,
                            entry_price=neckline,
                            stop_loss=l3_price * 0.99,
                            take_profit=neckline + height,
                            start_index=l1_idx,
                            end_index=l3_idx,
                            notes=f"Head: {l2_price:.2f}, Neckline: {neckline:.2f}",
                        ))

    return results


def _detect_double_top_bottom(
    df: pd.DataFrame, lookback: int = 5
) -> List[PatternResult]:
    """Detect Double Top and Double Bottom patterns."""
    results: List[PatternResult] = []
    highs, lows = find_swing_points(df, lookback)

    # Double Top
    if len(highs) >= 2:
        h1_idx, h1_price = highs[-2]
        h2_idx, h2_price = highs[-1]
        price_diff = abs(h1_price - h2_price) / max(h1_price, h2_price)

        if price_diff < 0.02:  # Tops within 2%
            # Find valley between tops
            valley_lows = [l for l in lows if h1_idx < l[0] < h2_idx]
            if valley_lows:
                valley = min(l[1] for l in valley_lows)
                height = max(h1_price, h2_price) - valley

                results.append(PatternResult(
                    pattern_type=PatternType.DOUBLE_TOP,
                    signal=PatternSignal.BEARISH,
                    confidence=0.65,
                    entry_price=valley,
                    stop_loss=max(h1_price, h2_price) * 1.01,
                    take_profit=valley - height,
                    start_index=h1_idx,
                    end_index=h2_idx,
                    notes=f"Tops at {h1_price:.2f} and {h2_price:.2f}",
                ))

    # Double Bottom
    if len(lows) >= 2:
        l1_idx, l1_price = lows[-2]
        l2_idx, l2_price = lows[-1]
        price_diff = abs(l1_price - l2_price) / max(l1_price, l2_price)

        if price_diff < 0.02:
            peak_highs = [h for h in highs if l1_idx < h[0] < l2_idx]
            if peak_highs:
                peak = max(h[1] for h in peak_highs)
                height = peak - min(l1_price, l2_price)

                results.append(PatternResult(
                    pattern_type=PatternType.DOUBLE_BOTTOM,
                    signal=PatternSignal.BULLISH,
                    confidence=0.65,
                    entry_price=peak,
                    stop_loss=min(l1_price, l2_price) * 0.99,
                    take_profit=peak + height,
                    start_index=l1_idx,
                    end_index=l2_idx,
                    notes=f"Bottoms at {l1_price:.2f} and {l2_price:.2f}",
                ))

    return results


def _detect_triangles(
    df: pd.DataFrame, lookback: int = 5
) -> List[PatternResult]:
    """Detect Ascending, Descending, and Symmetrical triangles."""
    results: List[PatternResult] = []
    highs, lows = find_swing_points(df, lookback)

    if len(highs) < 3 or len(lows) < 3:
        return results

    # Use last N swing points
    recent_highs = highs[-4:]
    recent_lows = lows[-4:]

    # Check if highs are flat and lows are rising (Ascending Triangle)
    high_prices = [h[1] for h in recent_highs]
    low_prices = [l[1] for l in recent_lows]

    high_range = (max(high_prices) - min(high_prices)) / max(high_prices)
    low_slope = (low_prices[-1] - low_prices[0]) / max(low_prices[0], 1)

    if high_range < 0.02 and low_slope > 0.01:
        resistance = max(high_prices)
        last_close = float(df["close"].iloc[-1])
        height = resistance - min(low_prices)

        results.append(PatternResult(
            pattern_type=PatternType.ASCENDING_TRIANGLE,
            signal=PatternSignal.BULLISH,
            confidence=0.6,
            entry_price=resistance * 1.005,  # Buy on breakout
            stop_loss=low_prices[-1] * 0.99,
            take_profit=resistance + height,
            start_index=min(recent_lows[0][0], recent_highs[0][0]),
            end_index=max(recent_lows[-1][0], recent_highs[-1][0]),
            notes=f"Resistance at {resistance:.2f}, rising lows",
        ))

    # Descending Triangle: flat lows, declining highs
    low_range = (max(low_prices) - min(low_prices)) / max(min(low_prices), 1)
    high_slope = (high_prices[-1] - high_prices[0]) / max(high_prices[0], 1)

    if low_range < 0.02 and high_slope < -0.01:
        support = min(low_prices)
        height = max(high_prices) - support

        results.append(PatternResult(
            pattern_type=PatternType.DESCENDING_TRIANGLE,
            signal=PatternSignal.BEARISH,
            confidence=0.6,
            entry_price=support * 0.995,
            stop_loss=high_prices[-1] * 1.01,
            take_profit=support - height,
            start_index=min(recent_lows[0][0], recent_highs[0][0]),
            end_index=max(recent_lows[-1][0], recent_highs[-1][0]),
            notes=f"Support at {support:.2f}, declining highs",
        ))

    # Symmetrical Triangle: converging highs and lows
    if high_slope < -0.005 and low_slope > 0.005:
        midpoint = (high_prices[-1] + low_prices[-1]) / 2
        height = high_prices[0] - low_prices[0]

        results.append(PatternResult(
            pattern_type=PatternType.SYMMETRICAL_TRIANGLE,
            signal=PatternSignal.NEUTRAL,
            confidence=0.5,
            entry_price=midpoint,
            stop_loss=low_prices[-1] * 0.99,
            take_profit=midpoint + height * 0.5,
            start_index=min(recent_lows[0][0], recent_highs[0][0]),
            end_index=max(recent_lows[-1][0], recent_highs[-1][0]),
            notes="Converging trendlines",
        ))

    return results


def _detect_flags(
    df: pd.DataFrame, lookback: int = 5
) -> List[PatternResult]:
    """Detect Bull and Bear Flag patterns."""
    results: List[PatternResult] = []
    n = len(df)

    if n < 30:
        return results

    close = df["close"].values

    # Look for a strong move (pole) followed by consolidation (flag)
    pole_len = min(10, n // 4)
    flag_len = min(15, n // 3)

    # Bull flag: strong up move, then slight downward consolidation
    pole_start_idx = n - pole_len - flag_len
    if pole_start_idx >= 0:
        pole_change = (close[pole_start_idx + pole_len] - close[pole_start_idx]) / close[pole_start_idx]
        flag_section = close[pole_start_idx + pole_len :]
        flag_change = (flag_section[-1] - flag_section[0]) / max(flag_section[0], 1)

        if pole_change > 0.03 and -0.02 < flag_change < 0.005:
            pole_height = close[pole_start_idx + pole_len] - close[pole_start_idx]
            breakout = float(max(flag_section))

            results.append(PatternResult(
                pattern_type=PatternType.BULL_FLAG,
                signal=PatternSignal.BULLISH,
                confidence=0.6,
                entry_price=breakout * 1.002,
                stop_loss=float(min(flag_section)) * 0.99,
                take_profit=breakout + pole_height,
                start_index=pole_start_idx,
                end_index=n - 1,
                notes=f"Pole: {pole_change*100:.1f}%, Flag: {flag_change*100:.1f}%",
            ))

        # Bear flag: strong down move, slight upward consolidation
        if pole_change < -0.03 and -0.005 < flag_change < 0.02:
            pole_height = close[pole_start_idx] - close[pole_start_idx + pole_len]
            breakdown = float(min(flag_section))

            results.append(PatternResult(
                pattern_type=PatternType.BEAR_FLAG,
                signal=PatternSignal.BEARISH,
                confidence=0.6,
                entry_price=breakdown * 0.998,
                stop_loss=float(max(flag_section)) * 1.01,
                take_profit=breakdown - pole_height,
                start_index=pole_start_idx,
                end_index=n - 1,
                notes=f"Pole: {pole_change*100:.1f}%, Flag: {flag_change*100:.1f}%",
            ))

    return results


def _detect_wedges(
    df: pd.DataFrame, lookback: int = 5
) -> List[PatternResult]:
    """Detect Rising and Falling Wedge patterns."""
    results: List[PatternResult] = []
    highs, lows = find_swing_points(df, lookback)

    if len(highs) < 3 or len(lows) < 3:
        return results

    recent_highs = highs[-3:]
    recent_lows = lows[-3:]

    high_prices = [h[1] for h in recent_highs]
    low_prices = [l[1] for l in recent_lows]

    high_slope = (high_prices[-1] - high_prices[0]) / max(len(recent_highs) - 1, 1)
    low_slope = (low_prices[-1] - low_prices[0]) / max(len(recent_lows) - 1, 1)

    # Rising Wedge (bearish): both trendlines rising, converging
    if high_slope > 0 and low_slope > 0:
        # Check convergence
        range_start = high_prices[0] - low_prices[0]
        range_end = high_prices[-1] - low_prices[-1]
        if range_end < range_start * 0.8:
            results.append(PatternResult(
                pattern_type=PatternType.RISING_WEDGE,
                signal=PatternSignal.BEARISH,
                confidence=0.55,
                entry_price=low_prices[-1],
                stop_loss=high_prices[-1] * 1.01,
                take_profit=low_prices[0],
                start_index=min(recent_highs[0][0], recent_lows[0][0]),
                end_index=max(recent_highs[-1][0], recent_lows[-1][0]),
                notes="Rising converging trendlines (bearish)",
            ))

    # Falling Wedge (bullish): both trendlines falling, converging
    if high_slope < 0 and low_slope < 0:
        range_start = high_prices[0] - low_prices[0]
        range_end = high_prices[-1] - low_prices[-1]
        if range_end < range_start * 0.8:
            results.append(PatternResult(
                pattern_type=PatternType.FALLING_WEDGE,
                signal=PatternSignal.BULLISH,
                confidence=0.6,
                entry_price=high_prices[-1],
                stop_loss=low_prices[-1] * 0.99,
                take_profit=high_prices[0],
                start_index=min(recent_highs[0][0], recent_lows[0][0]),
                end_index=max(recent_highs[-1][0], recent_lows[-1][0]),
                notes="Falling converging trendlines (bullish)",
            ))

    return results
