"""Fibonacci retracement and extension calculations.

Based on the Technical Analysis Guide:
- Retracement levels: 0.236, 0.382, 0.5, 0.618, 0.786
- Extension levels: 1.0, 1.272, 1.382, 1.618, 2.0, 2.618

And from the Elliott Wave book:
- Wave 2 commonly retraces 50-61.8% of Wave 1
- Wave 3 target: 100-161.8% of Wave 1
- Wave 4 commonly retraces 23.6-38.2% of Wave 3
- Wave 5 target: 38.2-61.8% of distance from Wave 0 to Wave 3
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Dict, List, Tuple

import numpy as np
import pandas as pd


RETRACEMENT_LEVELS = [0.236, 0.382, 0.5, 0.618, 0.786]
EXTENSION_LEVELS = [1.0, 1.272, 1.382, 1.618, 2.0, 2.618, 3.0, 4.236]


@dataclass
class FibLevel:
    ratio: float
    price: float
    label: str


@dataclass
class FibResult:
    swing_high: float
    swing_low: float
    direction: str  # "up" or "down"
    retracement_levels: List[FibLevel]
    extension_levels: List[FibLevel]


def calculate_retracements(
    swing_low: float,
    swing_high: float,
    direction: str = "up",
) -> List[FibLevel]:
    """Calculate Fibonacci retracement levels.

    For uptrend: measure from swing low to swing high, retrace downward.
    For downtrend: measure from swing high to swing low, retrace upward.
    """
    levels = []
    diff = swing_high - swing_low

    for ratio in RETRACEMENT_LEVELS:
        if direction == "up":
            # Retracing down from the high
            price = swing_high - diff * ratio
        else:
            # Retracing up from the low
            price = swing_low + diff * ratio

        levels.append(FibLevel(
            ratio=ratio,
            price=round(price, 8),
            label=f"{ratio*100:.1f}%",
        ))
    return levels


def calculate_extensions(
    swing_low: float,
    swing_high: float,
    pullback: float,
    direction: str = "up",
) -> List[FibLevel]:
    """Calculate Fibonacci extension levels from a pullback point.

    Used to project Wave 3 and Wave 5 targets.
    """
    levels = []
    diff = swing_high - swing_low

    for ratio in EXTENSION_LEVELS:
        if direction == "up":
            price = pullback + diff * ratio
        else:
            price = pullback - diff * ratio

        levels.append(FibLevel(
            ratio=ratio,
            price=round(price, 8),
            label=f"{ratio*100:.1f}%",
        ))
    return levels


def find_swing_points(
    df: pd.DataFrame,
    lookback: int = 5,
) -> Tuple[List[Tuple[int, float]], List[Tuple[int, float]]]:
    """Find swing highs and swing lows in price data.

    A swing high is a point where the high is higher than the `lookback`
    candles on either side.
    """
    highs: List[Tuple[int, float]] = []
    lows: List[Tuple[int, float]] = []

    high_arr = df["high"].values
    low_arr = df["low"].values

    for i in range(lookback, len(df) - lookback):
        # Swing high
        left_highs = high_arr[i - lookback : i]
        right_highs = high_arr[i + 1 : i + lookback + 1]
        if high_arr[i] > left_highs.max() and high_arr[i] > right_highs.max():
            highs.append((i, float(high_arr[i])))

        # Swing low
        left_lows = low_arr[i - lookback : i]
        right_lows = low_arr[i + 1 : i + lookback + 1]
        if low_arr[i] < left_lows.min() and low_arr[i] < right_lows.min():
            lows.append((i, float(low_arr[i])))

    return highs, lows


def auto_fibonacci(
    df: pd.DataFrame,
    lookback: int = 5,
) -> FibResult:
    """Automatically detect the most recent swing and calculate Fib levels.

    Identifies the last significant swing high/low pair and determines
    the retracement direction based on the current trend.
    """
    highs, lows = find_swing_points(df, lookback)

    if not highs or not lows:
        # Fallback: use absolute high/low of the data
        swing_high = float(df["high"].max())
        swing_low = float(df["low"].min())
        last_close = float(df["close"].iloc[-1])
        direction = "up" if last_close > (swing_high + swing_low) / 2 else "down"
    else:
        last_high_idx, last_high_price = highs[-1]
        last_low_idx, last_low_price = lows[-1]

        if last_high_idx > last_low_idx:
            # Most recent swing is a high -> trend was up, expect retracement down
            direction = "up"
            swing_high = last_high_price
            swing_low = last_low_price
        else:
            # Most recent swing is a low -> trend was down, expect retracement up
            direction = "down"
            swing_high = last_high_price
            swing_low = last_low_price

    retracements = calculate_retracements(swing_low, swing_high, direction)

    # For extensions, use the last pullback (most recent opposite swing)
    pullback = swing_low if direction == "up" else swing_high
    extensions = calculate_extensions(swing_low, swing_high, pullback, direction)

    return FibResult(
        swing_high=swing_high,
        swing_low=swing_low,
        direction=direction,
        retracement_levels=retracements,
        extension_levels=extensions,
    )


def nearest_fib_level(
    price: float,
    fib_result: FibResult,
    tolerance_pct: float = 0.5,
) -> FibLevel | None:
    """Check if price is near a Fibonacci level within tolerance."""
    all_levels = fib_result.retracement_levels + fib_result.extension_levels
    for level in all_levels:
        pct_diff = abs(price - level.price) / level.price * 100
        if pct_diff <= tolerance_pct:
            return level
    return None
