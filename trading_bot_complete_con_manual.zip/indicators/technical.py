"""Technical indicators: RSI, MACD, Bollinger Bands, EMA, SMA, ATR, Stochastic, VWAP, OBV."""

from __future__ import annotations

from dataclasses import dataclass
from typing import List, Optional, Tuple

import numpy as np
import pandas as pd

from connectors.base import Candle


def candles_to_df(candles: List[Candle]) -> pd.DataFrame:
    """Convert list of Candle objects to a pandas DataFrame."""
    data = {
        "timestamp": [c.timestamp for c in candles],
        "open": [c.open for c in candles],
        "high": [c.high for c in candles],
        "low": [c.low for c in candles],
        "close": [c.close for c in candles],
        "volume": [c.volume for c in candles],
    }
    df = pd.DataFrame(data)
    df.set_index("timestamp", inplace=True)
    return df


# ---------------------------------------------------------------------------
# Moving Averages
# ---------------------------------------------------------------------------

def sma(series: pd.Series, period: int) -> pd.Series:
    """Simple Moving Average."""
    return series.rolling(window=period, min_periods=1).mean()


def ema(series: pd.Series, period: int) -> pd.Series:
    """Exponential Moving Average."""
    return series.ewm(span=period, adjust=False).mean()


def wma(series: pd.Series, period: int) -> pd.Series:
    """Weighted Moving Average."""
    weights = np.arange(1, period + 1, dtype=float)
    return series.rolling(window=period).apply(
        lambda x: np.dot(x, weights[-len(x):]) / weights[-len(x):].sum(),
        raw=True,
    )


# ---------------------------------------------------------------------------
# RSI
# ---------------------------------------------------------------------------

def rsi(series: pd.Series, period: int = 14) -> pd.Series:
    """Relative Strength Index."""
    delta = series.diff()
    gain = delta.where(delta > 0, 0.0)
    loss = (-delta).where(delta < 0, 0.0)
    avg_gain = gain.ewm(alpha=1 / period, min_periods=period).mean()
    avg_loss = loss.ewm(alpha=1 / period, min_periods=period).mean()
    rs = avg_gain / avg_loss.replace(0, np.nan)
    return 100 - (100 / (1 + rs))


# ---------------------------------------------------------------------------
# MACD
# ---------------------------------------------------------------------------

@dataclass
class MACDResult:
    macd_line: pd.Series
    signal_line: pd.Series
    histogram: pd.Series


def macd(
    series: pd.Series,
    fast: int = 12,
    slow: int = 26,
    signal: int = 9,
) -> MACDResult:
    """MACD indicator."""
    fast_ema = ema(series, fast)
    slow_ema = ema(series, slow)
    macd_line = fast_ema - slow_ema
    signal_line = ema(macd_line, signal)
    histogram = macd_line - signal_line
    return MACDResult(macd_line=macd_line, signal_line=signal_line, histogram=histogram)


# ---------------------------------------------------------------------------
# Bollinger Bands
# ---------------------------------------------------------------------------

@dataclass
class BollingerBands:
    upper: pd.Series
    middle: pd.Series
    lower: pd.Series
    bandwidth: pd.Series
    percent_b: pd.Series


def bollinger_bands(
    series: pd.Series, period: int = 20, std_dev: float = 2.0
) -> BollingerBands:
    """Bollinger Bands."""
    middle = sma(series, period)
    std = series.rolling(window=period, min_periods=1).std()
    upper = middle + std_dev * std
    lower = middle - std_dev * std
    bandwidth = (upper - lower) / middle
    percent_b = (series - lower) / (upper - lower)
    return BollingerBands(
        upper=upper, middle=middle, lower=lower,
        bandwidth=bandwidth, percent_b=percent_b,
    )


# ---------------------------------------------------------------------------
# ATR (Average True Range)
# ---------------------------------------------------------------------------

def atr(df: pd.DataFrame, period: int = 14) -> pd.Series:
    """Average True Range."""
    high = df["high"]
    low = df["low"]
    close = df["close"]
    prev_close = close.shift(1)
    tr1 = high - low
    tr2 = (high - prev_close).abs()
    tr3 = (low - prev_close).abs()
    true_range = pd.concat([tr1, tr2, tr3], axis=1).max(axis=1)
    return true_range.rolling(window=period, min_periods=1).mean()


# ---------------------------------------------------------------------------
# Stochastic Oscillator
# ---------------------------------------------------------------------------

@dataclass
class StochasticResult:
    k: pd.Series
    d: pd.Series


def stochastic(
    df: pd.DataFrame, k_period: int = 14, d_period: int = 3
) -> StochasticResult:
    """Stochastic Oscillator (%K and %D)."""
    lowest_low = df["low"].rolling(window=k_period, min_periods=1).min()
    highest_high = df["high"].rolling(window=k_period, min_periods=1).max()
    denom = highest_high - lowest_low
    k_val = 100 * (df["close"] - lowest_low) / denom.replace(0, np.nan)
    d_val = sma(k_val, d_period)
    return StochasticResult(k=k_val, d=d_val)


# ---------------------------------------------------------------------------
# VWAP (Volume Weighted Average Price)
# ---------------------------------------------------------------------------

def vwap(df: pd.DataFrame) -> pd.Series:
    """Volume Weighted Average Price (intraday)."""
    typical_price = (df["high"] + df["low"] + df["close"]) / 3
    cum_tp_vol = (typical_price * df["volume"]).cumsum()
    cum_vol = df["volume"].cumsum()
    return cum_tp_vol / cum_vol.replace(0, np.nan)


# ---------------------------------------------------------------------------
# OBV (On Balance Volume)
# ---------------------------------------------------------------------------

def obv(df: pd.DataFrame) -> pd.Series:
    """On Balance Volume."""
    direction = np.sign(df["close"].diff())
    return (direction * df["volume"]).cumsum()


# ---------------------------------------------------------------------------
# ADX (Average Directional Index)
# ---------------------------------------------------------------------------

@dataclass
class ADXResult:
    adx: pd.Series
    plus_di: pd.Series
    minus_di: pd.Series


def adx(df: pd.DataFrame, period: int = 14) -> ADXResult:
    """Average Directional Index."""
    high = df["high"]
    low = df["low"]
    close = df["close"]

    plus_dm = high.diff()
    minus_dm = -low.diff()
    plus_dm = plus_dm.where((plus_dm > minus_dm) & (plus_dm > 0), 0.0)
    minus_dm = minus_dm.where((minus_dm > plus_dm) & (minus_dm > 0), 0.0)

    atr_val = atr(df, period)
    plus_di = 100 * ema(plus_dm, period) / atr_val.replace(0, np.nan)
    minus_di = 100 * ema(minus_dm, period) / atr_val.replace(0, np.nan)

    dx = 100 * (plus_di - minus_di).abs() / (plus_di + minus_di).replace(0, np.nan)
    adx_val = ema(dx, period)

    return ADXResult(adx=adx_val, plus_di=plus_di, minus_di=minus_di)


# ---------------------------------------------------------------------------
# Ichimoku Cloud
# ---------------------------------------------------------------------------

@dataclass
class IchimokuResult:
    tenkan: pd.Series
    kijun: pd.Series
    senkou_a: pd.Series
    senkou_b: pd.Series
    chikou: pd.Series


def ichimoku(
    df: pd.DataFrame,
    tenkan_period: int = 9,
    kijun_period: int = 26,
    senkou_b_period: int = 52,
) -> IchimokuResult:
    """Ichimoku Cloud."""
    high = df["high"]
    low = df["low"]
    close = df["close"]

    tenkan = (
        high.rolling(window=tenkan_period, min_periods=1).max()
        + low.rolling(window=tenkan_period, min_periods=1).min()
    ) / 2

    kijun = (
        high.rolling(window=kijun_period, min_periods=1).max()
        + low.rolling(window=kijun_period, min_periods=1).min()
    ) / 2

    senkou_a = ((tenkan + kijun) / 2).shift(kijun_period)
    senkou_b = (
        (
            high.rolling(window=senkou_b_period, min_periods=1).max()
            + low.rolling(window=senkou_b_period, min_periods=1).min()
        )
        / 2
    ).shift(kijun_period)

    chikou = close.shift(-kijun_period)

    return IchimokuResult(
        tenkan=tenkan, kijun=kijun, senkou_a=senkou_a,
        senkou_b=senkou_b, chikou=chikou,
    )


# ---------------------------------------------------------------------------
# Pivot Points
# ---------------------------------------------------------------------------

def pivot_points(df: pd.DataFrame) -> Tuple[float, float, float, float, float]:
    """Classic pivot points from last candle. Returns (PP, R1, R2, S1, S2)."""
    last = df.iloc[-1]
    pp = (last["high"] + last["low"] + last["close"]) / 3
    r1 = 2 * pp - last["low"]
    s1 = 2 * pp - last["high"]
    r2 = pp + (last["high"] - last["low"])
    s2 = pp - (last["high"] - last["low"])
    return pp, r1, r2, s1, s2


# ---------------------------------------------------------------------------
# Donchian Channel
# ---------------------------------------------------------------------------

@dataclass
class DonchianChannel:
    upper: pd.Series
    lower: pd.Series
    middle: pd.Series


def donchian(df: pd.DataFrame, period: int = 20) -> DonchianChannel:
    """Donchian Channel."""
    upper = df["high"].rolling(window=period, min_periods=1).max()
    lower = df["low"].rolling(window=period, min_periods=1).min()
    middle = (upper + lower) / 2
    return DonchianChannel(upper=upper, lower=lower, middle=middle)
