"""Volume analysis indicators."""

from __future__ import annotations

from dataclasses import dataclass

import numpy as np
import pandas as pd

from indicators.technical import ema, sma


@dataclass
class VolumeProfile:
    avg_volume: float
    current_volume: float
    volume_ratio: float  # current / average
    is_high_volume: bool
    trend: str  # "increasing", "decreasing", "stable"


def volume_profile(df: pd.DataFrame, period: int = 20) -> VolumeProfile:
    """Analyze volume profile."""
    vol = df["volume"]
    avg = float(vol.rolling(window=period, min_periods=1).mean().iloc[-1])
    current = float(vol.iloc[-1])
    ratio = current / avg if avg > 0 else 0

    # Volume trend
    recent = vol.tail(5).values
    if len(recent) >= 3:
        slope = np.polyfit(range(len(recent)), recent, 1)[0]
        if slope > avg * 0.1:
            trend = "increasing"
        elif slope < -avg * 0.1:
            trend = "decreasing"
        else:
            trend = "stable"
    else:
        trend = "stable"

    return VolumeProfile(
        avg_volume=avg,
        current_volume=current,
        volume_ratio=ratio,
        is_high_volume=ratio > 1.5,
        trend=trend,
    )


def money_flow_index(df: pd.DataFrame, period: int = 14) -> pd.Series:
    """Money Flow Index (MFI) - volume-weighted RSI."""
    typical_price = (df["high"] + df["low"] + df["close"]) / 3
    money_flow = typical_price * df["volume"]

    pos_flow = money_flow.where(typical_price > typical_price.shift(1), 0)
    neg_flow = money_flow.where(typical_price < typical_price.shift(1), 0)

    pos_sum = pos_flow.rolling(window=period, min_periods=1).sum()
    neg_sum = neg_flow.rolling(window=period, min_periods=1).sum()

    mfi = 100 - (100 / (1 + pos_sum / neg_sum.replace(0, np.nan)))
    return mfi


def volume_weighted_macd(
    df: pd.DataFrame, fast: int = 12, slow: int = 26, signal: int = 9
) -> pd.Series:
    """VWMACD - Volume weighted MACD."""
    vwap_fast = ema(df["close"] * df["volume"], fast) / ema(df["volume"], fast)
    vwap_slow = ema(df["close"] * df["volume"], slow) / ema(df["volume"], slow)
    vwmacd = vwap_fast - vwap_slow
    return vwmacd


def accumulation_distribution(df: pd.DataFrame) -> pd.Series:
    """Accumulation/Distribution Line."""
    clv = ((df["close"] - df["low"]) - (df["high"] - df["close"])) / (
        df["high"] - df["low"]
    ).replace(0, np.nan)
    ad = (clv * df["volume"]).cumsum()
    return ad


def detect_volume_divergence(
    df: pd.DataFrame, lookback: int = 10
) -> str:
    """Detect price-volume divergence.

    Returns: "bullish_divergence", "bearish_divergence", or "none"
    """
    if len(df) < lookback * 2:
        return "none"

    recent = df.tail(lookback)
    prev = df.iloc[-lookback * 2 : -lookback]

    price_change = float(recent["close"].iloc[-1] - prev["close"].iloc[-1])
    vol_change = float(recent["volume"].mean() - prev["volume"].mean())

    if price_change > 0 and vol_change < 0:
        return "bearish_divergence"  # Price up, volume down
    elif price_change < 0 and vol_change > 0:
        return "bullish_divergence"  # Price down, volume up

    return "none"
